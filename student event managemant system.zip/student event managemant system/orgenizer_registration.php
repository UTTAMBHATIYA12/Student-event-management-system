<?php
// 1. Include your Image Upload Class file
require_once 'controller/operation.php';
require_once 'model/database.php';

if (isset($_POST['submit_form'])) {

    $full_name = $_POST['full_name'];
    $comapny_name = $_POST['comapny_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $bio = $_POST['bio'];
    $experience = $_POST['experience'];
    $address = $_POST['address'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $orgenizer = new Orgenizer();
    if ($orgenizer->getId($email, $phone) > 0) {
        echo "<script>alert('An organizer with this Email or Phone Number already exists!')</script>";
    } else {
        $image_name = $_FILES['compny_logo']['name'];
        $temp_name = $_FILES['compny_logo']['tmp_name'];

        // Fix: Remove __DIR__ and ensure the slashes are consistent
        $folder = "view/uploads/profile_pictures/" . $image_name;

        if (move_uploaded_file($temp_name, $folder)) {
            $Orgenizer = new Orgenizer();
            echo "<script>alert('" . $Orgenizer->Insert_new_Orgenizer($full_name, $comapny_name, $email, $phone, $bio, $experience, $address, $image_name, $password) . "')</script>";
        } else {
            echo "Upload failed. Check if the folder exists and has write permissions.";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer Registration</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="view/css/style.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }

        /* Ensuring the transition for your JS border-color change works smoothly */
        .form-input {
            transition: border-color 0.2s ease-in-out;
        }
    </style>
</head>

<body class="flex items-center justify-center min-h-screen p-4">

    <div class="bg-white w-full max-w-3xl rounded-2xl shadow-sm border border-slate-200 p-8 md:p-12">
        <div class="mb-10 text-center md:text-left">
            <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">Create Account</h2>
            <p class="text-slate-500 mt-2">Enter your professional details to get started.</p>
        </div>

        <form method="POST" enctype="multipart/form-data" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                    <input type="text" name="full_name" placeholder="John Doe"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Company Name</label>
                    <input type="text" name="comapny_name" placeholder="Acme Events"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Email</label>
                    <input type="email" name="email" placeholder="hello@company.com"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Phone</label>
                    <input type="tel" name="phone" pattern="[0-9]{10,12}" title="Please enter a valid phone number"
                        placeholder="9998887776"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1">About the Organizer (Bio)</label>
                <textarea name="bio" rows="3" placeholder="Briefly describe your event history..."
                    class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none resize-none"></textarea>
            </div>
            <div class="space-y-2">
                <label class="block text-sm font-semibold text-slate-700 mb-1">Experience Level</label>
                <select name="experience"
                    class="orm-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none resize-none">
                    <option value="" disabled selected>Select Experience</option>
                    <option value="Less than 1 year">Less than 1 year</option>
                    <option value="1 year">1 Year</option>
                    <option value="2 years">2 Years</option>
                    <option value="3 years">3 Years</option>
                    <option value="4 years">4 Years</option>
                    <option value="5 years">5 Years</option>
                    <option value="More than 5 years">More than 5 years</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1">Address</label>
                <input type="text" name="address" placeholder="123 Street Name, City"
                    class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1">Company Logo</label>
                <div
                    class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-lg hover:border-indigo-400 transition-colors">
                    <div class="space-y-1 text-center">
                        <svg class="mx-auto h-12 w-12 text-slate-400" stroke="currentColor" fill="none"
                            viewBox="0 0 48 48">
                            <path
                                d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <div class="flex text-sm text-slate-600">
                            <label for="file-upload"
                                class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500">
                                <span>Upload a file</span>
                                <input id="file-upload" name="compny_logo" type="file" class="sr-only">
                            </label>
                            <p class="pl-1">or drag and drop</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Password</label>
                    <input type="password" name="password"
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}"
                        title="Must contain at least one number, one uppercase, one lowercase letter, one special character, and at least 8 characters"
                        placeholder="••••••••"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1">Confirm Password</label>
                    <input type="password" name="confirm_password" placeholder="••••••••"
                        class="form-input w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:outline-none">
                </div>
            </div>
            <button type="submit" name="submit_form"
                class="w-full bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-indigo-600 transition-all shadow-md">
                Register Now
            </button>
        </form>

        <div class="mt-6 text-center text-sm text-slate-600">
            Already registered? <a href="index.php" class="text-indigo-600 font-semibold hover:underline">Login Now</a>
        </div>
    </div>

    <script>
        // --- YOUR EXACT JS CODE ---
        document.querySelector('form').addEventListener('submit', function (e) {
            const pass = document.querySelector('input[name="password"]').value;
            const confirmPass = document.querySelector('input[name="confirm_password"]').value;

            if (pass !== confirmPass) {
                e.preventDefault();
                alert("Error: Passwords do not match!");
                document.querySelector('input[name="confirm_password"]').style.borderColor = "#ef4444";
                document.querySelector('input[name="confirm_password"]').focus();
            }
        });

        document.querySelector('input[name="password"]').addEventListener('input', function () {
            if (this.value.length >= 8) {
                this.style.borderColor = "#22c55e";
            } else {
                this.style.borderColor = "#e2e8f0";
            }
        });
    </script>
</body>

</html>