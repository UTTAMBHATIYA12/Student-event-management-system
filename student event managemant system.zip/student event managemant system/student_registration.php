<?php
require_once('model/database.php');
require_once('controller/operation.php');

$Student = new Student();
$Collage = new Collage();
$collage_id = 0;
// --- 1. AJAX HANDLER (Must be first) ---
if (isset($_POST['get_college_name'])) {
    $code = $_POST['collage_code'];
    $result = $Collage->getCollegeNameByCode($code);

    if ($result && $row = $result->fetch_assoc()) {
        // Send Name and ID separated by |
        echo $row['college_name'] . "|" . $row['college_id'];
    } else {
        echo "Not Found";
    }
    exit;
}

// --- 2. REGISTRATION LOGIC ---
if (isset($_REQUEST['register_student'])) {
    $name = $_POST['student_name'];
    $gender = $_POST['gender'];
    $course = $_POST['course'];
    $year = $_POST['year'];
    $semester = $_POST['semester'];
    $roll_no = $_POST['roll_no'];
    $collage_code = $_POST['collage_code'];
    $college_id = $_POST['college_id'];
    $email = $_POST['email'];
    $contact = $_POST['phone_number'];
    $password = $_POST['password'];
    $image_name = 'profile_image';

    if (empty($_POST['collage_name'])) {
        $Registration_msg = "Wrong Collage Code, Please Enter Correct Collage Code which Provid Provide By Your Collage, If generate any issue please contact Your Collage";
    } else {
        $Registration = new Registration();
        $Registration_msg = $Registration->student_validation_check($name, $gender, $course, $year, $semester, $roll_no, $college_id, $image_name, $email, $contact, $password);
    }
    header('location:index.php?error=' . $Registration_msg);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEMS | Student Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <style>
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --secondary: #0ea5e9;
            --bg-dark: #0f172a;
            --text-main: #1e293b;
            --text-light: #64748b;
            --white: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: url('https://images.unsplash.com/photo-1523580494863-6f3031224c94') no-repeat center/cover;
            padding: 20px;
        }

        .main-card {
            display: flex;
            width: 100%;
            max-width: 1100px;
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(15px);
            border-radius: 24px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .brand-panel {
            flex: 1;
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            color: var(--white);
            background: rgba(15, 23, 42, 0.5);
        }

        .logo-icon {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: var(--secondary);
            margin-bottom: 30px;
        }

        .feature-list {
            list-style: none;
            margin-top: 40px;
        }

        .feature-list li {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            color: #cbd5e1;
        }

        .feature-list i {
            color: var(--secondary);
            margin-right: 12px;
        }

        .form-panel {
            flex: 1.4;
            padding: 50px;
            background: var(--white);
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .full-width {
            grid-column: span 2;
        }

        .triple-grid {
            grid-column: span 2;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .input-box {
            display: flex;
            flex-direction: column;
        }

        .input-box label {
            font-size: 13px;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 8px;
        }

        .input-field {
            position: relative;
            width: 100%;
        }

        .input-field i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            z-index: 2;
        }

        .input-field input,
        .input-field select {
            width: 100%;
            height: 48px;
            padding: 0 15px 0 45px;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            outline: none;
            font-size: 14px;
            background: #f8fafc;
            transition: 0.3s;
        }

        .btn-submit {
            width: 100%;
            padding: 15px;
            margin-top: 25px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
        }

        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: var(--text-light);
        }

        @media (max-width: 992px) {
            .brand-panel {
                display: none;
            }

            .main-card {
                max-width: 650px;
            }
        }
    </style>
</head>

<body>

    <div class="main-card">
        <div class="brand-panel">
            <div class="brand-content">
                <div class="logo-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                <h1>Empower Your Campus.</h1>
                <p>Join SEMS today and streamline your event management.</p>
                <ul class="feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> Automated Student Entry</li>
                    <li><i class="fa-solid fa-circle-check"></i> Real-time Analytics</li>
                    <li><i class="fa-solid fa-circle-check"></i> Unique College Coding</li>
                </ul>
            </div>
            <div class="brand-footer"><small>Student Event Management System</small></div>
        </div>

        <div class="form-panel">
            <div class="form-header">
                <h2>Student Registration</h2>
                <p>Provide your details to initiate the onboarding process.</p><br>
            </div>

            <form method="post" enctype="multipart/form-data">
                <div class="grid-container">
                    <div class="input-box full-width">
                        <label>Student Name</label>
                        <div class="input-field">
                            <i class="fa-solid fa-user-tie"></i>
                            <input type="text" name="student_name" placeholder="Your Full Name" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Gender</label>
                        <div class="input-field">
                            <i class="fa-solid fa-venus-mars"></i>
                            <select name="gender" required>
                                <option value="" disabled selected>Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Course</label>
                        <div class="input-field">
                            <i class="fa-solid fa-book-open"></i>
                            <input type="text" name="course" placeholder="e.g. BCA, MCA" required>
                        </div>
                    </div>

                    <div class="triple-grid">
                        <div class="input-box">
                            <label>Year</label>
                            <div class="input-field">
                                <i class="fa-solid fa-calendar-days"></i>
                                <select name="year" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                </select>
                            </div>
                        </div>
                        <div class="input-box">
                            <label>Semester</label>
                            <div class="input-field">
                                <i class="fa-solid fa-layer-group"></i>
                                <select name="semester" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                </select>
                            </div>
                        </div>
                        <div class="input-box">
                            <label>Roll No</label>
                            <div class="input-field">
                                <i class="fa-solid fa-hashtag"></i>
                                <input type="text" name="roll_no" placeholder="Roll No" required>
                            </div>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>College Code</label>
                        <div class="input-field">
                            <i class="fa-solid fa-barcode"></i>
                            <input type="text" name="collage_code" id="collage_code"
                                title="Enter Collage Code Which Given By Your Collage" placeholder="Unique ID" required
                                oninput="fetchCollegeName()">
                        </div>
                    </div>

                    <div class="input-box">
                        <label>College Name</label>
                        <div class="input-field">
                            <i class="fa-solid fa-building"></i>
                            <input type="text" id="college_display_name" name="collage_name" placeholder="Detecting..."
                                readonly style="background: #f1f5f9; cursor: not-allowed;">
                        </div>
                    </div>

                    <div class="input-box full-width">
                        <label>Profile Picture</label>
                        <input type="file" name="profile_image" required>
                    </div>

                    <div class="input-box">
                        <label>Email</label>
                        <div class="input-field">
                            <i class="fa-solid fa-envelope"></i>
                            <input type="email" name="email" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Phone</label>
                        <div class="input-field">
                            <i class="fa-solid fa-phone"></i>
                            <input type="text" name="phone_number" pattern="^[0-9]{10}$" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Password</label>
                        <div class="input-field">
                            <i class="fa-solid fa-lock"></i>
                            <input type="password" name="password"
                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}" placeholder="••••••••"
                                title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                                required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Confirm Password</label>
                        <div class="input-field">
                            <i class="fa-solid fa-shield-halved"></i>
                            <input type="password" name="confirm_password"
                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}" placeholder="••••••••"
                                title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                                required>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="college_id" id="college_id_hidden">
                <button type="submit" name="register_student" class="btn-submit">Complete Registration</button>
                <div class="footer-text">Already registered? <a href="index.php">Login Now</a></div>
            </form>
        </div>
    </div>
    <script src="view/js/validation.js"></script>
</body>

</html>