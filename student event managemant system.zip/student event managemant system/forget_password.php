<?php
session_start();
require_once('controller/operation.php');
require_once('model/database.php');
$verifyEmail = new verifyEmail();
$Collage = new Collage();
$student = new Student();
$org = new Orgenizer();
$admin = new admin();
// STEP CONTROL
if (!isset($_SESSION['step'])) {
    $_SESSION['step'] = 1;
}
// STEP 1: SEND OTP
if (isset($_POST['next'])) {
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['otp'] = $verifyEmail->generateOTP();

    $userType = "";

    if ($Collage->getId($_SESSION['email']) > 0) {
        $userType = "collage";
    } elseif ($student->getId($_SESSION['email']) > 0) {
        $userType = "student";
    } elseif ($org->getId($_SESSION['email'], 0) > 0) {
        $userType = "organizer";
    } elseif ($admin->getId($_SESSION['email']) > 0) {
        $userType = "admin";
    } else {
        $error = "Email Not registered!";
    }
    if (!empty($userType)) {

        $_SESSION['user_type'] = $userType;

        // send email
        $msg_return = $verifyEmail->send_email($_SESSION['email'], $_SESSION['otp'], "none");
        $msg_return = 1;

        if (!empty($_SESSION['otp']) && $msg_return == 1) {
            $success = "OTP Sent Successfully!";
            $_SESSION['step'] = 2;
        } else {
            $error = "Failed to send OTP!";
        }
    }
}

// STEP 2: VERIFY OTP
if (isset($_POST['verify'])) {

    if (empty($_SESSION['otp'])) {
        $error = "Session expired. Please request OTP again!";
    } elseif (trim($_POST['otp']) == $_SESSION['otp']) {
        $_SESSION['step'] = 3;
        unset($_SESSION['otp']);
    } else {
        $error = "Invalid OTP!";
    }
}

// STEP 3: RESET PASSWORD
if (isset($_POST['reset'])) {

    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password != $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($new_password) < 8) {
        $error = "Password must be at least 8 characters!";
    } else {

        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        if ($_SESSION['user_type'] == "student") {
            $student->update_password($_SESSION['email'], $hashed_password);
        } elseif ($_SESSION['user_type'] == "admin") {
            $admin->update_password($_SESSION['email'], $hashed_password);
        } elseif ($_SESSION['user_type'] == "organizer") {
            $org->update_password($_SESSION['email'], $hashed_password);
        } elseif ($_SESSION['user_type'] == "collage") {
            $Collage->update_password($_SESSION['email'], $hashed_password);
        }
        header('location:index.php?error=Password updated successfully!');
        $success = "Password updated successfully!";
        session_destroy();
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Forgot Password</title>

    <style>
        body {
            background: #f1f3f4;
            font-family: Arial;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .box {
            display: flex;
            justify-content: space-between;
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 800px;
            max-width: 95%;
        }

        .left {
            width: 45%;
        }

        .right {
            width: 45%;
        }

        h2 {
            margin-bottom: 10px;
        }

        p {
            color: #5f6368;
            font-size: 14px;
        }

        .input-group {
            position: relative;
            margin-top: 20px;
        }

        .input-group input {
            width: 100%;
            padding: 14px;
            border: 1px solid #dadce0;
            border-radius: 6px;
        }

        .input-group label {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            background: #fff;
            padding: 0 5px;
            color: #777;
            transition: 0.3s;
        }

        .input-group input:focus+label,
        .input-group input:valid+label {
            top: -8px;
            font-size: 12px;
            color: #1a73e8;
        }

        .input-group input:focus {
            border-color: #1a73e8;
        }

        .buttons {
            margin-top: 25px;
            text-align: right;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .next {
            background: #1a73e8;
            color: white;
        }

        .cancel {
            text-decoration: none;
            background: transparent;
            color: #1a73e8;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>

<body>

    <div class="box">

        <!-- LEFT -->
        <div class="left">
            <h2>Forgot Password</h2>

            <?php if ($_SESSION['step'] == 1) { ?>
                <p>Enter your registered email to receive OTP.</p>
            <?php } elseif ($_SESSION['step'] == 2) { ?>
                <p>Enter OTP sent to <b>
                        <?php echo $_SESSION['email']; ?>
                    </b></p>
            <?php } else { ?>
                <p>Create a new password for your account.</p>
            <?php } ?>

            <p style="margin-top:20px;">🔒 Never share your OTP.</p>
        </div>

        <!-- RIGHT -->
        <div class="right">

            <?php if (isset($error))
                echo "<p class='error'>$error</p>"; ?>
            <?php if (isset($success))
                echo "<p class='success'>$success</p>"; ?>

            <!-- STEP 1 -->
            <?php if ($_SESSION['step'] == 1) { ?>
                <form method="POST">
                    <div class="input-group">
                        <input type="email" name="email" required>
                        <label>Email address</label>
                    </div>

                    <div class="buttons">
                        <button class="btn cancel"><a href="index.php" class="cancel">Back</a></button>&nbsp;&nbsp;&nbsp;
                        <button class="btn next" name="next">Next</button>
                    </div>
                </form>
            <?php } ?>

            <!-- STEP 2 -->
            <?php if ($_SESSION['step'] == 2) { ?>
                <form method="POST">
                    <div class="input-group">
                        <input type="text" name="otp" required>
                        <label>Enter OTP</label>
                    </div>

                    <div class="buttons">
                        <button class="btn next" name="verify">Verify</button>
                    </div>
                </form>
            <?php } ?>

            <!-- STEP 3 -->
            <?php if ($_SESSION['step'] == 3) { ?>
                <form method="POST">
                    <div class="input-group">
                        <input type="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}"
                            placeholder="••••••••"
                            title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                            required>
                        <label>New Password</label>
                    </div>

                    <div class="input-group">
                        <input type="password" name="confirm_password"
                            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}" placeholder="••••••••"
                            title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                            required>
                        <label>Confirm Password</label>
                    </div>

                    <div class="buttons">
                        <button type="submit" class="btn success" name="reset">Reset Password</button>
                    </div>
                </form>
            <?php } ?>

        </div>

    </div>
    <script src="view\js\validation.js"></script>
</body>

</html>