<?php
require_once('controller/operation.php');
if (isset($_REQUEST['submit'])) {

    $college_name = $_POST['college_name'];
    $college_code = $_POST['college_code'];
    $university_name = $_POST['university_name'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $total_students = $_POST['total_students'];
    $principal_name = $_POST['principal_name'];
    $password = $_POST['password'];

    $Registration = new Registration();

    echo "<script>alert('" . $Registration->Collage_Validation_check($college_name, $university_name, $college_code, $address, $city, $state, $pincode, $phone_number, $email, $password, $principal_name, $total_students) . "')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEMS | College Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="view/css/registration_page_style.css">

</head>

<body>

    <div class="main-card">
        <div class="brand-panel">
            <div class="brand-content">
                <div class="logo-icon">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <h1>Empower Your Campus.</h1>
                <p>Join SEMS today and streamline your event management with precision.</p>

                <ul class="feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> Automated Student Entry</li>
                    <li><i class="fa-solid fa-circle-check"></i> Real-time Analytics</li>
                    <li><i class="fa-solid fa-circle-check"></i> Unique College Coding</li>
                </ul>
            </div>
            <div class="brand-footer">
                <small>Student Events Management System</small>
            </div>
        </div>

        <div class="form-panel">
            <div class="form-header">
                <h2>College Registration</h2>
                <p>Provide your details to initiate the onboarding process.</p>
            </div><br><br>

            <form method="post">
                <div class="grid-container">
                    <div class="input-box">
                        <label>College Name</label>
                        <div class="input-field">
                            <i class="fa fa-school"></i>
                            <input type="text" name="college_name" placeholder="e.g. Stanford University" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>College Code</label>
                        <div class="input-field">
                            <i class="fa fa-barcode"></i>
                            <input type="text" name="college_code" placeholder="Unique ID" required>
                        </div>
                    </div>

                    <div class="input-box full-width">
                        <label>University Affiliation</label>
                        <div class="input-field">
                            <i class="fa fa-building"></i>
                            <input type="text" name="university_name" placeholder="Parent University Name" required>
                        </div>
                    </div>

                    <div class="input-box full-width">
                        <label>Official Address</label>
                        <div class="input-field">
                            <i class="fa fa-map-marker-alt"></i>
                            <textarea name="address" placeholder="Street, Block, and Landmark" required></textarea>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>City</label>
                        <div class="input-field">
                            <i class="fa fa-city"></i>
                            <input type="text" placeholder="City" name="city" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Pin-code</label>
                        <div class="input-field">
                            <i class="fa fa-code"></i>
                            <input type="text" placeholder="123456" name="pincode" pattern="^[0-9]{6}$" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label>State</label>
                        <div class="input-field">
                            <i class="fa fa-code"></i>
                            <input type="text" placeholder="State" name="state" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Email Address</label>
                        <div class="input-field">
                            <i class="fa fa-envelope"></i>
                            <input type="email" name="email" placeholder="admin@college.edu" required>
                        </div>
                    </div>

                    <div class="input-box full-width">
                        <label>Principal's Name</label>
                        <div class="input-field ">
                            <i class="fa fa-user-tie"></i>
                            <input type="text" name="principal_name" placeholder="Full Name" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label>Total Student</label>
                        <div class="input-field">
                            <i class="fa fa-user"></i>
                            <input type="text" name="total_students" placeholder="500" required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Contact Number</label>
                        <div class="input-field">
                            <i class="fa fa-phone"></i>
                            <input type="text" name="phone_number" placeholder="+1 234 567 890" pattern="^[0-9]{10}$"
                                required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Password</label>
                        <div class="input-field">
                            <i class="fa-solid fa-lock"></i>
                            <input type="password" name="password"
                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}" placeholder="••••••••"
                                title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                                required>
                        </div>
                    </div>

                    <div class="input-box">
                        <label>Confirm Password</label>
                        <div class="input-field">
                            <i class="fa-solid fa-shield-halved"></i>
                            <input type="password" name="confirm_password"
                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,}" placeholder="••••••••"
                                title="Minimum 8 characters, at least one uppercase, one lowercase, one number and one special character"
                                required>
                        </div>
                    </div>
                </div>

                <button type="submit" name="submit" class="btn-submit">Register College</button>

                <div class="footer-text">
                    Already registered? <a href="/student%20event%20managemant%20system/">Login Now</a>
                </div>
            </form>
        </div>
    </div>
    <script src="view/js/validation.js"></script>
</body>

</html>