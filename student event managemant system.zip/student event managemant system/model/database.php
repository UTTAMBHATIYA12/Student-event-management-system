<?php

class Database
{
    protected $conn;
    public function __construct()
    {
        // Centralized connection
        $this->conn = new mysqli("localhost", "root", "", "student_event_management_system");
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
}

class events extends Database
{
    public function Insert($event_name, $event_desc, $event_date, $event_venue, $event_time, $image_name, $collage_id)
    {
        $this->conn->query("INSERT INTO `events` (`event_id`, `event_name`, `event_description`, `event_date`, `venue`, `college_id`, `created_at`, `time`, `event_image`)
            VALUES (NULL, '$event_name', '$event_desc', '$event_date', '$event_venue', '$collage_id', CURRENT_TIMESTAMP, '$event_time','$image_name');");
        return "Event Created Successfully !!";
    }
    public function Delete($event_id, $collage_id)
    {
        if ($event_id == 0)
            $sql = "DELETE FROM events WHERE `college_id` = '$collage_id'";
        else
            $sql = "DELETE FROM events WHERE college_id = $collage_id AND event_id = $event_id";
        $this->conn->query($sql);
    }
    public function Update($event_id, $collage_id, $event_name, $event_desc, $event_date_time, $event_venue)
    {
        $this->conn->query("UPDATE `events` SET `event_name` = '$event_name', `event_description` = '$event_desc', `event_date_time` = '$event_date_time', `venue` = '$event_venue' WHERE `event_id` = '$event_id' AND `college_id` = '$collage_id';");
        return "Event Updated Successfully";
    }
    public function Search($collage_id, $find)
    {
        $sql = "SELECT * FROM `events` WHERE `time` LIKE '$find%' OR `venue` LIKE '$find%' OR `event_date` LIKE '$find%' OR `event_name` LIKE '$find%' OR `event_id` LIKE '$find%' OR `status` LIKE '$find%' AND `college_id` = $collage_id ORDER BY event_id DESC";
        return $this->conn->query($sql);
    }
    public function Selete($collage_id, $event_id)
    {
        if ($event_id == 0)
            $sql = "SELECT * FROM events WHERE college_id = $collage_id ORDER BY event_id DESC";
        else
            $sql = "SELECT * FROM `events` WHERE `college_id` = $collage_id AND `event_id` = $event_id";
        return $this->conn->query($sql);
    }
    public function Event_Registration($event_id, $collage_id, $student_id, $member_ids, $team_name, $type)
    {
        $result = $this->conn->query("SELECT * FROM `event_registration` WHERE `event_id` = $event_id AND `student_id` = $student_id");
        if ($result->num_rows > 0) {
            return "You Have Alredy Registerd In Thise Event !!";
        } elseif ($type === "solo") {
            $this->conn->query("INSERT INTO `event_registration` (`registration_id`, `college_id`, `student_id`, `member_id`, `event_id`, `registration_date`, `status`,`type`,`group_name`) 
            VALUES (NULL, '$collage_id', '$student_id', 'NULL', '$event_id', CURRENT_TIMESTAMP, 'Reject','SOLO','NULL')");
            return "Event Registerd Successfully Wait For Aprove From Your Collage !!";
        } else {
            $this->conn->query("INSERT INTO `event_registration` (`registration_id`, `college_id`, `student_id`, `member_id`, `event_id`, `registration_date`, `status`,`type`,`group_name`) 
            VALUES (NULL, '$collage_id', '$student_id', '$member_ids', '$event_id', CURRENT_TIMESTAMP, 'Reject','GROUP','$team_name')");
            return "Event Registerd Successfully Wait For Aprove From Your Collage !!.  Notification Send To You Gruop Member's !";
        }
    }
    public function Registration_event_details_select($event_id)
    {
        $sql = "SELECT * FROM event_registration WHERE `event_id` = $event_id ORDER BY event_id DESC";
        return $this->conn->query($sql);
    }
    public function Registerd_event_details($student_id)
    {
        $sql = "SELECT events.*,event_registration.* FROM events INNER JOIN event_registration ON events.event_id = event_registration.event_id WHERE event_registration.student_id = '$student_id';";
        return $this->conn->query($sql);
    }
    public function Event_Cancle($student_id, $event_id)
    {
        $sql = "DELETE FROM `event_registration` WHERE `student_id` = $student_id AND `event_id` = $event_id";
        if ($student_id == 0)
            $sql = "DELETE FROM `event_registration` WHERE `event_id` = $event_id";
        $this->conn->query($sql);
        return "Event Cancled Successfully !!";
    }
    public function count_total_Event($collage_id)
    {
        $result = $this->conn->query("SELECT COUNT(`event_id`) AS event_id FROM `events` WHERE `college_id` = '$collage_id'");
        $row = $result->fetch_assoc();
        return (int) $row['event_id'];
    }
    public function select_all_register_student($collage_id, $accepted)
    {
        if ($accepted != "Acept")
            $sql = "SELECT COUNT(student_id) AS total_student FROM event_registration WHERE college_id = $collage_id";
        else
            $sql = "SELECT COUNT(student_id) AS total_student FROM event_registration WHERE college_id = $collage_id AND status = 'Acept'";
        return $this->conn->query($sql);
    }
    public function selecte_event_all_student($collage_id)
    {
        $sql = "SELECT DISTINCT 
            sr.student_id, 
            sr.full_name, 
            sr.phone, 
            sr.email, 
            e.event_name, 
            e.event_date, 
            e.time, 
            er.*
        FROM `event_registration` AS er
        JOIN `events` AS e 
            ON er.event_id = e.event_id
        JOIN `student_registration` AS sr 
            ON er.student_id = sr.student_id
        WHERE er.college_id = $collage_id 
        AND e.college_id = $collage_id 
        AND sr.college_id = $collage_id 
        AND er.status = 'Accept'
        ORDER BY er.registration_id DESC;";
        return $this->conn->query($sql);
    }
    public function search_event_all_student($collage_id, $find)
    {
        $sql = "SELECT DISTINCT 
            sr.student_id, 
            sr.full_name, 
            sr.phone, 
            sr.email, 
            e.event_name, 
            e.event_date, 
            e.time, 
            er.*
        FROM `event_registration` AS er
        JOIN `events` AS e 
            ON er.event_id = e.event_id
        JOIN `student_registration` AS sr 
            ON er.student_id = sr.student_id
        WHERE
            sr.full_name LIKE '$find%' 
            OR sr.email LIKE '$find%' 
            OR sr.phone LIKE '$find%'
            OR e.event_name LIKE '$find%'
            OR e.event_date LIKE '$find%' 
            OR e.time LIKE '$find%' 
            OR er.type LIKE '$find%' 
            AND er.status = 'Accept'
            AND er.college_id = $collage_id  
        ORDER BY er.registration_id DESC;";
        return $this->conn->query($sql);
    }
    public function select_new_event_registration_request($collage_id)
    {
        $sql = "SELECT DISTINCT 
            sr.student_id, 
            sr.full_name, 
            sr.phone, 
            sr.email, 
            e.event_name, 
            e.event_date, 
            e.time, 
            er.*
        FROM `event_registration` AS er
        JOIN `events` AS e 
            ON er.event_id = e.event_id
        JOIN `student_registration` AS sr 
            ON er.student_id = sr.student_id
        WHERE er.college_id = $collage_id 
        AND e.college_id = $collage_id 
        AND sr.college_id = $collage_id 
        AND er.status = 'Reject'
        ORDER BY er.registration_id DESC;";
        return $this->conn->query($sql);
    }
    public function accept_event_requets($event_regi_id, $collage_id, $event_id, $sine)
    {
        if ($event_id == 0) {
            $this->conn->query("UPDATE `event_registration` SET `status` = 'Accept' WHERE `registration_id` = $event_regi_id AND `college_id` = $collage_id;");
            $notification = new notification();
            $notification->add_send_notification("Your Event Registration Request Accepted", 0, 0, $collage_id, 1);
            return "Request Accepted Successfully";
        } elseif ($event_id != 0) {
            $this->conn->query("UPDATE `event_registration` SET `status` = 'Accept' WHERE `event_id` = $event_id AND `college_id` = $collage_id;");
            return "All Request Accepted Successfully";
        }
    }
    public function getEventInfoById($event_id, $collage_id)
    {
        $result = $this->conn->query("SELECT COUNT(`event_id`) AS event_id FROM `events` WHERE `event_id` = $event_id AND college_id = $collage_id");
        $row = $result->fetch_assoc();
        return (int) $row['event_id'];
    }
    // following function used for remove event requested
    public function Remove_event_requets($event_regi_id, $collage_id, $event_id)
    {
        if ($event_id == 0) {
            $this->conn->query("UPDATE `event_registration` SET `status` = 'Accept' WHERE `registration_id` = $event_regi_id AND `college_id` = $collage_id;");
            return "Request Accepted Successfully";
        } elseif ($event_id != 0) {
            $this->conn->query("UPDATE `event_registration` SET `status` = 'Accept' WHERE `event_id` = $event_regi_id AND `college_id` = $collage_id;");
            return "All Request Accepted Successfully";
        }
    }
}

class galary extends Database
{
    function insert_image($image_name, $collage_id)
    {
        $this->conn->query("INSERT INTO `galary` (`image_id`, `collage_id`, `image_path`) VALUES (NULL, '$collage_id', '$image_name ');");
    }
    function select($collage_id)
    {
        return $this->conn->query("SELECT * FROM `galary` WHERE `collage_id` = $collage_id ORDER BY image_id DESC");
    }
    function DeleteAllImage($collage_id)
    {
        $this->conn->query("DELETE FROM `galary` WHERE `collage_id` = '$collage_id'");
        return "All Image Deleted Successfully !!";
    }
}

class Collage extends Database
{
    public function New_Collage_Register($college_name, $university_name, $collage_code, $address, $city, $state, $pincode, $contact, $email, $password, $principal_name, $total_students, $code)
    {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("INSERT INTO `college_register` 
    (`college_name`, `university_name`, `college_code`, `address`, `city`, `state`, `pincode`, `phone`, `email`, `password`, `principal_name`, `total_students`, `Status`, `system_code`, `registration_date`) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Reject', ?, CURRENT_TIMESTAMP)");

        // 3. Bind the variables (s = string, i = integer)
        $stmt->bind_param(
            "sssssssssssss",
            $college_name,
            $university_name,
            $collage_code,
            $address,
            $city,
            $state,
            $pincode,
            $contact,
            $email,
            $hashed_password,
            $principal_name,
            $total_students,
            $code
        );
        $stmt->execute();
        return "Registration Successfully, Please wait for admin approval. A unique code will be provide provided to you by our system. Share this code with your students, only then students will be able to register";
    }
    public function Update($collage_name, $univercity_name, $address, $city, $state, $pincode, $phone, $email, $principle_name, $total_student, $collage_id)
    {
        $sql = "UPDATE `college_register` SET `college_name` = '$collage_name', `university_name` = '$univercity_name',
            `address` = '$address', `city` = '$city', `state` = '$state', `pincode` = '$pincode',
            `phone` = '$phone', `email` = '$email', `principal_name` = '$principle_name', `total_students` = '$total_student',
            `Status` = 'accept' WHERE `college_id` = $collage_id;";
        $this->conn->query($sql);
        return "Updation Saved Successfully !!";
    }
    public function update_password($email, $newPassword)
    {
        $this->conn->query("UPDATE `college_register` SET `password` = '$newPassword' WHERE `email` = '$email';");
        if ($this->conn->affected_rows > 0)
            return 1;
    }
    public function Selete($collage_id)
    {
        if ($collage_id == 0)
            $sql = "SELECT * FROM `college_register` WHERE `Status` = 'accept' ORDER BY `college_id` DESC ";
        elseif ($collage_id == 1)
            $sql = "SELECT * FROM `college_register` WHERE `Status` = 'Reject' ORDER BY `college_id` DESC";
        else
            $sql = "SELECT * FROM `college_register` WHERE `college_id` = $collage_id";
        return $this->conn->query($sql);
    }
    public function Select_login_details($username, $password)
    {
        $result = $this->conn->query("SELECT COUNT(`college_id`) AS college_id,`password` FROM `college_register` WHERE `email` = '$username' AND `Status` = 'accept'");
        $row = $result->fetch_assoc();
        if (!empty($row['password'])) {
            if (password_verify($password, $row['password']))
                return (int) $row['college_id'];
        }
    }
    public function Check_Request_Aprove_Or_Not($username, $password)
    {
        $result = $this->conn->query("SELECT COUNT(`college_id`) AS collage_id FROM `college_register` WHERE `email` = '$username' AND `password` = '$password' AND `Status` = 'Reject'");
        $row = $result->fetch_assoc();
        return (int) $row['collage_id'];
    }
    public function Search($find, $status)
    {
        $cond = ($status == "Reject") ? "'Reject'" : "'accept'";
        $query = "SELECT * FROM `college_register` WHERE (
            `college_id` LIKE '$find%' OR `college_name` LIKE '$find%' OR `university_name` LIKE '$find%' OR 
            `college_code` LIKE '$find%' OR `address` LIKE '$find%' OR `city` LIKE '$find%' OR 
            `state` LIKE '$find%' OR `pincode` LIKE '$find%' OR `phone` LIKE '$find%' OR 
            `email` LIKE '$find%' OR `principal_name` LIKE '$find%' OR `total_students` LIKE '$find%' OR 
            `system_code` LIKE '$find%' OR `registration_date` LIKE '$find%'
        ) AND `Status` = $cond ORDER BY `college_id` DESC";
        return $this->conn->query($query);
    }
    public function getId($email)
    {
        $result = $this->conn->query("SELECT * FROM college_register WHERE `email`= '$email' AND `Status` = 'accept'");
        if ($row = $result->fetch_assoc()) {
            return (int) $row['college_id'];
        }
        return 0;
    }
    function getCollegeNameByCode($code)
    {
        $result = $this->conn->query("SELECT college_name,college_id FROM `college_register` WHERE `system_code` = '$code' AND `Status` = 'accept' ;");
        return $result;
    }
    public function Delete($collage_id)
    {
        $this->conn->query("DELETE FROM college_register WHERE `college_id` = '$collage_id'");
    }
    public function countAllCollage($sine)
    {
        if ($sine == "Reject")
            $result = $this->conn->query("SELECT COUNT(`college_id`) AS college_id FROM `college_register` WHERE `Status` = 'Reject'");
        else
            $result = $this->conn->query("SELECT COUNT(`college_id`) AS college_id FROM `college_register` WHERE `Status` = 'accept'");
        $row = $result->fetch_assoc();
        return (int) $row['college_id'];
    }
}

class Student extends Database
{
    function Student_registration($name, $gender, $course, $year, $semester, $roll_no, $college_id, $image, $email, $contact, $password)
    {
        $query = "INSERT INTO `student_registration` (`student_id`, `full_name`, `roll_number`, `college_id`, `course`, `year`, `semester`, `gender`, `image`, `email`, `phone`, `password`, `registration_date`) VALUES (NULL, '$name', '$roll_no', '$college_id', '$course', '$year', '$semester', '$gender', '$image', '$email', '$contact', '$password', CURRENT_TIMESTAMP)";

        $this->conn->query($query);
        return "You Have Successfully Registerd !";
    }
    public function Update($collage_id, $student_id, $student_name, $roll_no, $year, $semester, $Image, $contact, $email)
    {
        $sql = "UPDATE `student_registration` SET `full_name` = '$student_name', `roll_number` = '$roll_no', `year` = '$year',
        `semester` = '$semester', `image` = '$Image', `email` = '$email', `phone` = '$contact' WHERE `student_id` = $student_id AND `college_id` = $collage_id";
        $this->conn->query($sql);
        return "Your Record Updated Successfully !!";
    }

    public function update_password($email, $newPassword)
    {
        $this->conn->query("UPDATE `student_registration` SET `password` = '$newPassword' WHERE `email` = '$email';");
        if ($this->conn->affected_rows > 0)
            return 1;
    }

    public function Selete($collage_id)
    {
        if ($collage_id > 0)
            return $this->conn->query("SELECT * FROM student_registration WHERE college_id = '$collage_id'");
        else
            return $this->conn->query("SELECT * FROM student_registration");
    }

    public function Select_login_details($username, $password)
    {
        $result = $this->conn->query("SELECT COUNT(`student_id`) AS student_id,`password` FROM `student_registration` WHERE `email` = '$username'");
        $row = $result->fetch_assoc();
        if (!empty($row['password'])) {
            if (password_verify($password, $row['password']))
                return (int) $row['student_id'];
        }
    }

    public function Search($collage_id, $find)
    {
        return $this->conn->query("SELECT * FROM student_registration WHERE college_id = '$collage_id' AND student_id LIKE '$find%' 
        OR full_name LIKE '$find%' OR roll_number LIKE '$find%' OR course LIKE '$find%' OR `year` LIKE '$find%' OR gender LIKE '$find%'
        OR email LIKE '$find%' OR gender LIKE '$find%' OR email LIKE '$find%' OR phone LIKE '$find%'");
    }

    public function Delete($student_id, $collage_id)
    {
        $sql = ($student_id == 0) ? "DELETE FROM `student_registration` WHERE `college_id` = '$collage_id'" : "DELETE FROM `student_registration` WHERE `college_id` = $collage_id AND student_id = $student_id";
        $this->conn->query($sql);
    }

    public function getId($email)
    {
        $result = $this->conn->query("SELECT * FROM `student_registration` WHERE `email` = '$email'");
        if ($row = $result->fetch_assoc())
            return (int) $row['student_id'];
        return 0;
    }

    public function getCollageId($email)
    {
        $result = $this->conn->query("SELECT * FROM `student_registration` WHERE `email` = '$email'");
        if ($row = $result->fetch_assoc())
            return (int) $row['college_id'];
        return 0;
    }
    public function getNameById($id)
    {
        return $this->conn->query("SELECT * FROM `student_registration` WHERE `student_id` = '$id'");
    }

    public function view_profile($email, $collage_id)
    {
        $sql = ($collage_id != 0) ? "SELECT college_register.college_name,student_registration.* FROM college_register,student_registration WHERE student_registration.email = '$email' AND college_register.college_id = $collage_id" : "SELECT * FROM student_registration WHERE email = '$email'";
        return $this->conn->query($sql);
    }

    public function count_total_student($collage_id)
    {
        $result = $this->conn->query("SELECT COUNT(`student_id`) AS sid FROM `student_registration` WHERE `college_id` = '$collage_id'");
        $row = $result->fetch_assoc();
        return (int) $row['sid'];
    }

    public function SelectAllStudent($find)
    {
        if (!empty($find) || $find != 0)
            return $this->conn->query("SELECT *FROM student_registration s,college_register c WHERE s.college_id = c.college_id AND s.student_id LIKE '$find%' 
        OR s.full_name LIKE '$find%' OR s.roll_number LIKE '$find%' OR s.course LIKE '$find%' OR s.`year` LIKE '$find%' OR s.gender LIKE '$find%'
        OR s.email LIKE '$find%' OR s.gender LIKE '$find%' OR s.email LIKE '$find%' OR s.phone LIKE '$find%'");
        else
            return $this->conn->query("SELECT *FROM student_registration s,college_register c WHERE s.college_id = c.college_id");
    }
}

class Orgenizer extends Database
{
    public function Insert_new_Orgenizer($full_name, $comapny_name, $email, $phone, $bio, $experience, $address, $logo_path, $password)
    {
        $insert = $this->conn->prepare("INSERT INTO organizer (full_name, comapny_name, email, phone, bio, experience, address, compny_logo, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insert->bind_param("sssssssss", $full_name, $comapny_name, $email, $phone, $bio, $experience, $address, $logo_path, $password);
        $insert->execute();
        $insert->close();
        return "You Have Successfully Regisited";
    }
    public function Selete($orgenizer_id)
    {
        $sql = ($orgenizer_id == 0) ? "SELECT * FROM `organizer`;" : "SELECT * FROM `organizer` WHERE `organizer_id` = '$orgenizer_id'";
        return $this->conn->query($sql);
    }
    public function Select_login_details($username, $password)
    {
        $result = $this->conn->query("SELECT COUNT(`organizer_id`) AS organizer_id,`password` FROM `organizer` WHERE `email` = '$username'");
        $row = $result->fetch_assoc();
        if (!empty($row['password'])) {
            if (password_verify($password, $row['password']))
                return (int) $row['organizer_id'];
        }
    }
    public function update_password($email, $newPassword)
    {
        $this->conn->query("UPDATE `organizer` SET `password` = '$newPassword' WHERE `email` = '$email';");
        if ($this->conn->affected_rows > 0)
            return 1;
    }
    public function updateOrgenizerDetails($name, $comapny_name, $phone, $address, $experience, $about, $image_name, $orgenizer_id)
    {
        $insert = $this->conn->prepare("UPDATE organizer SET full_name = ?,  comapny_name = ?,   phone = ?,   bio = ?,   experience = ?,   address = ?,   compny_logo = ? WHERE organizer_id = ? ");
        $insert->bind_param("ssssssss", $name, $comapny_name, $phone, $about, $experience, $address, $image_name, $orgenizer_id);
        $insert->execute();
        $insert->close();
        return "Updation Saved Successfully !!";
    }
    public function getId($email, $mobile_number)
    {
        if ($mobile_number === 0)
            $result = $this->conn->query("SELECT * FROM `organizer` WHERE `email` = '$email'");
        else
            $result = $this->conn->query("SELECT * FROM `organizer` WHERE `email` = '$email' OR `phone` = '$mobile_number' ");
        if ($row = $result->fetch_assoc())
            return (int) $row['organizer_id'];
        return 0;
    }
    public function getOrgenizerDetails($email)
    {
        return $this->conn->query("SELECT * FROM `organizer` WHERE `email` = '$email'");
    }
    public function getResourseDetails($orgenizer_id)
    {
        return $this->conn->query("SELECT * FROM `resource` WHERE `orgenizer_id` = '$orgenizer_id' AND `status` = 'Available' ");
    }
    public function countTotalOrgenizer()
    {
        $result = $this->conn->query("SELECT COUNT(`organizer_id`) AS organizer_id FROM `organizer`");
        $row = $result->fetch_assoc();
        return (int) $row['organizer_id'];
    }
}
class payment extends Database
{
    public function addPaymentCollageToOrg($collage_id, $orgenizer_id, $total, $payment_method, $status, $tx_id, $today, $payment_time)
    {
        $this->conn->query("INSERT INTO payments (college_id, organizer_id, amount, payment_method, payment_status, transaction_reference, payment_date, payment_time) 
        VALUES ($collage_id, $orgenizer_id, $total, '$payment_method', '$status', '$tx_id', '$today', '$payment_time')");
        if ($this->conn->affected_rows > 0)
            return true;
        else
            return false;
    }

    public function paymentHistory($organizer_id, $college_id)
    {
        if ($organizer_id != 0) { // select payment history of the orgenizer
            return $this->conn->query("SELECT 
                p.payment_id,
                c.college_name, 
                p.amount,
                p.payment_method,
                p.payment_status,
                p.transaction_reference,
                p.payment_date,
                p.payment_time
            FROM payments p
            JOIN college_register c ON p.college_id = c.college_id
            WHERE p.organizer_id = $organizer_id
            ORDER BY p.payment_date DESC, p.payment_time DESC");
        } else { // select hostory of the an collage 
            return $this->conn->query("SELECT 
                p.payment_id,
                o.full_name AS organizer_name,
                o.comapny_name,
                p.amount,
                p.payment_method,
                p.payment_status,
                p.transaction_reference,
                p.payment_date,
                p.payment_time
            FROM payments p
            JOIN organizer o ON p.organizer_id = o.organizer_id
            WHERE p.college_id = $college_id
            ORDER BY p.payment_date DESC, p.payment_time DESC;");
        }
    }
    public function searchPaymentHistory($organizer_id, $college_id, $payment_status)
    {
        if ($organizer_id != 0) { // searcg payment history by status...................................
            return $this->conn->query("SELECT 
                p.payment_id,
                c.college_name, 
                p.amount,
                p.payment_method,
                p.payment_status,
                p.transaction_reference,
                p.payment_date,
                p.payment_time
            FROM payments p
            JOIN college_register c ON p.college_id = c.college_id
            WHERE p.organizer_id = $organizer_id AND p.payment_status = '$payment_status'
            ORDER BY p.payment_date DESC, p.payment_time DESC");
        } else { // select hostory of the an collage 
            return $this->conn->query("SELECT 
                p.payment_id,
                o.full_name AS organizer_name,
                o.comapny_name,
                p.amount,
                p.payment_method,
                p.payment_status,
                p.transaction_reference,
                p.payment_date,
                p.payment_time
            FROM payments p
            JOIN organizer o ON p.organizer_id = o.organizer_id
            WHERE p.college_id = $college_id  AND p.payment_status = '$payment_status'
            ORDER BY p.payment_date DESC, p.payment_time DESC;");
        }
    }
}

class admin extends Database
{
    public function Select_login_details($username, $password)
    {
        $result = $this->conn->query("SELECT COUNT(`admin_id`) AS admin_id,`password` FROM `admin` WHERE `email` = '$username'");
        $row = $result->fetch_assoc();
        if (!empty($row['password'])) {
            if (password_verify($password, $row['password']))
                return (int) $row['admin_id'];
        }
    }
    public function update_password($email, $newPassword)
    {
        $this->conn->query("UPDATE `admin` SET `password` = '$newPassword' WHERE `email` = '$email';");
        if ($this->conn->affected_rows > 0)
            return 1;
    }
    public function Accept_Reject_Collage_Request($collage_id, $status)
    {
        if ($status == "accept") {
            $this->conn->query("UPDATE `college_register` SET `Status` = 'accept' WHERE`college_id` = '$collage_id';");
            $result = $this->conn->query("SELECT email,system_code FROM `college_register` WHERE`college_id` = $collage_id;");
            $row = $result->fetch_assoc();
            require_once('C:\wamp64\www\student event managemant system\controller\operation.php');
            $send_main = new verifyEmail();
            $send_main->send_email($row['email'], $row['system_code'], "Request_accept");
            // here add code for send email to the collage with code ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            return "Collage Request Accepted Successfully !!";
        } else {
            $this->conn->query("DELETE FROM `college_register` WHERE`college_id` = '$collage_id';");
            return "Collage Request Unaccept Or Deleted From The Record Successfully !!";
        }
    }
    public function getId($email)
    {
        $result = $this->conn->query("SELECT * FROM `admin` WHERE `email` = '$email'");
        if ($row = $result->fetch_assoc())
            return (int) $row['admin_id'];
        return 0;
    }
}

class feedback extends Database
{
    public function Add_Feedback($student_id, $event_id, $rating, $comments)
    {
        $this->conn->query("INSERT INTO `event_feedback` (`feedback_id`, `student_id`, `event_id`, `rating`, `comments`, `feedback_date`) VALUES (NULL, '$student_id', '$event_id', '$rating', '$comments', CURRENT_TIMESTAMP);");
    }
    public function Remove_Feedback($feedback_id, $collage_id, $remove_all)
    {
        if ($remove_all != 0)  //  remove only specific feedback which choose by collage user 
            $sql = "DELETE FROM `event_feedback` WHERE college_id = $collage_id";
        else // remove all feedback of that specific collage 
            $sql = "DELETE FROM `event_feedback` WHERE college_id = $collage_id AND feedback_id = $feedback_id";

        $this->conn->query($sql);
        return "Feeback Removed Successfully";
    }
    public function select_FeedBack($collage_id)
    {
        $sql = "SELECT DISTINCT  student_registration.full_name,events.event_name, event_feedback.* FROM `student_registration`,`events`,`event_feedback` WHERE event_feedback.college_id = $collage_id AND event_feedback.event_id = events.event_id AND events.college_id = $collage_id AND student_registration.college_id = $collage_id ORDER BY feedback_id DESC";
        return $this->conn->query($sql);
    }
    public function Search_Feedback($collage_id, $find) // invalid sql query need to fix and solving problums 
    {
        $sql = "SELECT DISTINCT  student_registration.full_name,events.event_name, event_feedback.* FROM `student_registration`,`events`,`event_feedback` WHERE event_feedback.college_id = $collage_id AND event_feedback.event_id = events.event_id AND events.college_id = $collage_id AND student_registration.college_id = $collage_id ORDER BY feedback_id DESC";
        return $this->conn->query($sql);
    }
}

class notification extends Database
{
    public function add_send_notification($information, $organizer_id, $student_id, $collage_id, $sine)
    {
        $target_student = 0;
        $target_organizer = 0;
        $target_collage = $collage_id;

        switch ($sine) {
            case 'CollageToOrg':
                $target_organizer = $organizer_id;
                break;

            case 'orgToCollage':
                $target_organizer = $organizer_id;
                break;

            case '0':
                break;

            case '1':
                $target_student = $student_id;
                break;

            default:
                return false;
        }

        // Single sanitized query
        $query = "INSERT INTO `notification` 
              (`notification_id`, `collage_id`, `student_id`, `orgenizer_id`, `sine`, `information`, `date`) 
              VALUES (NULL, '$target_collage', '$target_student', '$target_organizer', '$sine', '$information', CURRENT_TIMESTAMP)";

        return $this->conn->query($query);
    }
    public function select_notification($collage_id, $student_id, $sine)
    {
        if ($student_id == 0) { //select collage notification recive by orgenizer and admin
            $sql = "SELECT * FROM `notification` WHERE `collage_id` = $collage_id AND `student_id` = 0 AND `sine` = 'orgToCollage' OR `sine` = 0;";
            return $this->conn->query($sql);
        } else { // select notification from collage to student
            $sql = "SELECT * FROM `notification` WHERE `collage_id` = $student_id AND `student_id` = 0 AND `sine` = 0;";
        }
    }
    public function Delete_notification($collage_id, $notification_id)
    {
        if ($notification_id == 0) // delete all notification of the collage
            $sql = "DELETE FROM notification WHERE collage_id = $collage_id";
        else // delete specific notification of the collage
            $sql = "DELETE FROM notification WHERE collage_id = $collage_id AND notification_id = $notification_id";

        $this->conn->query($sql);
        return "Notification Deleted Successfully";
    }
    public function getNotificationOfOrgenizer($orgenizer_id)
    {
        return $this->conn->query("SELECT *FROM notification WHERE orgenizer_id = $orgenizer_id AND sine = 'CollageToOrg'");
    }
}
class resource_manage extends Database
{
    public function AddNewResource($organizer_id, $resource_name, $resource_type, $capacity, $price, $status, $details, $image_name)
    {
        $this->conn->query("INSERT INTO `resource` (`resource_id`, `orgenizer_id`, `resource_name`, `resource_type`, `capacity`, `status`, `price`, `details`, `image`) 
        VALUES (NULL, '$organizer_id', '$resource_name', '$resource_type', '$capacity', '$status', '$price', '$details', '$image_name')");
        return "New Resourse Added Successfully !!";
    }
    public function selectAllocatedResourseCollages($orgenizer_id)
    {
        return $this->conn->query("SELECT 
            b.booking_id,
            c.college_name, 
            r.resource_name, 
            r.resource_type, 
            r.capacity, 
            r.price, 
            b.status 
        FROM college_register AS c, resource AS r, booking AS b WHERE c.college_id = b.college_id AND r.resource_id = b.resource_id AND b.organizer_id = $orgenizer_id ORDER BY booking_id DESC");
    }
    public function searchByStatus($orgenizer_id, $status)
    {
        return $this->conn->query("SELECT
            c.college_name, 
            r.resource_name, 
            r.resource_type, 
            r.capacity, 
            r.price, 
            b.status 
        FROM college_register AS c, resource AS r, booking AS b WHERE c.college_id = b.college_id AND r.resource_id = b.resource_id AND b.organizer_id = $orgenizer_id AND b.status = '$status' ORDER BY booking_id DESC");
    }
    public function getResourseDtailsByOrgenizerId($orgenizer_id)
    {
        return $this->conn->query("SELECT *FROM resource WHERE orgenizer_id = '$orgenizer_id' ORDER BY resource_id DESC");
    }
    public function searchResourseDtailsByOrgenizerId($orgenizer_id, $status)
    {
        return $this->conn->query("SELECT *FROM resource WHERE orgenizer_id = '$orgenizer_id' AND status = '$status' ORDER BY resource_id DESC");
    }
    public function updateResourseStatusByOrgenizer($orgenizer_id, $status, $resourse_id)
    {
        $this->conn->query("UPDATE resource SET status = '$status' WHERE  orgenizer_id = '$orgenizer_id' AND resource_id = '$resourse_id'");
        return "Resource  Updated Successfully !!";
    }
    public function deleteResourseByOrgenizer($orgenizer_id, $resourse_id)
    {
        $stmt = $this->conn->prepare("DELETE FROM resource WHERE orgenizer_id = ? AND resource_id = ?");
        $stmt->bind_param("ss", $orgenizer_id, $resourse_id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            return "Resource Removed Successfully !!";
        } else {
            return "Resource already booked !!";
        }
    }
}
class booking extends Database
{
    function newResourseBooking($organizer_id, $event_id, $college_id, $resource_id, $booking_date, $booking_date_end, $other_requerment, $address)
    {
        $this->conn->query("INSERT INTO `booking` (`booking_id`, `organizer_id`, `event_id`, `college_id`, `resource_id`, `booking_date`, `booking_date_end`, `other_requerment`, `address`, `status`) 
            VALUES (NULL, '$organizer_id', $event_id, '$college_id', '$resource_id', '$booking_date', '$booking_date_end', '$other_requerment', '$address', 'Request');");
        return "Order Booked Successfully";
    }
    function select_booking_info($collage_id)
    {
        $query = "SELECT 
            b.booking_id,
            e.event_name,
            r.resource_name,
            o.full_name,
            b.booking_date,
            b.booking_date_end,
            b.other_requerment,
            b.status
        FROM booking b
        JOIN events e ON b.event_id = e.event_id
        JOIN resource r ON b.resource_id = r.resource_id
        JOIN organizer o ON b.organizer_id = o.organizer_id
        WHERE b.college_id = $collage_id 
        ORDER BY b.booking_id DESC;";
        return $this->conn->query($query);
    }
    function totol_booking_count($collage_id)
    {
        $result = $this->conn->query("SELECT COUNT(`booking_id`) AS booking_id FROM booking WHERE college_id = $collage_id");
        $row = $result->fetch_assoc();
        return (int) $row['booking_id'];

    }
    function search_booking_info($search, $collage_id)
    {

        $query = "SELECT 
            b.booking_id,
            e.event_name,
            r.resource_name,
            o.full_name,
            b.booking_date,
            b.booking_time,
            b.purpose,
            b.status
          FROM booking b
          JOIN events e ON b.event_id = e.event_id
          JOIN resource r ON b.resource_id = r.resource_id
          JOIN organizer o ON b.organizer_id = o.organizer_id
          WHERE b.college_id = $collage_id
          AND (
            e.event_name LIKE '%$search%' OR
            r.resource_name LIKE '%$search%' OR
            o.full_name LIKE '%$search%' OR
            b.purpose LIKE '%$search%'
          )";
        return $this->conn->query($query);
    }
    function delete_booking_info($booking_id, $collage_id)
    {
        if ($booking_id == 0) {
            $this->conn->query("DELETE FROM booking WHERE college_id = $collage_id");
        } else {
            $this->conn->query("DELETE FROM booking WHERE college_id = $collage_id AND booking_id = $booking_id");
        }
        return "Notification Deleted Successfully !!";
    }
    function manageBookingStatus($sine, $collage_id, $booking_id, $status) // manage all type status from both  user collage and orgenizer
    {
        $this->conn->query("UPDATE `booking` SET `status` = '$status' WHERE `booking_id` = $booking_id;");
        return "Booking Status Updated Successfully !!";
        $notification = new notification();
        if ($sine == "orgToCollage") {
            $notification->add_send_notification("Your Request " . $status . " By Orgenizer", $collage_id, $sine);
        }
    }
    function select_new_booking_request_info_for_orgenizer($orgenizer_id)
    {
        return $this->conn->query("SELECT 
            b.booking_id,
            b.booking_date,
            b.booking_date_end,
            b.other_requerment,
            b.address,
            c.college_id,
            c.principal_name,
            c.college_name,
            c.phone,     
            e.event_name,
            e.event_category,
            r.resource_name
        FROM booking AS b
        INNER JOIN college_register AS c ON b.college_id = c.college_id
        INNER JOIN events AS e ON b.event_id = e.event_id
        INNER JOIN resource AS r ON b.resource_id = r.resource_id
        WHERE b.organizer_id = $orgenizer_id AND b.status = 'Request' ORDER BY booking_id DESC");
    }

}

class Contact_us extends Database
{
    public function addContactByOrgenizer($orgenizer_id, $message)
    {
        $this->conn->query("INSERT INTO `contact_messages` (`id`, `student_id`, `organizer_id`, `college_id`, `message`, `created_at`) 
        VALUES (NULL, NULL, '$orgenizer_id', NULL, '$message', CURRENT_TIMESTAMP)");
        return "Contact Send Successfully Waiting For Response From Us";
    }
}

?>