-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 19, 2026 at 10:13 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_event_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$gqhjs1wNpUIi8eoMk1GDD.US3bul/671kEY6ZVn47S3jvnVZDEcK6');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `organizer_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `college_id` int DEFAULT NULL,
  `resource_id` varchar(50) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `booking_date_end` date DEFAULT NULL,
  `other_requerment` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `address` varchar(100) NOT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  PRIMARY KEY (`booking_id`),
  KEY `booking_ibfk_1` (`college_id`),
  KEY `booking_ibfk_2` (`event_id`),
  KEY `booking_ibfk_3` (`organizer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `college_register`
--

DROP TABLE IF EXISTS `college_register`;
CREATE TABLE IF NOT EXISTS `college_register` (
  `college_id` int NOT NULL AUTO_INCREMENT,
  `college_name` varchar(200) NOT NULL,
  `university_name` varchar(150) DEFAULT NULL,
  `college_code` varchar(20) NOT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `principal_name` varchar(100) DEFAULT NULL,
  `total_students` int NOT NULL,
  `Status` varchar(10) NOT NULL DEFAULT 'Reject',
  `system_code` varchar(10) NOT NULL,
  `registration_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`college_id`),
  UNIQUE KEY `college_code` (`college_code`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_register`
--

INSERT INTO `college_register` (`college_id`, `college_name`, `university_name`, `college_code`, `address`, `city`, `state`, `pincode`, `phone`, `email`, `password`, `principal_name`, `total_students`, `Status`, `system_code`, `registration_date`) VALUES
(3, 'smt css shah bca collage deesa', 'hngu patan', 'hngu25418', 'kachhi koloni collage road deesa', 'deesa', 'Gujrat', '385535', '7856941230', 'ubhatiya907@gmail.com', '$2y$10$Q6iglDXduXexnwpN9BB/Ou0wivcR9JTxts5hkdy858U9OJggY1b5i', 'prof Hitesh Modth', 350, 'accept', 'SEMS120', '2026-03-02 16:20:03'),
(5, 'DNP ART AND COMMERCE COLLAGE DEESA', 'HNGU', 'hngu25414', 'kachhi coloni collage road,deesa,385535,banasknatha,gujrat', 'deesa', 'Gujarat', '385535', '7896325410', 'dnp@gmail.com', '123', 'Dr Arti Patel', 0, 'accept', 'SEMS125', '2026-03-05 06:21:14'),
(6, 'SMT CSS SHAH  BCA COLLAGE DEESA', 'HNGU', '78009op', 'deesa ', 'deesa', 'gujarat', '385535', '7896523410', 'smt@gmail.com', 'Uttam@12345', 'Mr Hitesh Modth', 350, 'accept', 'SEMS120', '2026-03-27 12:54:27'),
(7, '', 'd', 'd', 'DEESA\r\nDEESA ', 'DEESA', 'Goa', '385535', '4785693210', 'ucbhatiya6@gmail.com', '$2y$10$iRdy/Z9GYb0ccen2tiWhd.PN/z1gjY0sXsmzfSnpoJT86Esn91EGi', 'BHATIYA UTTAMKUMAR CHHAGANBHAI', 0, 'Reject', 'SEMScode55', '2026-03-27 13:02:43'),
(13, 'DNP ART AND COMMERCE COLLAGE DEESA', 'hngu', '789654', 'Deesa ', 'DEESA', 'Gujarat', '385535', '0123456789', 'dnpDeesa@gmail.com', 'Uttam@12345', 'Dr Arti Patel', 3500, 'accept', 'SEMScodeDD', '2026-03-27 13:12:57'),
(14, 'deesa collage', 'patan hngu', '78955', 'deesa bk palnpur ', 'deesa', 'gujrat', '385535', '7896325410', 'deesa@gmail.com', 'Uttam@12345', 'Uttam Bhatiya', 588, 'accept', 'SEMScode63', '2026-04-09 15:18:33'),
(20, 'deesa collage', 'patan hngu', '7895', 'palnpur ', 'deesa', 'gujrat', '385535', '7896325411', 'dsa@gmail.com', 'Uttam@12345', 'Uttam Bhatiya', 588, 'accept', 'SEMScode4E', '2026-04-09 15:29:35'),
(21, 'deesa collage', 'patan hngu', '789588', 'deesa ', 'deesa', 'gujrat', '385535', '7896325411', 'clg@gmail.com', 'Uttam@12345', 'Uttam Bhatiya', 588, 'accept', 'SEMScode96', '2026-04-09 15:32:16'),
(23, 'SMT CSS SHAH BCA COLLAGE DEESA', 'HNGU PATAN', 'HNGU456321', 'kachi coloni collage road deesa', 'deesa', 'gujrat', '385535', '7788996655', 'smtCSS@gmail.com', '$2y$10$99Mtvqcl33TDP7rrPmvXqOG/2KkrKwb1pk0lnAwf7Dc3Q2D0dtnnu', 'Mr Hitesh Maith', 250, 'Reject', 'SEMS7855', '2026-04-12 08:52:09'),
(24, 'AP Trivedi Collage', 'HNGU Patan', 'hngu21', 'tharad tharad', 'Tharad', 'Gujarat', '385566', '7410258963', 'ap@gmail.com', '$2y$10$G/V4B1SRzCpcQ6TUYgYS.uIC5wUwZ396bTJCOK/piO.nK.ksrqlyi', 'uttam bhatiya', 210, 'Reject', 'SEMSF3D098', '2026-04-12 10:18:54'),
(25, 'AP Trivedi Collage', 'HNGU Patan', 'hngu22', 'tharad tharad', 'Tharad', 'Gujarat', '385566', '7210258963', 'apl@gmail.com', '$2y$10$4x4CCx4D/cmGUb5BEgvVjuko5CghwPdxfhueO6JBjo9Al5lDTS1qa', 'uttam bhatiya', 210, 'Reject', 'SEMS551D22', '2026-04-12 10:20:00'),
(26, 'SMT CSS SHAH BCA COLLAGE DEESA', 'HNGU PATAN', 'HNGU2135', 'Deesa, Gujarat, ', 'Deesa', 'Gujarat', '385535', '9966332211', 'aryanm.patel71@gmail.com', '$2y$10$O5TAiT/EkovgTK/smf9WjejCwzXVDjaTGMHqy5KtB1UVrpcxvvp/q', 'JAY MODI', 585, 'accept', 'SEMSF78F9D', '2026-04-18 10:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `organizer_id` int DEFAULT NULL,
  `college_id` int DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_student` (`student_id`),
  KEY `fk_organizer` (`organizer_id`),
  KEY `fk_college` (`college_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `student_id`, `organizer_id`, `college_id`, `message`, `created_at`) VALUES
(1, NULL, 8, NULL, 'have generate issue to transfer money', '2026-04-17 09:20:27'),
(2, NULL, 8, NULL, 'WonderFull, Your System, Only Generate issue when login', '2026-04-17 09:28:52'),
(3, NULL, 8, NULL, 'WonderFull, Your System, Only Generate issue when login', '2026-04-17 09:31:09');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `event_description` text,
  `event_date` date NOT NULL,
  `venue` varchar(200) DEFAULT NULL,
  `college_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time` time NOT NULL,
  `event_image` varchar(200) NOT NULL,
  `status` varchar(25) DEFAULT NULL,
  `capacity` varchar(10) NOT NULL,
  `registration_type` varchar(7) DEFAULT NULL,
  `event_category` varchar(50) NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `college_id` (`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_description`, `event_date`, `venue`, `college_id`, `created_at`, `time`, `event_image`, `status`, `capacity`, `registration_type`, `event_category`) VALUES
(21, 'TREDITIONAL DAY', 'we can celebrate traditional day in our collage, all student must wear traditional coolths which you have any ', '2026-03-07', 'collage', 3, '2026-03-06 06:26:35', '08:00:00', 'InShot_20260130_180106938.jpg', 'upcomming', '10', 'solo', ''),
(23, 'SPORTS DAY', 'we can celebrate sports day in our collage, all student must wear traditional coolths which you have any ', '2026-03-07', 'collage', 3, '2026-03-07 04:32:56', '23:02:00', 'IMG_20260129_051738_140.webp', 'upcomming', '0', NULL, ''),
(24, 'Ambedkar Jayni', 'we can celibrate ambedket jaynti in 14 april', '2026-04-14', 'collage hall', 3, '2026-04-14 17:23:33', '09:00:00', 'IMG-20240103-WA0004.jpg', NULL, '', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `event_feedback`
--

DROP TABLE IF EXISTS `event_feedback`;
CREATE TABLE IF NOT EXISTS `event_feedback` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `event_id` int NOT NULL,
  `rating` varchar(5) DEFAULT NULL,
  `comments` text,
  `feedback_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `college_id` int DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `student_id` (`student_id`),
  KEY `event_id` (`event_id`),
  KEY `event_feedback_ibfk_3` (`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_registration`
--

DROP TABLE IF EXISTS `event_registration`;
CREATE TABLE IF NOT EXISTS `event_registration` (
  `registration_id` int NOT NULL AUTO_INCREMENT,
  `college_id` int NOT NULL,
  `student_id` int NOT NULL,
  `event_id` int NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL DEFAULT 'Registered',
  `type` varchar(7) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `group_name` varchar(25) DEFAULT NULL,
  `member_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`registration_id`),
  UNIQUE KEY `student_id` (`student_id`,`event_id`),
  KEY `event_id` (`event_id`),
  KEY `event_registration_ibfk_3` (`college_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `galary`
--

DROP TABLE IF EXISTS `galary`;
CREATE TABLE IF NOT EXISTS `galary` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `collage_id` int NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `event_id` int NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `collage_id` (`collage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `collage_id` int NOT NULL,
  `student_id` int NOT NULL,
  `orgenizer_id` int NOT NULL,
  `sine` varchar(25) NOT NULL,
  `information` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`,`collage_id`),
  KEY `notification_ibfk_1` (`collage_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

DROP TABLE IF EXISTS `organizer`;
CREATE TABLE IF NOT EXISTS `organizer` (
  `organizer_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `comapny_name` varchar(30) NOT NULL,
  `compny_logo` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rating` int DEFAULT '0',
  `bio` varchar(50) NOT NULL,
  `experience` varchar(10) NOT NULL,
  PRIMARY KEY (`organizer_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `college_id` int NOT NULL,
  `organizer_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('UPI','Card','NetBanking','Cash') DEFAULT 'UPI',
  `payment_status` enum('Pending','Completed','Failed') DEFAULT 'Pending',
  `transaction_reference` varchar(100) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `payment_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `transaction_reference` (`transaction_reference`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `college_id`, `organizer_id`, `amount`, `payment_method`, `payment_status`, `transaction_reference`, `payment_date`, `payment_time`, `created_at`) VALUES
(1, 3, 1, 128550.00, 'UPI', 'Completed', 'TXN-69E45522A55CB', '2026-04-19', '04:08:02', '2026-04-19 04:08:02');

-- --------------------------------------------------------

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
CREATE TABLE IF NOT EXISTS `resource` (
  `resource_id` int NOT NULL AUTO_INCREMENT,
  `orgenizer_id` int NOT NULL,
  `resource_name` varchar(100) NOT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `capacity` varchar(20) NOT NULL,
  `status` varchar(20) DEFAULT 'Available',
  `price` varchar(20) NOT NULL,
  `details` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`resource_id`),
  KEY `resource_ibfk_1` (`orgenizer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

DROP TABLE IF EXISTS `student_registration`;
CREATE TABLE IF NOT EXISTS `student_registration` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `roll_number` varchar(30) NOT NULL,
  `college_id` int NOT NULL,
  `course` varchar(20) NOT NULL,
  `year` int NOT NULL,
  `semester` int NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `image` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `email` (`email`),
  KEY `college_id` (`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college_register` (`college_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`),
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`organizer_id`) REFERENCES `organizer` (`organizer_id`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college_register` (`college_id`);

--
-- Constraints for table `event_feedback`
--
ALTER TABLE `event_feedback`
  ADD CONSTRAINT `event_feedback_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_registration` (`student_id`),
  ADD CONSTRAINT `event_feedback_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`),
  ADD CONSTRAINT `event_feedback_ibfk_3` FOREIGN KEY (`college_id`) REFERENCES `college_register` (`college_id`);

--
-- Constraints for table `event_registration`
--
ALTER TABLE `event_registration`
  ADD CONSTRAINT `event_registration_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_registration` (`student_id`),
  ADD CONSTRAINT `event_registration_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`),
  ADD CONSTRAINT `event_registration_ibfk_3` FOREIGN KEY (`college_id`) REFERENCES `college_register` (`college_id`);

--
-- Constraints for table `galary`
--
ALTER TABLE `galary`
  ADD CONSTRAINT `galary_ibfk_1` FOREIGN KEY (`collage_id`) REFERENCES `college_register` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`collage_id`) REFERENCES `college_register` (`college_id`);

--
-- Constraints for table `resource`
--
ALTER TABLE `resource`
  ADD CONSTRAINT `resource_ibfk_1` FOREIGN KEY (`orgenizer_id`) REFERENCES `organizer` (`organizer_id`);

--
-- Constraints for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD CONSTRAINT `student_registration_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college_register` (`college_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
