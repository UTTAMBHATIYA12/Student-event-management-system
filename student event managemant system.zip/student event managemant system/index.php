<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once('controller/operation.php');
    $obj = new login($_POST['name'], $_POST['password']);
}
if (isset($_REQUEST['error'])) {
    echo "<script>alert('" . $_GET['error'] . "')</script>";
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Student Event Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="view/css/style.css">
</head>

<body class="login">

    <!-- Main Container -->
    <div class="container">

        <!-- Hero Section -->
        <header class="herol">
            <h1>EventSphere</h1>
            <p>Manage • Organize • Celebrate Campus Events</p>
        </header>

        <!-- Large College Login Box -->
        <div class="login-card organizer large-box">
            <h2>Login Here</h2>
            <p>Create, manage, and monitor campus events professionally</p>

            <form method="post">
                <input type="text" placeholder="Email Address" name="name" required>
                <input type="password" placeholder="Password" name="password" required>
                <button type="submit" name="submit">Login</button>
            </form>

            <div class="links">
                <a href="forget_password.php">Forgot Password?</a>
            </div>
            <div class="links">
                <a href="student_registration.php">New
                    Student</a>&nbsp;&nbsp;&nbsp;
                <a href="collage_registration.php">New
                    Collage</a>&nbsp;&nbsp;&nbsp;
                <a href="orgenizer_registration.php">Orgenizer</a>&nbsp;&nbsp;&nbsp;
            </div>
        </div>
    </div>
</body>

</html>