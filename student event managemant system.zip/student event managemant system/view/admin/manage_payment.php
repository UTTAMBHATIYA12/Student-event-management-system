<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$orgenizer = new Orgenizer();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - All Payments</title>
    <link rel="stylesheet" href="../css/admin_style.css">
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>
    <div class="header">
        <h1>College-to-Organizer Payments</h1>
        <p style="color:black">Monitor transactions between institutions and event organizers.</p>
        <div class="header-wrapper">
            <p style="color:black">View all payments received from colleges</p>

            <select class="status-select">
                <option value="all">All Status</option>
                <option value="paid">Paid</option>
                <option value="pending">Pending</option>
            </select>
        </div>
    </div>


    <div class="payment-container">
        <table class="payment-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>From (College)</th>
                    <th>To (Organizer)</th>
                    <th>Amount</th>
                    <th>Transaction ID</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td data-label="Date">2026-03-29</td>
                    <td data-label="From"><strong>LDRP Institute</strong></td>
                    <td data-label="To">Mr. Rajesh</td>
                    <td data-label="Amount" class="amt-text">₹ 15,000</td>
                    <td data-label="ID">TXN_998877</td>
                    <td data-label="Status"><span class="badge success">Paid</span></td>
                </tr>
            </tbody>
        </table>
    </div>
    </div>
</body>

</html>