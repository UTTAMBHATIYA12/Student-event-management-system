<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$collage = new Collage();
$admin = new admin();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>
    <!-- Header -->
    <div class="header">
        <form action="" method="post">
            <input type="text" name="find" class="search" placeholder="Search By Anything.......">&nbsp;
            <input type="submit" value="Go" name="go" width="20px" class="btn">
        </form>
    </div>
    <?php
    $result = $collage->Selete(01); // new collage request.............................................
    if (isset($_REQUEST['go'])) {
        $result = $collage->Search($_POST['find'], "Reject");
    } elseif (isset($_REQUEST['accept'])) {
        echo "<script>alert('" . $admin->Accept_Reject_Collage_Request($_POST['collage_id'], "accept") . "')</script>";
    } elseif (isset($_REQUEST['Reject'])) {
        echo "<script>alert('" . $admin->Accept_Reject_Collage_Request($_POST['collage_id'], "reject") . "')</script>";
    }
    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>Manage Event</h2><br>
            <table>
                <tr>
                    <th>Collage ID</th>
                    <th>Collage Name(univercity name)</th>
                    <th>Collage Code</th>
                    <th>Address</th>
                    <th>E-mail</th>
                    <th>Contact</th>
                    <th>Principle Name</th>
                    <th>Action</th>
                </tr>

                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['college_id']; ?></td>
                        <td><?php echo $row['college_name'] . "( " . $row['university_name'] . " )"; ?></td>
                        <td><?php echo $row['college_code']; ?></td>
                        <td><?php echo $row['address'] . " / " . $row['city'] . "(" . $row['pincode'] . ")"; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo $row['principal_name']; ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="collage_id" value="<?php echo $row['college_id']; ?>">
                                <button type="submit" name="accept" class="edit">Accept</button>
                                <button type="submit" name="Reject" class="delete">Reject</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No Found New Collage Request";
    }
    ?>
    </div>
</body>

</html>