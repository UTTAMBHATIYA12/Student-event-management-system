<?php
session_start();
require_once('../../model/database.php');
if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {
    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
$collage = new Collage();
$org = new Orgenizer();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        a {
            text-decoration: none;
        }
    </style>
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>
    <!-- Header -->
    <div class="cards">
        <div class="card">
            <h3>Total Collage's</h3>
            <a href="ragister_collage_list.php">
                <p>
                    <?= $collage->countAllCollage("accept") ?>
                </p>
            </a>
        </div>
        <div class="card">
            <h3>New Request Collage's</h3>
            <a href="Collage_request.php">
                <p><?= $collage->countAllCollage("Reject") ?></p>
            </a>
        </div>
        <div class="card">
            <h3>Total Orgenizer</h3>
            <a href="manage_Orgenizer.php">
                <p>
                    <?= $org->countTotalOrgenizer() ?>
                </p>
            </a>
        </div>
    </div>
    <div class="header">
        <?php $result = $collage->Selete(01);
        $i = 0;
        for ($i = 1; $i <= 4; $i++) {
            if ($result->num_rows > 0) {
                ?>
                <div class="header">
                    <h2>Manage Event</h2><br>
                    <table>
                        <tr>
                            <th>Collage ID</th>
                            <th>Collage Name(univercity name)</th>
                            <th>Collage Code</th>
                            <th>Address</th>
                            <th>E-mail</th>
                            <th>Contact</th>
                            <th>Principle Name</th>
                            <th>Action</th>
                        </tr>

                        <?php
                        while ($row = $result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td><?php echo $row['college_id']; ?></td>
                                <td><?php echo $row['college_name'] . "( " . $row['university_name'] . " )"; ?></td>
                                <td><?php echo $row['college_code']; ?></td>
                                <td><?php echo $row['address'] . " / " . $row['city'] . "(" . $row['pincode'] . ")"; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['phone']; ?></td>
                                <td><?php echo $row['principal_name']; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="collage_id" value="<?php echo $row['college_id']; ?>">
                                        <button type="submit" name="accept" class="edit">Accept</button>
                                        <button type="submit" name="Reject" class="delete">Reject</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $i++;
                            if ($i == 5) {
                                break;
                            }
                        }
                        ?>
                    </table>
                </div>
                <?php
            }
        } ?>
    </div>
    <div class="header">
        <?php $result = $collage->Selete(0);
        $i = 0;
        for ($i = 1; $i <= 4; $i++) {
            if ($result->num_rows > 0) {
                ?>
                <div class="header">
                    <h2>Manage Register Collages</h2><br>
                    <table>
                        <tr>
                            <th>Collage ID</th>
                            <th>Collage Name(univercity name)</th>
                            <th>Collage Code</th>
                            <th>Address</th>
                            <th>E-mail</th>
                            <th>Contact</th>
                            <th>Principle Name</th>
                            <th>Action</th>
                        </tr>

                        <?php
                        while ($row = $result->fetch_assoc()) {

                            ?>
                            <tr>
                                <td><?php echo $row['college_id']; ?></td>
                                <td><?php echo $row['college_name'] . "( " . $row['university_name'] . " )"; ?></td>
                                <td><?php echo $row['college_code']; ?></td>
                                <td><?php echo $row['address'] . " / " . $row['city'] . "(" . $row['pincode'] . ")"; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['phone']; ?></td>
                                <td><?php echo $row['principal_name']; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="collage_id" value="<?php echo $row['college_id']; ?>">
                                        <button type="submit" name="delete" class="delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $i++;
                            if ($i == 5) {
                                break;
                            }
                        }
                        ?>
                    </table>
                </div>
                <?php
            }
        }
        ?>
    </div>
</body>

</html>