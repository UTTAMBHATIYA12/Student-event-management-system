<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$orgenizer = new Orgenizer();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orgenizer</title>
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>

        <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $result = $orgenizer->Selete(0);
    if (isset($_REQUEST['go'])) {
        $result = $orgenizer->Selete($_POST['orgenizer_id']);
    }
    if ($result->num_rows > 0) {
        ?>
            <div class="header">
                <h2>Manage Orgenizer</h2><br>
                <table>
                    <tr>
                        <th>Orgenizer ID</th>
                        <th>Owener Name</th>
                        <th>Comapny Name</th>
                        <th>E-mail</th>
                        <th>Contact</th>
                        <th>Address</th>
                        <th>Rating</th>
                        <th>Action</th>
                    </tr>

                    <?php
                    while ($row = $result->fetch_assoc()) {
                        ?>
                            <tr>
                                <td>
                                    <?php echo $row['organizer_id']; ?>
                                </td>
                                <td>
                                    <?php echo $row['full_name']; ?>
                                </td>
                                <td>
                                    <?php echo $row['comapny_name']; ?>
                                </td>
                                <td>
                                    <?php echo $row['email']; ?>
                                </td>
                                <td>
                                    <?php echo $row['phone']; ?>
                                </td>
                                <td>
                                    <?php echo $row['address']; ?>
                                </td>
                                <td>
                                    <?php echo $row['rating']; ?>
                                </td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="event_id" value="<?php echo $row['organizer_id']; ?>">
                                        <button type="submit" name="delete" class="delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                    }
                    ?>
                </table>
            </div>
            <?php
    } else {
        echo "No records found Any record";
    }
    ?>
    </div>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>