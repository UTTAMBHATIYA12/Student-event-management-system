<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$orgenizer = new Orgenizer();
$student = new Student();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $result = $student->SelectAllStudent(0);
    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>Manage Orgenizer</h2><br>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Collage Name</th>
                    <th>E-mail</th>
                    <th>Contact</th>
                    <th>Gender</th>
                </tr>

                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td>
                            <?php echo $row['student_id']; ?>
                        </td>
                        <td>
                            <?php echo $row['full_name']; ?>
                        </td>
                        <td>
                            <?php echo $row['college_name']; ?>
                        </td>
                        <td>
                            <?php echo $row['email']; ?>
                        </td>
                        <td>
                            <?php echo $row['phone']; ?>
                        </td>
                        <td>
                            <?php echo $row['gender']; ?>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No records found Any record";
    }
    ?>
    </div>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>