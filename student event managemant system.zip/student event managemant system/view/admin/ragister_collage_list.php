<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['admin'] !== 'admin') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$collage = new Collage();
$events = new events();
$Student = new Student();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="stylesheet" href="../css/admin_css.css">
    <style>
        .search_form {
            width: 50pc;
        }

        .search_form .search {
            width: 15pc;
        }

        .search_form .btn {
            width: 3pc;
            background-color: rgb(175, 175, 175);
        }

        .search_form .btn:hover {
            background-color: rgba(127, 135, 143, 0.33);
        }
    </style>
</head>

<body>
    <?php include('../inc/admin_left_menu.php'); ?>
    <!-- Header -->
    <div class="header">
        <form action="" method="post">
            <input type="text" name="find" class="search" placeholder="Search By Anything.......">&nbsp;
            <input type="submit" value="Go" name="go" width="20px" class="btn">
        </form>
    </div>
    <?php
    $result = $collage->Selete(0);
    if (isset($_REQUEST['go'])) {
        $result = $collage->Search($_POST['find'], "accept");
    } elseif (isset($_REQUEST['delete'])) {
        $Student->Delete(0, $_POST['collage_id']);
        $events->Delete(0, $_POST['collage_id']);
        $collage->Delete($_POST['collage_id']);
        echo "<script>alert('Collage Deleted Successfully  !!')</script>";

    }
    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>Manage Colllage</h2><br>
            <table>
                <tr>
                    <th>Collage ID</th>
                    <th>Collage Name(univercity name)</th>
                    <th>Collage Code</th>
                    <th>Address</th>
                    <th>E-mail</th>
                    <th>Contact</th>
                    <th>Principle Name</th>
                    <th>Action</th>
                </tr>

                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['college_id']; ?></td>
                        <td><?php echo $row['college_name'] . "( " . $row['university_name'] . " )"; ?></td>
                        <td><?php echo $row['college_code']; ?></td>
                        <td><?php echo $row['address'] . " / " . $row['city'] . "(" . $row['pincode'] . ")"; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo $row['principal_name']; ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="collage_id" value="<?php echo $row['college_id']; ?>">
                                <button type="submit" name="delete" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No found Any Record";
    }
    ?>
    </div>
</body>

</html>