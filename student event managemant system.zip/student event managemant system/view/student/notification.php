<?php
require_once('../../model/database.php');
$events = new events();
$student = new Student();
$notification = new notification();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$collage_id = $student->getCollageId($_SESSION['username']);
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <section class="hero">
        <h2>Notification</h2>
        <p>Important Notice From You Collage</p>
    </section>

    <div class="profile-container">

        <div class="events-section">
            <h3>
                <form method="post">Notification
                    <?php $result = $notification->select_notification($collage_id, 1, $student->getId($_SESSION['username']), 0);
                    if ($result->num_rows > 0) { ?>
                        <input type="submit" style="width:170px; margin-left: 67%;" value="Delete All Notification"
                            class="cancle_event" name="delete_all_event_register_student">
                    </form>
                </h3>
                <?php

                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="event-item">
                        <div>
                            <h4><?php echo $row['information'] ?></h4>
                            <p><?php echo $row['date']; ?></p>
                        </div>
                        <form action="" method="post">
                            <input type="hidden" name="event_id" value="<?php echo $row['notification_id']; ?>">
                            <input type="submit" value="Delete" name="Event_cancle_join" class="cancle_event">
                        </form>
                    </div>
                <?php }
                    } else {
                        echo "No Found Any Notification";
                    }
                    ?>
        </div>
    </div>

    <?php include '../inc/footer.php'; ?>

</body>

</html>