<?php
require_once('../../model/database.php');
$events = new events();
$student = new Student();
$feedback = new feedback();
session_start();
$_SESSION['username'] = "tushar@gmail.com";
$event_id = 0;
$Student_id = 0;
if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$Student_id = $student->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Event Details - Student Event Management System</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../student event managemant system/view/css/style.css">
    <link rel="stylesheet" href="../../student event managemant system/view/css/hero.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-light: #eff6ff;
            --text-main: #1e293b;
            --text-sub: #64748b;
            --bg-body: #f8fafc;
            --white: #ffffff;
            --border: #e2e8f0;
        }

        /* Trigger Button */
        .btn-main {
            background: var(--primary);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }

        .btn-main:hover {
            background: #1d4ed8;
            transform: translateY(-2px);
        }

        /* Modal Background */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.4);
            backdrop-filter: blur(8px);
            overflow-y: auto;
            display: none;
            align-items: flex-start;
            justify-content: center;
            padding: 40px 10px;
            /* Provides space at the top and bottom */
        }

        /* Modal Content Box */
        .modal-content {
            background: white;
            /* Changed from var(--white) for safety */
            margin: 0;
            /* Removed the 8% auto */
            padding: 35px;
            border-radius: 24px;
            width: 100%;
            max-width: 420px;
            /* Better for responsiveness */
            position: relative;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .close-btn {
            position: absolute;
            right: 25px;
            top: 25px;
            font-size: 22px;
            color: var(--text-sub);
            cursor: pointer;
            transition: 0.2s;
        }

        .close-btn:hover {
            color: #ef4444;
        }

        h3 {
            margin: 0 0 10px 0;
            color: var(--text-main);
            font-size: 22px;
        }

        p.subtitle {
            color: var(--text-sub);
            font-size: 14px;
            margin-bottom: 25px;
        }

        /* Selection Cards */
        .selection-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }

        .option-card input {
            display: none;
        }

        .card-ui {
            padding: 20px;
            border: 2px solid var(--border);
            border-radius: 16px;
            text-align: center;
            cursor: pointer;
            transition: 0.3s ease;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .card-ui i {
            font-size: 24px;
            color: var(--text-sub);
        }

        .card-ui span {
            font-weight: 600;
            font-size: 15px;
            color: var(--text-main);
        }

        .option-card input:checked+.card-ui {
            border-color: var(--primary);
            background: var(--primary-light);
        }

        .option-card input:checked+.card-ui i,
        .option-card input:checked+.card-ui span {
            color: var(--primary);
        }

        /* Form Inputs */
        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 6px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 14px;
            transition: 0.2s;
            background: #fcfcfd;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }

        .hidden-fields {
            display: none;
            border-top: 1px solid var(--border);
            padding-top: 20px;
            margin-top: 10px;
        }

        /* Confirm Button */
        .btn-confirm {
            width: 100%;
            background: var(--text-main);
            color: white;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 15px;
            transition: 0.3s;
        }

        .btn-confirm:hover {
            background: #000;
        }

        /* Animation */
        .member-input {
            animation: fadeIn 0.4s ease forwards;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>

</head>

<body>

    <?php include '..\inc\header.php'; ?>

    <!-- Header -->
    <section class="hero">
        <h1>Event Registration</h1>
        <p>Celebrate culture, creativity, and talent</p>
    </section>

    <!-- Event Details -->

    <?php
    $collage_id = $student->getCollageId($_SESSION['username']);
    if (isset($_REQUEST['submit_feedback'])) { // for feedback only when student registe an event than they give feed back 
        $feedback->Add_Feedback($_POST['student_id'], $_POST['event_id'], $_POST['rating'], $_POST['comment']);
        header('location:index.php?feedback=Thank you for your feedback');

    }
    if (isset($_REQUEST['View_event_details'])) { // request from event page and home which contain only event id for fetch evennt deatils
        $event_id = $_POST['event_id'];
    } elseif (isset($_REQUEST['join_event'])) {
        if ($_POST['regType'] === "solo") {
            echo "<script>alert('" . $events->Event_Registration($_POST['event_id'], $collage_id, $Student_id, NULL, NULL, "solo") . "')</script>";
        } else {
            $member_ids = isset($_POST['member_ids']) ? $_POST['member_ids'] : [];
            $member_ids_fetch = implode(", ", array_map('htmlspecialchars', $member_ids));
            echo "<script>alert('" . $events->Event_Registration($_POST['event_id'], $collage_id, $Student_id, $member_ids_fetch, $_POST['gruop_name'], "gruop") . "')</script>";
        }
        ?>
        <style>
            .event-container {
                display: none;
            }
        </style>
        <div class="feedback_body">
            <div class="feedback_box">
                <form method="post">
                    <label>Ratting</label><br>
                    We Value Your Feedback
                    <br><br>
                    <div class="start">
                        <label for="r1">⭐</label>
                        <input type="radio" name="rating" class="radio_button" id="r1" value="1">
                        <label for="r2">⭐</label>
                        <input type="radio" name="rating" class="radio_button" id="r2" value="2">
                        <label for="r3">⭐</label>
                        <input type="radio" name="rating" class="radio_button" id="r3" value="3">
                        <label for="r4">⭐</label>
                        <input type="radio" name="rating" class="radio_button" id="r4" value="4">
                        <label for="r5">⭐</label>
                        <input type="radio" name="rating" class="radio_button" id="r5" value="5">
                    </div>
                    <br><br>
                    <input type="hidden" name="event_id" value="<?php echo $_POST['event_id'] ?>">
                    <input type="hidden" name="student_id" value="<?php echo $Student_id ?>">
                    <textarea name="comment" cols="35" rows="5" placeholder="Write Your Review ..." required></textarea><br>
                    <input type="submit" name="submit_feedback" value="Submit FeedBack">
                </form>
            </div>
        </div>

        <?php
    }
    $result = $events->Selete($collage_id, $event_id);
    if ($result->num_rows > 0) {
        if ($row = $result->fetch_assoc()) {

            ?>
            <div class="event-container">
                <!-- Left Image -->
                <div class="event-image">
                    <img src="../uploads/event_pictures/<?php echo $row['event_image'] ?>" alt="image Error">
                </div>

                <!-- Right Details -->
                <div class="event-details">
                    <h2><?php echo $row['event_name'] ?></h2>

                    <div class="event-info">
                        <p><strong>📅 Date:</strong> <?php echo $row['event_date'] ?></p>
                        <p><strong>⏰ Time:</strong> <?php echo $row['time'] ?></p>
                        <p><strong>📍 Location:</strong> <?php echo $row['venue'] ?></p>
                        <!-- <p><strong>🎯 Category:</strong> <?php // echo $row['event_name'] ?></p> -->
                    </div>
                    <div class="event-description">
                        <h3>About This Event</h3>
                        <p>
                            <?php echo $row['event_description'] ?>
                        </p>
                    </div>
                    <form method="post">
                        <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                        <input type="hidden" name="event_name" value="<?php echo $row['event_name']; ?>"><br>
                        <button type="button" id="openBooking" class="btn-main">Register Now</button>
                        <div id="bookingModal" class="modal">
                            <div class="modal-content">
                                <span class="close-btn">&times;</span>
                                <h3>Event Registration</h3>
                                <p class="subtitle">Join us solo or bring your team along!</p>

                                <div class="selection-grid">
                                    <label class="option-card">
                                        <input type="radio" name="regType" value="solo" checked>
                                        <div class="card-ui">
                                            <i class="fa-solid fa-user"></i>
                                            <span>Solo</span>
                                        </div>
                                    </label>

                                    <label class="option-card">
                                        <input type="radio" name="regType" value="group">
                                        <div class="card-ui">
                                            <i class="fa-solid fa-users"></i>
                                            <span>Group</span>
                                        </div>
                                    </label>
                                </div>

                                <div id="groupInputs" class="hidden-fields">
                                    <div class="form-group">
                                        <label><i class="fa-solid fa-signature"></i> Team Name</label>
                                        <input type="text" name="gruop_name" placeholder="e.g. Code Warriors">
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fa-solid fa-hashtag"></i> Total Members</label>
                                        <input type="number" name="team_member_ids" id="memberCount" min="2" max="10"
                                            placeholder="Number of students">
                                    </div>
                                    <div id="memberList"></div>
                                </div>

                                <button type="submit" name="join_event" class="btn-confirm">Proceed to Registration</button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php
        }
    }
    ?>
    </div>
    <?php include '..\inc\footer.php'; ?>
    <script src="../js/select_solo_group.js"></script>
</body>

</html>