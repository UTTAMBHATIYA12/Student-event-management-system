<?php
require_once('../../model/database.php');
$events = new events();
$stu = new Student();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Event Registration - Student Event Management System</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #333;
        }

        /* Page Title */
        .page-title {
            text-align: center;
            padding: 60px 20px 30px;
        }

        .page-title h2 {
            font-size: 36px;
            color: #444;
        }

        .page-title p {
            color: #666;
            margin-top: 10px;
        }

        /* Registration Container */
        .registration-container {
            max-width: 1000px;
            margin: 30px auto 60px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
            display: flex;
            overflow: hidden;
        }

        /* Left Info Panel */
        .event-info {
            flex: 1;
            background: linear-gradient(to bottom, #667eea, #764ba2);
            color: #fff;
            padding: 40px;
        }

        .event-info h3 {
            font-size: 26px;
            margin-bottom: 15px;
        }

        .event-info p {
            font-size: 15px;
            line-height: 1.7;
            opacity: 0.95;
        }

        .event-info ul {
            margin-top: 20px;
        }

        .event-info ul li {
            margin-bottom: 10px;
            font-size: 14px;
        }

        /* Right Form Panel */
        .registration-form {
            flex: 1.2;
            padding: 40px;
        }

        .registration-form h3 {
            font-size: 24px;
            margin-bottom: 25px;
            color: #444;
        }

        .registration-form input,
        .registration-form select {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 18px;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            font-size: 14px;
        }

        .registration-form input:focus,
        .registration-form select:focus {
            border-color: #667eea;
        }

        /* Button */
        .registration-form button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: #fff;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .registration-form button:hover {
            background: #2b3d8aff;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .registration-container {
                flex-direction: column;
            }

            .event-info {
                text-align: center;
            }
        }
    </style>
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <!-- Page Title -->
    <section class="page-title">
        <h2>Event Registration</h2>
        <p>Fill in the form below to register for the event</p>
    </section>

    <!-- Registration Card -->
    <div class="registration-container">

        <!-- Left Side Info -->
        <div class="event-info">
            <h3>Why Join This Event?</h3>
            <p>
                Participate in exciting activities, showcase your talent,
                and connect with other students through our events.
            </p>

            <ul>
                <li>✔ Certificate of Participation</li>
                <li>✔ Fun & Learning Experience</li>
                <li>✔ Build Teamwork Skills</li>
            </ul>
        </div>
        <?php
        $Student_id = null;
        $Student_name = null;
        $Student_email = null;
        $event_name = null;
        if (isset($_REQUEST['join_event'])) {
            $event_name = $_POST['event_name'];
            $result = $events->Registration_event_details_select($_POST['event_id']);
            if ($result->num_rows > 0) {
                if ($row = $result->fetch_assoc()) {
                    $Student_id = $row['student_id'];
                }
            }
            $stu_details = $stu->Search(3, $Student_id);
            if ($stu_details->num_rows > 0) {
                if ($row = $stu_details->fetch_assoc()) {
                    $Student_name = $row['full_name'];
                    $Student_email = $row['email'];
                }
            }

        }
        ?>
        <!-- Right Side Form -->
        <form class="registration-form">
            <h3>Register Now</h3>

            <label for="">Student Id</label>
            <input type="text" value="<?php echo $Student_id ?>" required>
            <label for="">Student Name</label>
            <input type="text" value="<?php echo $Student_name ?>" required>
            <label for="">Email Address </label>
            <input type="email" value="<?php echo $Student_email ?>" required>
            <label for="">Event Name</label>
            <input type="text" value="<?php echo $event_name ?>" required>
            <button type="submit" onclick="alert('Event Ragistration Sucsessfully')">Submit Registration</button>
        </form>

    </div>

    <?php include 'C:\wamp\www\student event managemant system\view\inc\footer.php'; ?>

</body>

</html>