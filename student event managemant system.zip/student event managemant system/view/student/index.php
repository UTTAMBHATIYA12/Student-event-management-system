<?php
require_once('../../model/database.php');
$events = new events();
$student = new Student();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
if (!empty($_GET['feedback'])) {
    echo "<script>alert('Thank You For Your Feedback')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Student Event Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/hero.css">
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <!-- Hero -->
    <section class="hero">
        <h1>Welcome to Student Event Management System</h1>
        <p>Stay updated with the latest college and school events</p>
        <a href="event.php" class="cta-btn">Explore Events</a>
    </section>

    <!-- About -->
    <section class="about">
        <img src="../uploads/system_picture/2724275.jpg" alt="About">
        <div class="about-text">
            <h2>About Our System</h2>
            <p>
                Our Student Event Management System allows students to easily view, register, and participate
                in all upcoming college and school events. From cultural festivals to technical workshops, stay
                informed and never miss an event. Designed for simplicity, speed, and accessibility.
            </p>
        </div>
    </section>

    <section class="events">
        <h2> Latest Events</h2>
        <div class="event-grid">
            <?php $result = $events->Selete($student->getCollageId($_SESSION['username']), 0);
            $i = 0;
            for ($i = 1; $i <= 4; $i++) {
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {

                        ?>
                        <div class="event-card">
                            <img src="../uploads/event_pictures/<?php echo $row['event_image'] ?>" alt="image Error">
                            <div class="event-content">
                                <h3><?php echo $row['event_name'] ?></h3>
                                <p><?php echo $row['event_description'] . "<br> At - " . $row['venue'] ?></p>
                                <div class="event-date">📅 <?php echo $row['event_date'] ?></div>
                                <form action="event_details.php" method="post">
                                    <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                                    <input type="submit" value="View Details" name="View_event_details" class="event-btn">
                                </form>
                            </div>
                        </div>
                        <?php
                        $i++;
                        if ($i == 5) {
                            break;
                        }
                    }
                }

            } ?>
        </div>
    </section>
    <!-- Categories -->
    <section class="categories">
        <h2>Event Categories</h2>
        <div class="category-grid">
            <div class="category-card">
                <h3>College Events</h3>
                <p>Technical fests, workshops, and seminars</p>
            </div>
            <div class="category-card">
                <h3>School Events</h3>
                <p>Science fairs, cultural days, and competitions</p>
            </div>
            <div class="category-card">
                <h3>Cultural Events</h3>
                <p>Music, dance, and arts activities</p>
            </div>
            <div class="category-card">
                <h3>Sports Events</h3>
                <p>Matches, tournaments, and fitness challenges</p>
            </div>
        </div>
    </section>

    <?php include '../inc/footer.php'; ?>

</body>

</html>