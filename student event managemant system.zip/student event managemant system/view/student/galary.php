<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
require_once('../../model/database.php');
$galary = new galary();
$student = new Student();
$collage_id = $student->getCollageId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Gallery</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <!-- Hero -->
    <section class="hero">
        <h1>Event Gallery</h1>
        <p>We Can Manage Your Picture With Your Love Explore photos from our past events</p>
    </section>
    <section class="events">
        <div class="event-grid">
            <?php
            $result = $galary->select($collage_id);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="event-card">
                        <a href="../uploads/galary_pictures/<?php echo $row['image_path'] ?>"><img
                                src="../uploads/galary_pictures/<?php echo $row['image_path'] ?>" alt="image not available"></a>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </section>


    </div>
    <?php include '../inc/footer.php'; ?>

</body>

</html>