<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Participants - Student Event Management System</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #333;
        }

        /* Navbar */
        .navbar {
            position: sticky;
            top: 0;
            z-index: 100;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .navbar h1 {
            font-size: 24px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 25px;
        }

        .navbar ul li {
            cursor: pointer;
            transition: 0.3s;
        }

        .navbar ul li:hover {
            text-decoration: underline;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(to right, #667eea, #764ba2);
            color: white;
            text-align: center;
            padding: 100px 20px;
        }

        .hero h2 {
            font-size: 42px;
            margin-bottom: 15px;
        }

        .hero p {
            font-size: 18px;
            opacity: 0.9;
        }

        /* Participants Section */
        .participants {
            padding: 60px 50px;
        }

        .participants h2 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #444;
            text-align: center;
        }

        /* Participant Table */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        table th,
        table td {
            padding: 15px 20px;
            text-align: left;
            font-size: 14px;
        }

        table th {
            background: #667eea;
            color: white;
        }

        table tr:nth-child(even) {
            background: #f4f6fb;
        }

        table tr:hover {
            background: #e0e7ff;
            transform: scale(1.01);
            transition: 0.3s;
        }

        /* Footer */
        footer {
            background: #222;
            color: #ccc;
            text-align: center;
            padding: 25px;
            font-size: 14px;
        }
    </style>
</head>

<body>

   <?php include '../inc/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero">
        <h2>Participants</h2>
        <p>View all registered participants for the events</p>
    </section>

    <!-- Participants Table Section -->
    <section class="participants">
        <h2>Registered Participants</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Student ID</th>
                    <th>Event</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Alex Johnson</td>
                    <td>alex.johnson@example.com</td>
                    <td>STU123456</td>
                    <td>Tech Fest 2025</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Emily Davis</td>
                    <td>emily.davis@example.com</td>
                    <td>STU654321</td>
                    <td>Cultural Day</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Michael Lee</td>
                    <td>michael.lee@example.com</td>
                    <td>STU112233</td>
                    <td>Annual Sports Day</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Sophia Brown</td>
                    <td>sophia.brown@example.com</td>
                    <td>STU445566</td>
                    <td>Tech Fest 2025</td>
                </tr>
            </tbody>
        </table>
    </section>

    <?php include 'C:\wamp\www\student event managemant system\view\inc\footer.php'; ?>

</body>

</html>