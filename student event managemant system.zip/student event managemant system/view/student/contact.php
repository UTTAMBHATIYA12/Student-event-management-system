<?php
require_once('../../model/database.php');
$student = new Student();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$Student_id = $student->getId($_SESSION['username']);
$student_name = "";
$result = $student->view_profile($_SESSION['username'], 0);
$student_email = $_SESSION['username'];
$student_name = "uttam bhatiya";
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $student_name = $row['full_name'];
    }
}
if (isset($_REQUEST['Send_contact_massage'])) {
    echo "<script>alert('Your Request Send Successfully Please Wait For Response !!')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">
    <style>
        /* Contact Container */
        .contact-container {
            max-width: 1000px;
            margin: 30px auto 60px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
            display: flex;
            overflow: hidden;
        }

        /* Left Info */
        .contact-info {
            flex: 1;
            color: black;
            padding: 40px;
        }

        .contact-info h3 {
            font-size: 26px;
            margin-bottom: 15px;
        }

        .contact-info p {
            font-size: 15px;
            line-height: 1.7;
            margin-bottom: 12px;
            opacity: 0.95;
        }

        /* Right Form */
        .contact-form {
            flex: 1.2;
            padding: 40px;
            background: cover;
        }

        .contact-form h3 {
            font-size: 24px;
            margin-bottom: 25px;
            color: #444;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 18px;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            font-size: 14px;
        }

        .contact-form textarea {
            resize: none;
            height: 140px;
        }

        .contact-form input:focus,
        .contact-form textarea:focus {
            border-color: #667eea;
        }

        /* Button */
        .contact-form button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            border: none;
            border-radius: 25px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .contact-form button:hover {
            background: #2b3d8aff;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .contact-container {
                flex-direction: column;
            }

            .contact-info {
                text-align: center;
            }
        }
    </style>
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <section class="hero">
        <h2>Contact Us</h2>
        <p>We’d love to hear from you. Send us a message anytime.</p>
    </section>

    <div class="contact-container">

        <div class="contact-info">
            <h3>Get in Touch</h3>
            <p>Have any questions about events or registrations?
                Feel free to contact us anytime.</p>
            <p><strong>Email:</strong> info@events.com</p>
            <p><strong>Phone:</strong> +1 234 567 890</p>
            <p><strong>Address:</strong> 123 College Road, City</p>
            <p>🕘<?php echo date('M - D'); ?> | 9:00 AM – 6:00 PM</p>
        </div>

        <form class="contact-form" method="post">
            <h3>Send Message</h3>

            <input type="text" placeholder="Your Name" value="<?php if (!empty($student_name))
                echo $student_name; ?>" required>
            <input type="email" placeholder="Your Email" value="<?php if (!empty($student_email))
                echo $student_email; ?>" required>
            <textarea placeholder="Your Message" required></textarea>

            <button type="submit" name="Send_contact_massage">Send Message</button>
        </form>

    </div>

    <?php include '../inc/footer.php'; ?>

</body>

</html>