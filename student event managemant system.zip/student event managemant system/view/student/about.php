<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>About Us</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">
</head>

<body>
    <?php include '../inc/header.php'; ?>
    <!-- Hero Section -->
    <section class="hero">
        <h2>About Us</h2>
        <p>Learn more about our mission, vision, and team behind the Student Event Management System</p>
    </section>

    <!-- About Section -->
    <section class="about">
        <img src="../uploads/system_picture/2724275.jpg" alt="About">
        <div class="about-text">
            <h2>Who We Are</h2>
            <p>
                The Student Event Management System is designed to help students stay updated with
                college and school events. From technical workshops to cultural festivals, our platform
                provides an easy way to explore, register, and participate in all upcoming events.
                We believe in making event management simple, interactive, and accessible for every student.
            </p>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="mission-vision">
        <h2>Our Mission & Vision</h2>
        <div class="mv-cards">
            <div class="mv-card">
                <h3>Our Mission</h3>
                <p>To provide a seamless platform where students can discover, register, and participate in events,
                    promoting learning, creativity, and community engagement.</p>
            </div>
            <div class="mv-card">
                <h3>Our Vision</h3>
                <p>To be the go-to platform for student events, encouraging collaboration, innovation, and a vibrant
                    student life experience across schools and colleges.</p>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="team">
        <h2>Meet Our Team</h2>
        <div class="team-grid">
            <div class="team-member">
                <img src="https://images.unsplash.com/photo-1595152772835-219674b2a8a6" alt="Team Member">
                <h3>PRERAK BHEDA</h3>
                <p>Project Lead</p>
            </div>
            <div class="team-member">
                <img src="../uploads/system_picture/tushar.jpeg" alt="Team Member">
                <h3>TUSHAR DAVE</h3>
                <p>Frontend Developer</p>
            </div>
            <div class="team-member">
                <img src="/session/galary.jpg" alt="Team Member">
                <h3>UTTAM BHATIYA</h3>
                <p>Backend Developer</p>
            </div>
            <div class="team-member">
                <img src="../uploads/system_picture/kamlesh.jpeg" alt="Team Member">
                <h3>KAMLESH RATHOD</h3>
                <p>Database</p>
            </div>
        </div>
    </section>

    <?php include '../inc/footer.php'; ?>

</body>

</html>