<?php
require_once('../../model/database.php');
$events = new events();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>New Event's</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">

</head>

<body>

    <?php include '../inc/header.php'; ?>

    <!-- Page Title -->
    <section class="hero">
        <h2>All Events</h2>
        <p>Explore and register for upcoming college and school events</p>
    </section>
    <!-- Latest Events -->
    <section class="events">
        <h2>Latest Events</h2>
        <div class="event-grid">
            <?php $result = $events->Selete(3, 0);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="event-card">

                        <img src="../uploads/event_pictures/<?php echo $row['event_image'] ?>"
                            alt="<?php echo $row['event_image'] ?>">
                        <div class="event-content">
                            <h3><?php echo $row['event_name'] ?></h3>
                            <p><?php echo $row['event_description'] . "<br> At - " . $row['venue'] ?></p>
                            📅 <?php echo $row['event_date'] ?><br>
                            <form action="event_details.php" method="post">
                                <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                                <input type="submit" value="View Details" name="View_event_details" class="event-btn">
                            </form>
                        </div>
                    </div>
                <?php }
            } ?>
    </section>

    <?php include '../inc//footer.php'; ?>

</body>

</html>