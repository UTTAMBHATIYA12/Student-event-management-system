<?php
require_once('../../model/database.php');
$student = new Student();
session_start();

// Security Check
if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}

$collage_id = $student->getCollageId($_SESSION['username']);
$student_id = $student->getId($_SESSION['username']);

// Profile Update Logic
if (isset($_POST['update_profile'])) {
    $msg = $student->Update($collage_id, $student_id, $_POST['name'], $_POST['roll'], $_POST['year'], $_POST['sem'], $_POST['image'], $_POST['phone'], $_POST['email']);
    echo "<script>alert('$msg'); window.location='profile.php';</script>";
}

$result = $student->view_profile($_SESSION['username'], $collage_id);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <link rel="stylesheet" href="../css/hero.css">
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <style>
        :root {
            --accent: #2563eb;
            --text-main: #1e293b;
            --bg-soft: #f8fafc;
        }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: #f1f5f9;
            color: var(--text-main);
            margin: 0;
        }

        .main-wrapper {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
        }

        .profile-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 25px;
        }

        /* Left Side: Photo Card */
        .photo-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .photo-card img {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--bg-soft);
            margin-bottom: 15px;
        }

        .photo-card h2 {
            margin: 10px 0 5px;
            font-size: 20px;
        }

        .photo-card span {
            color: #64748b;
            font-size: 14px;
        }

        /* Right Side: Info Card */
        .details-card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        /* Typography & Grid */
        .info-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .field label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .field p {
            margin: 8px 0;
            font-size: 16px;
            font-weight: 500;
        }

        /* Inputs */
        input,
        select {
            width: 100%;
            padding: 10px;
            border: 1.5px solid #e2e8f0;
            border-radius: 8px;
            margin-top: 5px;
            font-size: 14px;
            transition: border 0.2s;
        }

        input:focus {
            outline: none;
            border-color: var(--accent);
        }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: 0.2s;
            font-size: 14px;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-outline {
            background: #f1f5f9;
            color: #475569;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        .hidden {
            display: none;
        }

        @media (max-width: 768px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

    <?php include '../inc/header.php'; ?>
    <!-- Page Title -->
    <section class="hero">
        <h2>My Profile</h2>
        <p>View your profile details and registered events</p>
    </section>

    <div class="main-wrapper">
        <div class="profile-grid">

            <div class="photo-card">
                <img src="../uploads/profile_pictures/<?= $row['image'] ?: 'default.png' ?>" alt="Profile">
                <h2><?= $row['full_name'] ?></h2>
                <span>Student ID: <?= $row['student_id'] ?></span>
                <div style="margin-top: 25px;">
                    <button id="editBtn" onclick="toggleMode(true)" class="btn btn-primary" style="width: 100%;">Edit
                        Profile</button>
                </div>
            </div>

            <div class="details-card">

                <div id="viewMode">
                    <div class="section-header">
                        <h3>General Information</h3>
                    </div>
                    <div class="info-row">
                        <div class="field"><label>Email Address</label>
                            <p><?= $row['email'] ?></p>
                        </div>
                        <div class="field"><label>Phone Number</label>
                            <p><?= $row['phone'] ?></p>
                        </div>
                    </div>
                    <div class="info-row">
                        <div class="field"><label>Course</label>
                            <p><?= $row['course'] ?></p>
                        </div>
                        <div class="field"><label>College</label>
                            <p><?= $row['college_name'] ?></p>
                        </div>
                    </div>
                    <div class="info-row">
                        <div class="field"><label>Year</label>
                            <p><?= $row['year'] ?></p>
                        </div>
                        <div class="field"><label>Semester</label>
                            <p><?= $row['semester'] ?></p>
                        </div>
                    </div>
                    <div class="field"><label>Roll Number</label>
                        <p><?= $row['roll_number'] ?></p>
                    </div>
                </div>

                <div id="editMode" class="hidden">
                    <div class="section-header">
                        <h3>Update Profile Details</h3>
                    </div>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="info-row">
                            <div class="field"><label>Full Name</label><input type="text" name="name"
                                    value="<?= $row['full_name'] ?>" required></div>
                            <div class="field"><label>Email</label><input type="email" name="email"
                                    value="<?= $row['email'] ?>" required></div>
                        </div>
                        <div class="info-row">
                            <div class="field"><label>Phone</label><input type="text" name="phone"
                                    value="<?= $row['phone'] ?>" required></div>
                            <div class="field"><label>Roll No</label><input type="text" name="roll"
                                    value="<?= $row['roll_number'] ?>" required></div>
                        </div>
                        <div class="info-row">
                            <div class="field"><label>Year</label><input type="text" name="year"
                                    value="<?= $row['year'] ?>" required></div>
                            <div class="field"><label>Semester</label><input type="text" name="sem"
                                    value="<?= $row['semester'] ?>" required></div>
                        </div>
                        <div class="field" style="margin-bottom: 20px;"><label>Change Profile Photo</label><input
                                type="file" name="image"></div>

                        <div style="display: flex; gap: 10px; border-top: 1px solid #eee; padding-top: 20px;">
                            <button type="submit" name="update_profile" class="btn btn-primary">Save Changes</button>
                            <button type="button" onclick="toggleMode(false)" class="btn btn-outline">Cancel</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <?php include '../inc/footer.php'; ?>
    <script>
        function toggleMode(isEdit) {
            document.getElementById('viewMode').classList.toggle('hidden', isEdit);
            document.getElementById('editMode').classList.toggle('hidden', !isEdit);
            document.getElementById('editBtn').classList.toggle('hidden', isEdit);
        }
    </script>

</body>

</html>