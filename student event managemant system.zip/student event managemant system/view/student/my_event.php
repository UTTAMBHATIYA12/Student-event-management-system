<?php
require_once('../../model/database.php');
$events = new events();
$student = new Student();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['student'] !== "student") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/hero.css">
    <link rel="icon" href="../uploads/system_picture/icon.png">
</head>

<body>

    <?php include '../inc/header.php'; ?>

    <section class="hero">
        <h2>My Event</h2>
        <p>View your Last Registered events details</p>
    </section>

    <div class="profile-container">

        <div class="events-section">
            <h3>Registered Events</h3>
            <?php
            $student_id = $student->getId($_SESSION['username']);
            if (isset($_REQUEST['Event_cancle_join'])) {
                echo "<script>alert('" . $events->Event_Cancle($student_id, $_POST['event_id']) . "')</script>";
            }
            $result = $events->Registerd_event_details($student_id);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="event-item">
                        <div>
                            <h4><?php echo $row['event_name'] . "( " . $row['type'] . " )" ?></h4>
                            <p><?php if ($row['type'] === "GROUP") {
                                $individual_ids = explode(",", $row['member_id']);

                                echo "<scrong>Gruop Name : </scrong>" . $row['group_name'] . "<br>";
                                echo "<scrong>Team Member : </scrong>";
                                foreach ($individual_ids as $id) {
                                    if ($row_stu = $student->getNameById(trim($id))->fetch_assoc()) {
                                        echo $row_stu['full_name'] . ", ";
                                    }
                                }

                            } ?></p>
                            <p>📅
                                <?php echo $row['event_date'] . " &nbsp;&nbsp; | &nbsp;📍" . $row['venue'] . " &nbsp;&nbsp; | &nbsp;" . $row['status'] ?>
                            </p>
                        </div>
                        <form action="" method="post">
                            <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                            <input type="submit" value="Cancle" name="Event_cancle_join" class="cancle_event">
                        </form>
                    </div>
                <?php }
            } else {
                echo "No Found Any Register Event";
            }
            ?>
        </div>
    </div>

    <?php include '../inc/footer.php'; ?>

</body>

</html>