<?php
session_start();
require_once('../../model/database.php');

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$obj = new Collage();
$collage_id = $obj->getId($_SESSION['username']);
if (isset($_REQUEST['save_profile_details'])) {
    echo "<script>alert('" . $obj->Update(
        $_POST['collage_name'],
        $_POST['univercity_name'],
        $_POST['address'],
        $_POST['city'],
        $_POST['state'],
        $_POST['pincode'],
        $_POST['phone'],
        $_POST['email'],
        $_POST['principle_name'],
        $_POST['total_student'],
        $collage_id
    ) . "')</script>";
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Profile</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css" />
</head>

<body>
    <?php include('../inc/collage_left_menu.php');
    $result = $obj->Selete($collage_id);
    ?>
    <div class="header">
        <h2>Collage Profile</h2><br>
        <?php
        if ($result->num_rows > 0) {
            if ($row = $result->fetch_assoc()) {
                ?>
                <form class="profile-form" method="post">

                    <div class="form-group">
                        <label>College Name</label>
                        <input type="text" name="collage_name" value="<?php echo $row['college_name'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>University Name</label>
                        <input type="text" name="univercity_name" value="<?php echo $row['university_name'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>College Code</label>
                        <input type="text" value="<?php echo $row['college_code'] ?>" required disabled>
                    </div>

                    <div class="form-group">
                        <label>Principal Name</label>
                        <input type="text" name="principle_name" value="<?php echo $row['principal_name'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo $row['email'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo $row['phone'] ?>" required>
                    </div>

                    <div class="form-group full">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo $row['address'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" value="<?php echo $row['city'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>State</label>
                        <input type="text" name="state" value="<?php echo $row['state'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Pincode</label>
                        <input type="text" name="pincode" value="<?php echo $row['pincode'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Total Student</label>
                        <input type="text" name="total_student" value="<?php echo $row['total_students'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Registration Date / time </label>
                        <input type="text" value="<?php echo $row['registration_date'] ?>" required disabled>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="save_profile_details" class="edit">Save Profile Update </button>
                    </div>
                </form>
                <?php
            }
        }
        ?>
    </div>
</body>

</html>