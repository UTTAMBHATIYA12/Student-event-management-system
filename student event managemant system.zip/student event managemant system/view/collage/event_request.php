<?php
session_start();
require_once('../../model/database.php');

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$events = new events();
$obj = new Collage();
$collage_id = $obj->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Event Requets</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $result = $events->select_new_event_registration_request($collage_id);
    if (isset($_REQUEST['find'])) {
        $result = $events->Search($collage_id, $_POST['find']);
    } elseif (isset($_REQUEST['Accept_event_request'])) {
        echo "<script>alert('" . $events->accept_event_requets(0, $collage_id, $_SESSION['events_id'], $_POST['student_id']) . "')</script>";
    } elseif (isset($_REQUEST['Delete_event_request'])) { // currently not working..........................
        echo "<script>alert('Request Rejected Successfully " . $_POST['event_regi_id'] . "" . $_POST['event_id'] . "')</script>";
    } elseif (isset($_REQUEST['accept_all_event_register_student'])) {
        echo "<script>alert('" . $events->accept_event_requets(0, $collage_id, $_SESSION['events_id'], $_POST['student_id']) . "')</script>";
    } elseif (isset($_REQUEST['delete_all_event_register_student'])) {
        echo "<script>alert('All Request Rejected Successfully !!')</script>"; // currently not working.................
    }
    ?>


    <?php
    if ($result->num_rows > 0) { ?>
        <div class="header">
            <h2>
                <form method="post">Manage Event Regiser Student
                    <input type="submit" style="width:170px; margin-left: 37%;" value="Accept All Request" class="edit"
                        name="accept_all_event_register_student">
                    <input type="submit" style="width:170px; margin-left: 0%;" value="Reject All Request" class="delete"
                        name="delete_all_event_register_student">
                </form>
            </h2><br>
            <table>
                <tr>
                    <th>Student Name</th>
                    <th>Event Name</th>
                    <th>Evant Date & Time</th>
                    <th>Gruop / Solo</th>
                    <th>Team Member</th>
                    <th>E-mail</th>
                    <th>Action</th>
                </tr>
                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['full_name']; ?></td>
                        <td><?php echo $row['event_name']; ?></td>
                        <td><?php echo $row['event_date'] . " / " . $row['time']; ?></td>
                        <td><?php echo $row['type'];
                        if ($row['type'] === "GROUP") {
                            echo " ( " . $row['group_name'] . " ) "; ?></td>
                            <td><?php
                            foreach (explode(",", $row['member_id']) as $id) {
                                if ($stu_fetch = $student->getNameById(trim($id))->fetch_assoc())
                                    echo $stu_fetch['email'] . ",<br>";

                            }
                        } else
                            echo "</td><td>-</td>";
                        ?>
                        <td><?php echo $row['email'] ?></td>

                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                <button type="submit" name="Accept_event_request" class="edit">Acept</button>
                                <button type="submit" name="delete" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No Records Found";
    }
    ?>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>