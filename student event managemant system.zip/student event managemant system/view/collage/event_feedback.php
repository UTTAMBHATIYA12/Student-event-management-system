<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}

require_once('../../model/database.php');
$feedback = new feedback();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Feedback</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <?php
    $result = $feedback->select_FeedBack($collage_id);
    if (isset($_REQUEST['delete_feedback'])) {
        echo "<script>alert('" . $feedback->Remove_Feedback($_POST['feedback_id'], $collage_id, 0) . "')</script>";
    } elseif (isset($_REQUEST['delete_all_feedback'])) {
        echo "<script>alert('" . $feedback->Remove_Feedback(0, $collage_id, 1) . "')</script>";
    } elseif (isset($_REQUEST['find'])) {
        echo "Need To Improve Sql Query";
        $result = $feedback->Search_Feedback($collage_id, $_POST['find']);
    }
    ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <div class="header">
        <h2>
            <form method="post">Manage FeedBack <input type="submit" style="width:170px; margin-left: 63%;"
                    value="Delete All Feedback" class="delete" name="delete_all_feedback"></form>
        </h2><br>
        <?php
        if ($result->num_rows > 0) {
            ?>

            <table>
                <tr>
                    <th>Feedback ID</th>
                    <th>Event Name</th>
                    <th>Student Name</th>
                    <th>Rating</th>
                    <th>Comment</th>
                    <th>Feedback Date</th>
                    <th>Action</th>
                </tr>

                <?php
                for ($i = 1; $i <= 5; $i++) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['feedback_id']; ?></td>
                            <td><?php echo $row['event_name']; ?></td>
                            <td><?php echo $row['full_name']; ?></td>
                            <td><?php $rating = $row['rating'];
                            for ($i = 1; $i <= $rating; $i++) {
                                echo "⭐";
                            }
                            ?></td>
                            <td><?php echo $row['comments']; ?></td>
                            <td><?php echo $row['feedback_date']; ?></td>
                            <td>
                                <form action="" method="post">
                                    <input type="hidden" name="feedback_id" value="<?php echo $row['feedback_id']; ?>">
                                    <button type="submit" name="delete_feedback" class="delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
        </div>
        <?php
        } else {
            echo "No found Any record Of Events Feedback";
        }
        ?>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>