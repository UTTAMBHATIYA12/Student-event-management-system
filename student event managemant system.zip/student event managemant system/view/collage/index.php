<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}

require_once('../../model/database.php');
$events = new events();
$obj = new Collage();
$stu = new Student();
$notification = new notification();
$booking = new booking();
$collage_id = $obj->getId($_SESSION['username']);
if (isset($_REQUEST['delete'])) {
    $events->Event_Cancle(0, $_POST['event_id']); // delete student who participent in the event
    $events->Delete($_POST['event_id'], $collage_id); // delete event
    echo "<script>alert('Event Deleted Successfully !!')</script>";
} elseif (isset($_REQUEST['update'])) {
    $_SESSION['event_id'] == $_POST['event_id'];
    header('location:manage_event.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
    <style>
        .header-wrapper {
            display: flex;
            justify-content: space-between;
            /* Pushes content to edges */
            align-items: center;
            /* Aligns vertically */
            margin: 20px 0;
            /* Vertical spacing */
            flex-wrap: wrap;
            gap: 15px;
        }
    </style>
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="cards">
        <div class="card">
            <h3>Total Student</h3>
            <p><?php echo $stu->count_total_student($collage_id) ?></p>
        </div>
        <div class="card">
            <h3>Total Events</h3>
            <p><?php echo $events->count_total_Event($collage_id) ?></p>
        </div>
        <div class="card">
            <h3>Event Registered Students</h3>
            <p><?php
            $result = $events->select_all_register_student($collage_id, "null");
            if ($row = $result->fetch_assoc())
                echo $row['total_student'];
            $result = $events->select_all_register_student($collage_id, "Reject");
            if ($row = $result->fetch_assoc())
                echo $row['total_student'];
            ?>
            </p>
        </div>
        <div class="card">
            <h3>My Resource Booking</h3>
            <p><?= $booking->totol_booking_count($collage_id) ?></p>
        </div>
    </div>
    <?php
    if (isset($_REQUEST['delete_a_notification'])) {
        echo "<script>alert('" . $notification->Delete_notification($collage_id, $_POST['notification_id']) . "')</script>";
    } elseif (isset($_REQUEST['delete_all_notification'])) {
        echo "<script>alert('" . $notification->Delete_notification($collage_id, 0) . "')</script>";
    }
    $result = $notification->select_notification($collage_id, 0, 0);
    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <div class="header-wrapper">
                <h2>Letest Notification</h2>
                <form method="post">
                    <input type="submit" name="delete_all_notification" class='delete' value="Delete All">
                </form>
            </div>
            <?php
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="header-wrapper">
                    <h4><?= "👉🏼 " . $row['information']; ?></h4>
                    <form method="post">
                        <input type="submit" name="delete_a_notification" class='delete' value="Delete">
                    </form>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }
    $result = $events->Selete($collage_id, 0);

    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>Manage Event</h2><br>
            <table>
                <tr>
                    <th>Event ID</th>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Date & Time</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                <?php
                for ($i = 1; $i <= 5; $i++) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['event_id']; ?></td>
                            <td><?php echo $row['event_name']; ?></td>
                            <td><?php echo $row['event_description']; ?></td>
                            <td><?php echo $row['event_date'] . " / " . $row['event_date']; ?></td>
                            <td><?php echo $row['venue']; ?></td>
                            <td>Upcoming</td>
                            <td>
                                <form action="" method="post">
                                    <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                                    <button type="submit" name="update" class="edit">Update</button>
                                    <button type="submit" name="delete" class="delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No found Any record Of Events <br>";
    }

    $result = $stu->Selete($collage_id);
    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>Manage Student's</h2><br>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Full Name</th>
                    <th>Roll No/course/Year/Sem</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                </tr>

                <?php
                for ($i = 1; $i <= 5; $i++) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td>
                                <?php echo $row['student_id']; ?>
                            </td>
                            <td>
                                <?php echo $row['full_name']; ?>
                            </td>
                            <td>
                                <?php echo $row['roll_number'] . " / " . $row['course'] . " / " . $row['year'] . " / " . $row['semester']; ?>
                            </td>
                            <td>
                                <?php echo $row['gender']; ?>
                            </td>
                            <td>
                                <?php echo $row['email']; ?>
                            </td>
                            <td>
                                <?php echo $row['phone']; ?>
                            </td>
                            <td>
                                <form action="" method="post">
                                    <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                    <button type="submit" name="delete" class="delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No found Any record Of The Student";
    }
    ?>
    </div>
</body>

</html>