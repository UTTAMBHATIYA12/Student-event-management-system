<?php
session_start();
$_SESSION['orgenizer_id'] = 0;
if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
require_once('../../model/database.php');
$org = new Orgenizer();
$events = new events();
$booking = new booking();
$collage = new Collage();
$payment = new payment();
$result = $org->Selete($_GET['id']);
$row = $result->fetch_assoc();
$collage_id = $collage->getId($_SESSION['username']);
if (isset($_REQUEST['book_now'])) {
    $start = $_POST['Start_date'];
    $end = $_POST['End_date'];
    $total = (float) $_POST['total_amount']; // total amount
    $event_id = $_POST['event_id'] ?? '';
    $today = date('Y-m-d');
    $payment_time = date('H:i:s');
    $error = "";

    if ($total <= 0) {
        $error = "Please select at least one resource.";
    } elseif ($start < $today || $end < $today) {
        $error = "Dates cannot be in the past.";
    } elseif ($end <= $start) {
        $error = "End Date must be after the Start Date.";
    } elseif (!ctype_digit($event_id)) {
        $error = "Invalid Event ID. Numbers only.";
    } elseif ($events->getEventInfoById($event_id, $collage_id) == 0) {
        $error = "Invalid Event ID. Please Check Event Id And Fill !!";
    }

    if ($error != "") {
        echo "<script>alert('" . $error . "');</script>";
    } else {
        $payment_status = "Completed"; //  need to implemention
        $transacttx_idion_reference = "TXN-" . strtoupper(uniqid());
        if ($payment->addPaymentCollageToOrg($collage_id, $_POST['organizer_id'], $total, $_POST['payment_method'], $payment_status, $transacttx_idion_reference, $today, $payment_time)) {
            $resource_id = isset($_POST['resource_id']) ? $_POST['resource_id'] : [];
            $resources_ids_fetch = implode(", ", array_map('htmlspecialchars', $resource_id));
            echo "<script>alert('" . $booking->newResourseBooking($_POST['organizer_id'], $_POST['event_id'], $collage_id, $resources_ids_fetch, $start, $end, $_POST['other_requerment'], $_POST['address']) . "')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer Hub | <?= $row['comapny_name'] ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --brand: #6366f1;
            --brand-soft: #eef2ff;
            --bg-pearl: #fdfdfe;
            --card-bg: #ffffff;
            --text-head: #0f172a;
            --text-body: #475569;
            --radius-lg: 24px;
            --radius-md: 16px;
            --shadow-soft: 0 20px 50px rgba(0, 0, 0, 0.03);
        }

        body {
            background-color: var(--bg-pearl);
            color: var(--text-body);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            margin: 0;
            /* padding: 20px; */
        }

        /* Layout Setup */
        .wrapper {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 24px;
            max-width: 1300px;
            margin: 40px auto;
        }

        /* Profile Sidebar - Sleek & Floating */
        .sidebar-profile {
            background: var(--card-bg);
            border-radius: var(--radius-lg);
            padding: 40px 30px;
            box-shadow: var(--shadow-soft);
            height: fit-content;
            border: 1px solid rgba(0, 0, 0, 0.02);
        }

        .company-logo img {
            width: 80px;
            height: 80px;
            border-radius: 22px;
            object-fit: cover;
            margin-bottom: 20px;
        }

        .sidebar-profile h1 {
            font-size: 22px;
            color: var(--text-head);
            margin: 0 0 10px 0;
            font-weight: 800;
        }

        .bio {
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .contact-list {
            list-style: none;
            padding: 0;
        }

        .contact-list li {
            background: #f8fafc;
            margin-bottom: 8px;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 13px;
            display: flex;
            flex-direction: column;
        }

        .contact-list li strong {
            font-size: 10px;
            text-transform: uppercase;
            color: var(--brand);
            letter-spacing: 1px;
            margin-bottom: 2px;
        }

        /* Main Content Area */
        .booking-card {
            background: var(--card-bg);
            border-radius: var(--radius-lg);
            padding: 45px;
            box-shadow: var(--shadow-soft);
        }

        .booking-card h2 {
            font-size: 26px;
            font-weight: 800;
            color: var(--text-head);
            margin-top: 0;
            margin-bottom: 30px;
        }

        /* Resource Selection - Modern Interactive Cards */
        .resource-item {
            margin-bottom: 12px;
        }

        .res-check:checked+.res-content {
            background: var(--brand-soft);
            border-color: var(--brand);
        }

        .res-content {
            border: 2px solid #f1f5f9;
            border-radius: var(--radius-md);
            padding: 20px 25px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .res-content:hover {
            border-color: var(--brand);
            background: #fafbff;
        }

        .res-info strong {
            font-size: 16px;
            color: var(--text-head);
        }

        .res-info span {
            font-size: 13px;
            display: block;
            margin-top: 4px;
        }

        .res-price {
            font-size: 18px;
            font-weight: 800;
            color: var(--brand);
        }

        /* Clean Form Elements */
        .form-group label {
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 8px;
            display: block;
            color: var(--text-head);
        }

        input,
        textarea {
            width: 100%;
            padding: 14px 18px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            background: #fcfdfe;
            font-size: 14px;
            transition: 0.2s;
        }

        input:focus {
            border-color: var(--brand);
            background: #fff;
            outline: none;
            box-shadow: 0 0 0 4px var(--brand-soft);
        }

        /* Summary Panel - The "Wonderful" Touch */
        .summary-sidebar {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: var(--radius-md);
            padding: 30px;
            margin-top: 40px;
        }

        .summary-sidebar h3 {
            margin-top: 0;
            font-size: 16px;
            color: var(--text-head);
        }

        .bill-row {
            display: flex;
            justify-content: space-between;
            margin: 12px 0;
            font-size: 14px;
        }

        .total-container {
            border-top: 2px dashed #e2e8f0;
            margin-top: 20px;
            padding-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .total-amount {
            font-size: 32px;
            margin: 0;
            color: var(--brand);
            font-weight: 800;
        }

        .btn-confirm {
            width: 100%;
            background: var(--brand);
            color: white;
            padding: 20px;
            border-radius: 14px;
            border: none;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 25px;
            transition: transform 0.2s, background 0.2s;
        }

        .btn-confirm:hover {
            background: #4f46e5;
            transform: translateY(-2px);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .wrapper {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="icon" href="../uploads/system_picture/icon.png">
</head>

<body>
    <?php include('../inc/collage_left_menu.php');
    $result = $org->Selete($_GET['id']);
    if ($row = $result->fetch_assoc()) {
        ?>

        <div class="wrapper">
            <aside class="sidebar-profile">
                <div class="company-logo">
                    <img src="../uploads/profile_pictures/<?= $row['compny_logo'] ?>" alt="Organizer Logo">
                </div>
                <h1><?= $row['comapny_name'] ?></h1>
                <p class="bio">
                    <?= $row['bio'] ?: 'A professional event organizer dedicated to crafting memorable experiences.' ?>
                </p>

                <ul class="contact-list">
                    <li><strong>Owner</strong> <?= $row['full_name'] ?></li>
                    <li><strong>Experience</strong> <?= $row['experience'] ?> Years</li>
                    <li><strong>Contact</strong> <?= $row['phone'] ?></li>
                    <li><strong>Email</strong> <?= $row['email'] ?></li>
                    <li><strong>Address</strong> <?= $row['address'] ?: 'Not Provided' ?></li>
                    <li><strong>Rating</strong> ⭐<?= $row['rating'] ?: 'N/A' ?> / 5</li>
                </ul>
            </aside>
            <div class="header">
                <div class="content-area">
                    <div class="booking-card">
                        <h2>Booking Now</h2>
                        <form method="POST">
                            <?php
                            $result = $org->getResourseDetails($_GET['id']);
                            if ($result->num_rows > 0) {
                                while ($res_row = $result->fetch_assoc()) { ?>
                                    <div class="resource-item">
                                        <input type="checkbox" name="resources[]" value="<?= $res_row['price'] ?>"
                                            data-price="<?= $res_row['price'] ?>" id="res_<?= $res_row['resource_id'] ?>"
                                            class="res-check">

                                        <label for="res_<?= $res_row['resource_id'] ?>" class="res-content">

                                            <div class="res-info">

                                                <strong><?= $res_row['resource_name'] ?></strong>

                                                <span><?= $res_row['details'] ?></span>
                                            </div>

                                            <div class="res-price">₹
                                                <?= number_format($res_row['price']) ?>
                                            </div>
                                        </label>
                                    </div>
                                    <input type="hidden" name="resource_id[]" value="<?= $res_row['resource_id'] ?>"
                                        id="res_<?= $res_row['resource_id'] ?>" class="res-check">
                                    <?php
                                } ?>

                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top:20px;">
                                    <div class="form-group">
                                        <label>Event Start Date</label>
                                        <input type="date" name="Start_date" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Event End Date</label>
                                        <input type="date" name="End_date" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Event Id (for Resource booking)</label>
                                        <input type="text" name="event_id" title="Must Requers Event Id For Booking" required>
                                    </div>
                                </div>

                                <div class="form-group" style="margin-top: 25px;">
                                    <label><i class="fa-solid fa-location-dot"></i> Event Venue Address</label>
                                    <div id="new_address_wrapper">
                                        <textarea name="address" rows="3" placeholder="Enter full venue details here..."
                                            required></textarea>
                                    </div>
                                </div>

                                <div class="form-group" style="margin-top: 20px;">
                                    <label><i class="fa-solid fa-pen-to-square"></i> Specific Instructions / Notes</label>
                                    <input type="text" name="other_requerment"
                                        placeholder="e.g. Needs extra lighting, specific setup time..." required>
                                </div>
                                <div class="form-group" style="margin-top: 20px;">
                                    <label><i class="fa-solid fa-credit-card"></i> Payment Method</label>
                                    <select name="payment_method" required
                                        style="width: 100%; padding: 14px 18px; border: 1px solid #e2e8f0; border-radius: 12px; background: #fcfdfe; font-size: 14px;">
                                        <option value="" disabled selected>Select Payment Type</option>
                                        <option value="UPI">UPI / Google Pay / PhonePe</option>
                                        <option value="Card">Debit / Credit Card</option>
                                        <option value="NetBanking">Net Banking</option>
                                        <option value="Cash">Cash (Manual Settlement)</option>
                                    </select>
                                </div>
                                <?php
                                $result_bill = $org->Selete($_GET['id']);
                                $row_bill = $result_bill->fetch_assoc();
                                ?>
                                <aside class="summary-sidebar">
                                    <h3><i class="fa-solid fa-file-invoice-dollar"></i> Booking Summary</h3>

                                    <div class="bill-row">
                                        <span><i class="fa-solid fa-user-tie"></i> Organizer</span>
                                        <strong><?= $row_bill['full_name'] ?></strong>
                                    </div>

                                    <div class="bill-row">
                                        <span><i class="fa-solid fa-phone"></i> Contact</span>
                                        <strong><?= $row_bill['phone'] ?></strong>
                                    </div>

                                    <div class="divider"></div>

                                    <div class="bill-row">
                                        <span>Base Resource Cost</span>
                                        <strong id="base-cost">₹ 0</strong>
                                    </div>

                                    <div class="bill-row">
                                        <span>Platform & Service Fee</span>
                                        <strong id="service-fee">₹ 0</strong>
                                    </div>

                                    <div class="total-container">
                                        <span class="total-label">Grand Total</span>
                                        <h2 class="total-amount" id="total-display">₹ 0</h2>
                                        <input type="hidden" name="total_amount" id="total_input" value="0">
                                        <input type="hidden" name="organizer_id" value="<?= $row['organizer_id'] ?>">
                                    </div>

                                    <button type="submit" name="book_now" class="btn-confirm">
                                        <i class="fa-solid fa-circle-check"></i> Confirm & Proceed
                                    </button>
                                </aside>
                                <?php
                            } else {
                                echo "Not Found Any Available Resource";
                            } ?>
                        </form>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    <script src="../js/calculator.js"></script>
</body>

</html>