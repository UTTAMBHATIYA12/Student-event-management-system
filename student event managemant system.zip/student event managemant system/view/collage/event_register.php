<?php
session_start();
require_once('../../model/database.php');

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$events = new events();
$obj = new Collage();
$student = new Student();
$collage_id = $obj->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Register Student</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $result = $events->selecte_event_all_student($collage_id);
    if (isset($_REQUEST['find'])) {
        $result = $events->search_event_all_student($collage_id, $_POST['find']);
    }

    if ($result->num_rows > 0) { ?>
        <div class="header">
            <h2>
                <form method="post">Manage Event Regiser Student <input type="button" style="width:170px; margin-left: 53%;"
                        value="Delete All Student" class="delete" name="delete_all_event_register_student"></form>
            </h2><br>
            <table>
                <tr>
                    <th>Student Name</th>
                    <th>Event Name</th>
                    <th>Evant Date & Time</th>
                    <th>Gruop / Solo</th>
                    <th>Team Member</th>
                    <th>E-mail</th>
                    <th>Action</th>
                </tr>
                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['full_name']; ?></td>
                        <td><?php echo $row['event_name']; ?></td>
                        <td><?php echo $row['event_date'] . " / " . $row['time']; ?></td>
                        <td><?php echo $row['type'];
                        if ($row['type'] === "GROUP") {
                            echo " ( " . $row['group_name'] . " ) "; ?></td>
                            <td><?php
                            foreach (explode(",", $row['member_id']) as $id) {
                                if ($stu_fetch = $student->getNameById(trim($id))->fetch_assoc())
                                    echo $stu_fetch['email'] . ",<br>";

                            }
                        } else
                            echo "</td><td>-</td>";
                        ?></td>
                        <td><?php echo $row['email'] ?></td>

                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="event_id" value="<?php echo $row['student_id']; ?>">
                                <button type="submit" name="delete" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No Records Found";
    }
    ?>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>