<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
require_once('../../model/database.php');

$booking = new booking();
$collage = new Collage();
$collage_id = $collage->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Booking History</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <style>
        .box {
            display: flex;
            background: #fff;
            border-radius: 10px;
            margin-bottom: 15px;
            overflow: hidden;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.08);
            transition: 0.3s;
        }

        .content {
            padding: 15px;
            width: 100%;
        }

        .title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .info {
            font-size: 14px;
            color: #555;
            margin: 3px 0;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 8px;
            font-size: 13px;
            color: #777;
        }

        #notification_show {
            padding: 20px;
            background-color: rgb(218, 218, 218);
            border-radius: 10px;
            position: fixed;
            right: -1000px;
            bottom: 20px;
            transition: 0.5s;
        }

        #notification_show.show {
            right: 20px;
        }
    </style>
</head>

<body>
    <?php
    include('../inc/collage_left_menu.php');

    ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $booking_id = 0;
    $result = $booking->select_booking_info($collage_id);
    if (isset($_REQUEST['find'])) {
        $result = $booking->search_booking_info($_POST['find'], $collage_id);
    } elseif (isset($_REQUEST['delete_history'])) {
        echo "<script>alert('" . $booking->delete_booking_info($_POST['booking_id'], $collage_id) . "')</script>";
    } elseif (isset($_REQUEST['delete_all_history'])) {
        echo "<script>alert('" . $booking->delete_booking_info(0, $collage_id) . "')</script>";

    } elseif (isset($_REQUEST['send_booking_id'])) {
        $booking_id = $_POST['booking_id'];
        ?>
        <style>
            #notification_show {
                right: 20px;
            }
        </style>
        <?php
    } elseif (isset($_REQUEST['cancle_booking'])) {
        echo "<script>alert('" . $booking->manageBookingStatus("CollageToOrg", $collage_id, $_POST['booking_id'], "cancled by collage") . "')</script>";
    }
    ?>
    <form method="post">
        <div id="notification_show">Are you Sure ? Cancle Booking &nbsp;&nbsp;
            <input type="hidden" name="booking_id" value=<?php echo $booking_id; ?>>
            <input type="submit" style="width:100px" name="cancle_booking" value="OK" class="edit"><input type="submit"
                style="width:100px" class="delete" value="Canlce">
        </div>
    </form>
    <div class="header">
        <h2>
            <form method="post">📊 Booking History<input type="submit" style="width:120px; margin-left: 67%;"
                    value="Delete All" class="delete" name="delete_all_history"></form>
        </h2><br>
        <?php if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) { ?>

                <div class="box">



                    <div class="content">

                        <!-- Event Name -->
                        <div class="title"><?php echo $row['event_name']; ?></div>

                        <!-- Organizer (optional if you join organizer table) -->
                        <div class="info">👤 Organizer: <?php echo $row['full_name']; ?></div>

                        <!-- Resource -->
                        <div class="info">🏢 Resource: <?php echo $row['resource_name']; ?></div>
                        <!-- purpose -->
                        <div class="info">📌 Other Requerment : <?php echo $row['other_requerment']; ?></div>

                        <div class="footer">

                            <!-- Date -->
                            <span>📅 <?php echo $row['booking_date'] . " To " . $row['booking_date_end']; ?></span>

                            <!-- Delete Button -->
                            <span>
                                <form method="post">
                                    <input type="hidden" name="booking_id" value="<?php echo $row['booking_id']; ?>">
                                    <?php if ($row['status'] == "cancled by collage") {
                                        echo "Order Cancle By You";
                                    } elseif ($row['status'] == "cancled by orgenizer") {
                                        echo "Order Cancle By Orgenizer";
                                    } elseif ($row['status'] == "approved") {
                                        echo "Order Accepted By Orgenizer";
                                    } elseif ($row['status'] == "completed") { /////////
                                        echo "Order Completed";
                                    } else { ?> <input type="submit"
                                            style="width:160px; background: none; font-size: 1.2pc; color: rgb(255, 157, 0);"
                                            value="Cancle Booking" class="delete" name="send_booking_id"> <?php
                                    } ?>
                                    <input type="submit" style="width:80px; background: none; font-size: 1.2pc; color: red;"
                                        value="Delete" class="delete" name="delete_history">
                                </form>
                            </span>

                        </div>
                    </div>
                </div>

            <?php }
        } else {
            echo "Not Found Any Booking History";
        } ?>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>