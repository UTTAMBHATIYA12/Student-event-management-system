<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}

require_once('../../model/database.php');
$obj = new Collage();
$stu = new Student();
$collage_id = $obj->getId($_SESSION['username']);
$Student = new Student();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Student</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php
    $result = $Student->Selete($collage_id);
    if (isset($_REQUEST['find'])) {
        $result = $Student->Search($collage_id, $_POST['find']);
    }

    if ($result->num_rows > 0) {
        ?>
        <div class="header">
            <h2>
                <form method="post">Manage Student <input type="button" style="width:170px; margin-left: 67%;"
                        value="Delete All Student" class="delete" name="delete_all_register_student"></form>
            </h2><br>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Full Name</th>
                    <th>Roll No/course/Year/Sem</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                </tr>

                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td>
                            <?php echo $row['student_id']; ?>
                        </td>
                        <td>
                            <?php echo $row['full_name']; ?>
                        </td>
                        <td>
                            <?php echo $row['roll_number'] . " / " . $row['course'] . " / " . $row['year'] . " / " . $row['semester']; ?>
                        </td>
                        <td>
                            <?php echo $row['gender']; ?>
                        </td>
                        <td>
                            <?php echo $row['email']; ?>
                        </td>
                        <td>
                            <?php echo $row['phone']; ?>
                        </td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                <button type="submit" name="delete" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No found Any record Of The Student";
    }
    ?>
    </div>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>