<?php
session_start();
require_once('../../model/database.php');
if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$events = new events();
$obj = new Collage();
$collage_id = $obj->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Event</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
    <style>
        /* Container to help position the custom arrow */
        .select-wrapper {
            position: relative;
            width: 100%;
        }

        .select-ui {
            width: 100%;
            padding: 12px 15px;
            font-size: 14px;
            font-family: inherit;
            color: #1e293b;
            background-color: #fcfcfd;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            cursor: pointer;
            appearance: none;
            /* Removes default browser arrow */
            -webkit-appearance: none;
            -moz-appearance: none;
            transition: all 0.2s ease;
        }

        /* Custom Arrow Icon */
        .select-wrapper::after {
            content: '\25BC';
            /* Unicode for downward arrow */
            font-size: 10px;
            color: #64748b;
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
        }

        /* Focus State - Matches your text inputs */
        .select-ui:focus {
            outline: none;
            border-color: #2563eb;
            background-color: #ffffff;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }

        /* Hover Effect */
        .select-ui:hover {
            border-color: #cbd5e1;
        }

        #both_needed {
            display: none;
        }
    </style>
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="header">
        <form method="post">
            <input type="text" name="find" placeholder="Search Anythink....." class="search" id="search">&nbsp;
        </form>
    </div>
    <?php

    $result = $events->Selete($collage_id, 0); // 0 means select all recoord from the database --------------------
    if (isset($_REQUEST['find'])) {
        $result = $events->Search($collage_id, $_POST['find']); // for search event details 
    } elseif (isset($_POST['insert'])) {

        $image_name = $_FILES['upload_image']['name'];
        $temp_name = $_FILES['upload_image']['tmp_name'];
        $folder = __DIR__ . "/../uploads/event_pictures/" . $image_name;
        move_uploaded_file($temp_name, $folder);
        echo "<script>alert('" . $events->Insert(
            $_POST['event_name'],
            $_POST['event_desc'],
            $_POST['event_date'],
            $_POST['event_venue'],
            $_POST['event_time'],
            $image_name,
            $collage_id
        ) . "')</script>";
    } elseif (isset($_REQUEST['delete'])) {
        $events->Event_Cancle(0, $_POST['event_id']); // delete student who participent in the event
        $events->Delete($_POST['event_id'], $collage_id); // delete event
        echo "<script>alert('Event Deleted Successfully !!')</script>";
    } elseif (isset($_REQUEST['update_event_details'])) {
        echo "<script>alert('currently not working????????????????????????????? Your  Event Data Updated Successfully !!')</script>";
    }
    if (isset($_REQUEST['update']) || !empty($_SESSION['event_id'])) {
        if (!empty($_POST['event_id']))
            $event_id = $_POST['event_id'];
        else
            $event_id = $_SESSION['event_id'];
        $result = $events->Selete($collage_id, $event_id);
        if ($result->num_rows > 0) {
            if ($row = $result->fetch_assoc()) {
                $event_name = $row['event_name'];
                $event_desc = $row['event_description'];
                $event_date = $row['event_date'];
                $event_time = $row['time'];
                $event_venue = $row['venue'];
                $registration_type = $row['registration_type'];
                $event_capacity = $row['capacity'];
            }
        }
    }
    if ($result->num_rows > 0) {
        ?>

        <div class="header">
            <h2>Manage Event</h2><br>
            <table>
                <tr>
                    <th>Event ID</th>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Date & Time</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['event_id']; ?></td>
                        <td><?php echo $row['event_name']; ?></td>
                        <td><?php echo $row['event_description']; ?></td>
                        <td><?php echo $row['event_date'] . " / " . $row['time']; ?></td>
                        <td><?php echo $row['venue']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
                                <button type="submit" name="update" class="edit">Update</button><br>
                                <button type="submit" name="delete" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    } else {
        echo "No Found Any Event";
    }
    ?>
    <div class="header">
        <h2>Create/Update Event</h2><br>
        <form action="" class="form" method="post" id="events_form" enctype="multipart/form-data">
            <label for="">Event Name</label>
            <input type="text" name="event_name" value="<?php if (!empty($event_name))
                echo $event_name ?>" required><br><br>
                <label for="">Event Description</label>
                <input type="text" name="event_desc" value="<?php if (!empty($event_desc))
                echo $event_desc ?>" required><br><br>
                <label for="">Event Date </label>
                <input type="date" name="event_date" value="<?php if (!empty($event_date))
                echo $event_date ?>" required><br><br>
                <label for="">Event Time</label>
                <input type="time" name="event_time" value="<?php if (!empty($event_time))
                echo $event_time ?>" required><br><br>
                <label for="">Event Venue</label>
                <input type="text" name="event_venue" value="<?php if (!empty($event_venue))
                echo $event_venue ?>" required><br><br>
                <label for="">Image</label>
                <input type="file" name="upload_image"><br><br>
                <label for="reg_type">Registration Type</label>
                <div class="select-wrapper">
                    <select name="reg_type" id="reg_type" class="select-ui" onchange="toggleRegFields()" required>
                        <option value="<?php if (!empty($registration_type))
                echo $registration_type;
            else
                echo "Select Registration Type"
                    ?>"><?php if (!empty($registration_type))
                echo $registration_type;
            else
                "Select Registration Type" ?></option>
                        <option value="solo">Solo</option>
                        <option value="group">Group</option>
                        <option value="both">Both</option>
                    </select>
                </div>
                <br><br>

                <div id="capacity_container">
                    <label id="capacity_label">Total Students Allowed (Solo)</label>
                    <input type="number" name="event_capacity" min="1" value="<?php if (!empty($event_capacity))
                echo $event_capacity; ?>" required>
                <label id="both_needed">Total Group Allowed</label>
                <input type="number" name="event_capacity" min="1" id="both_needed" required>
            </div>
            <br><br>
            <?php if (empty($event_id)) { ?>
                <input type="submit" name="insert" value="CREATE / UPDATE">
            <?php } else { ?>
                <input type="submit" name="update_event_details" value="CREATE / UPDATE">
            <?php } ?>
        </form>
    </div>
    </div>
    <script>
        function toggleRegFields() {
            const regType = document.getElementById('reg_type').value;
            const label = document.getElementById('capacity_label');
            const open_both = document.getElementById('both_needed');

            if (regType === 'solo') {
                label.innerText = "Total Students Allowed (Solo)";
            } elseif(regType === 'group'){ }
            label.innerText = "Total Groups Allowed";
            else {
                open_both.style.display = "block";
            }
        }

        // Run once on page load to set the correct label if updating
        window.onload = toggleRegFields;
    </script>
    <script src="../js/auto_submit_search.js"></script>
</body>

</html>