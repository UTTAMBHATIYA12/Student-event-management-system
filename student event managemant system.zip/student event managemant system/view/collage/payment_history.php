<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
require_once('../../model/database.php');

$booking = new booking();
$collage = new Collage();
$payment = new payment();
$collage_id = $collage->getId($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History</title>
    <link rel="stylesheet" href="../css/admin_style.css">
    <style>
        .header-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;

        }

        .position_search {
            margin: 20px 10px 20px 10px;
        }

        .status-select {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #cbd5e1;
            background-color: white;
            cursor: pointer;
            font-weight: 600;
            outline: none;
            color: #1e293b;
        }
    </style>
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <div class="header">

        <div class="header-wrapper position_search">
            <h2>Payment History</h2>
            <input type="submit" value="Delete All" class="delete" style="width:100px">
        </div>
        <div class="header-wrapper position_search">
            <p style="color:black;">Search By Payment Status :</p>
            <!-- <form method="post" onchange="this.form.submit()">
                <select class="status-select">
                    <option value="all">All Status</option>
                    <option value="paid">Paid</option>
                    <option value="pending">Pending</option>
                </select>
            </form> -->
        </div>

        <div class="table-scroll-box">
            <table class="payment-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Orgenizer Name</th>
                        <th>Event/Resource</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $payment->paymentHistory(0, $collage_id);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td>
                                    <?= date('d-M-Y', strtotime($row['payment_date'])) ?>
                                </td>

                                <td>
                                    <?= $row['organizer_name'] ?>
                                </td>

                                <td style="font-size: 12px; color: #64748b;">
                                    ID:
                                    <?= $row['transaction_reference'] ?>
                                </td>

                                <td class="amt-text">₹
                                    <?= number_format($row['amount']) ?>
                                </td>

                                <td>
                                    <?php if (strtolower($row['payment_status']) == 'completed' || strtolower($row['payment_status']) == 'paid'): ?>
                                        <span class="badge success">Paid</span>
                                    <?php else: ?>
                                        <span class="badge warning">
                                            <?= $row['payment_status'] ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">No payment history found.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>