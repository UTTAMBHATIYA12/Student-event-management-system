<?php
session_start();
require_once('../../model/database.php');

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Organizers</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../css/admin_css.css">
    <style>
        /* Container for the Grid */
        .organizer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 25px;
            padding: 20px 0;
        }

        /* The Professional Card */
        .org-card {
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        .org-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        /* Card Top Section */
        .org-header {
            background: #f8fafc;
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        .org-title h3 {
            color: #1e293b;
            font-size: 1.25rem;
            margin-bottom: 5px;
        }

        .org-title span {
            font-size: 0.85rem;
            color: #eab308;
            /* Star Color */
            font-weight: bold;
        }

        /* Card Info Section */
        .org-body {
            padding: 20px;
            flex-grow: 1;
        }

        .org-body p {
            font-size: 0.95rem;
            color: #475569;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .org-body i {
            color: #2563eb;
            /* Primary theme color */
            width: 20px;
        }

        /* Resource Tags */
        .tag-section {
            margin-top: 15px;
        }

        .tag-section strong {
            font-size: 0.85rem;
            color: #64748b;
        }

        .tags {
            margin-top: 8px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .tag {
            background: #eff6ff;
            color: #2563eb;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            border: 1px solid #dbeafe;
        }

        /* Action Buttons */
        .org-footer {
            padding: 15px 20px;
            background: #f8fafc;
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 10px;
        }

        .view-btn,
        .book-btn {
            text-decoration: none;
            text-align: center;
            padding: 10px;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .view-btn {
            background: transparent;
            border: 1px solid #cbd5e1;
            color: #475569;
        }

        .view-btn:hover {
            background: #f1f5f9;
        }

        .book-btn {
            background: #2563eb;
            color: #ffffff;
            border: none;
        }

        .book-btn:hover {
            background: #1d4ed8;
        }
    </style>
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>

    <div class="header">
        <h1>Explore Event Organizers</h1>
        <p>Select the best professionals to provide resources for your college events.</p>
    </div>

    <div class="organizer-container">
        <?php
        $org = new Orgenizer();
        // Fetching all organizers (passed 0 as per your method)
        $result = $org->Selete(0);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="org-card">
                    <div class="org-header">
                        <div class="org-title">
                            <h3><i class="fas fa-building"></i> <?php echo $row['comapny_name']; ?></h3>
                            <span><i class="fas fa-star"></i> <?php echo $row['rating']; ?> / 5.0</span>
                        </div>
                    </div>

                    <div class="org-body">
                        <p><i class="fas fa-user-tie"></i> <b>Owner:</b> <?php echo $row['full_name']; ?></p>
                        <p><i class="fas fa-briefcase"></i> <b>Experience:</b> <?php echo $row['experience']; ?> Years</p>
                        <p><i class="fas fa-phone-alt"></i> <b>Contact:</b> <?php echo $row['phone']; ?></p>

                        <div class="tag-section">
                            <strong>Provided Resources:</strong>
                            <div class="tags">
                                <span class="tag">DJ</span>
                                <span class="tag">Lighting</span>
                                <span class="tag">Stage Setup</span>
                                <span class="tag">Sound</span>
                            </div>
                        </div>
                    </div>

                    <div class="org-footer">
                        <a href="orgenizer_profile.php?id=<?php echo $row['organizer_id']; ?>" class="view-btn">View
                            Profile</a>
                        <a href="orgenizer_profile.php?id=<?php echo $row['organizer_id']; ?>" class="book-btn">Book
                            Resources</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No organizers available at the moment.</p>";
        }
        ?>
    </div>
    </div>
</body>

</html>