<?php
session_start();
require_once('../../model/database.php');

if (!isset($_SESSION['username']) || $_SESSION['collage'] !== "collage") {
    header("Location: /student%20event%20managemant%20system/index.php");
    exit();
}
$events = new events();
$obj = new Collage();
$galary = new galary();
$collage_id = $obj->getId($_SESSION['username']);

if (isset($_REQUEST['upload'])) {
    $image_name = $_FILES['upload_image']['name'];
    $temp_name = $_FILES['upload_image']['tmp_name'];
    $folder = __DIR__ . "/../uploads/galary_pictures/" . $image_name;
    move_uploaded_file($temp_name, $folder);
    if (!empty($image_name))
        $galary->insert_image($image_name, $collage_id);
    else
        echo "<script>alert('Select An Image !!')</script>";
} elseif (isset($_REQUEST['Delete_All'])) {
    echo "<script>alert('" . $galary->DeleteAllImage($collage_id) . "')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Galary</title>
    <link rel="icon" href="../uploads/system_picture/icon.png">
    <link rel="stylesheet" href="../css/admin_css.css">
    <style>
        .events {
            padding: 10px 20px;
        }

        .events .h2_galary {
            text-align: left;
            font-size: 32px;
            margin-bottom: 40px;
            color: #444;
        }

        .events h2 p {
            font-size: 15px;
            margin-left: 6px;
            margin-bottom: 20px;
        }

        .events h2 form input {
            padding: 2px 10px 2px 10px;
            outline: none;
        }

        .event-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(50px, 1fr));
            gap: 1px;
        }

        .event-card {
            background: transparent;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s, box-shadow 0.3s;
            margin: 0 10px 20px 10px;
        }

        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.12);
        }

        .event-card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }

        .event-grid .box_inner input {
            margin: 0 0 0 91%;

        }
    </style>
</head>

<body>
    <?php include('../inc/collage_left_menu.php'); ?>
    <section class="events">
        <h2 class="h2_galary">
            Galary section
            <p>You Can Upload Your Event Image Only</p>
            <form action="" method="post" enctype="multipart/form-data">
                <input type="file" name="upload_image" id="">
                <input type="submit" name="upload" value="Upload">
                <input type="submit" style="margin-left:56%;" name="Delete_All" value="Delete All Images">
            </form>
        </h2>
        <div class="event-grid">
            <?php
            $result = $galary->select($collage_id);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="box_inner">
                        <form action="" method="post" id="form_1">
                            <input type="checkbox" name="event_id_s" id="checkbox">

                            <div class="event-card">
                                <a href="../uploads/galary_pictures/<?php echo $row['image_path'] ?>">

                                    <img src="../uploads/galary_pictures/<?php echo $row['image_path'] ?>" alt="image not available">
                                </a>
                            </div>
                    </div>
                    <?php
                }
            }
            ?>
            <!-- <input type="submit" style="padding:2px 10px 2px 11px; position:absolute; top:31.8%; right: 15.3%;" name="Delete_Select_item" value="Delete Selected Image"> -->
            </form>
        </div>
    </section>
    <?php
    // if (isset($_REQUEST['Delete_Select_item'])) {
    //     echo $_POST['event_id_s']."1";
    // }

    ?>
</body>

</html>