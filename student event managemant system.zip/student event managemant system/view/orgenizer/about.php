<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Student Event Management</title>
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #10b981;
            --dark: #1e293b;
            --slate: #64748b;
            --light-bg: #f8fafc;
        }

        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            color: var(--dark);
            line-height: 1.6;
        }

        /* Hero Section */
        .about-hero {
            display: flex;
            align-items: center;
            gap: 50px;
            max-width: 1200px;
            margin: 80px auto;
            padding: 0 20px;
            flex-wrap: wrap;
        }

        .hero-image {
            flex: 1;
            min-width: 350px;
        }

        .hero-image img {
            width: 100%;
            border-radius: 24px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
        }

        .hero-content {
            flex: 1;
            min-width: 350px;
        }

        .hero-content h1 {
            font-size: 3rem;
            line-height: 1.1;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 1.2rem;
            color: var(--slate);
            margin-bottom: 30px;
        }

        /* Why Choose Us Section */
        .features-section {
            background-color: var(--light-bg);
            padding: 80px 20px;
            text-align: center;
        }

        .section-title {
            margin-bottom: 50px;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .feature-card {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-10px);
        }

        .feature-card h3 {
            color: var(--primary);
            margin-bottom: 15px;
        }

        /* How It Works Steps */
        .steps-container {
            max-width: 1000px;
            margin: 100px auto;
            padding: 0 20px;
        }

        .step {
            display: flex;
            gap: 40px;
            margin-bottom: 60px;
            align-items: center;
        }

        .step-num {
            background: var(--primary);
            color: white;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-weight: bold;
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        @media (max-width: 768px) {
            .hero-content h1 { font-size: 2.2rem; }
            .about-hero { text-align: center; }
            .step { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <?php require_once('../inc/org_header.php'); ?>

    <section class="about-hero">
        <div class="hero-content">
            <h1 style="color: var(--primary);">Simple Tools for Big Ideas.</h1>
            <p>We are a dedicated team of student developers and event organizers who realized that college events are often held back by paperwork and poor coordination. We built this system to fix that.</p>
            <button style="background: var(--dark); color: white; border: none; padding: 15px 30px; border-radius: 8px; font-weight: bold; cursor: pointer;">Explore Resources</button>
        </div>
        <div class="hero-image">
            <img src="..\uploads\system_picture\about_us.jpg" alt="Student Team Planning">
        </div>
    </section>

    <section class="features-section">
        <div class="section-title">
            <h2>Why Use Our System?</h2>
            <p style="color: var(--slate);">Built by students, for students.</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <h3>Fast Booking</h3>
                <p>No more running from office to office. Book sound, lights, and venues in 3 clicks.</p>
            </div>
            <div class="feature-card">
                <h3>Real-time Tracking</h3>
                <p>Know exactly when your request is accepted or if you need to provide more details.</p>
            </div>
            <div class="feature-card">
                <h3>Budget Friendly</h3>
                <p>Get the best resource prices specifically negotiated for student organizations.</p>
            </div>
        </div>
    </section>

    <div class="steps-container">
        <h2 style="text-align: center; margin-bottom: 60px;">How It Works</h2>
        
        <div class="step">
            <div class="step-num">1</div>
            <div>
                <h3>Select Your College</h3>
                <p>Browse through our verified list of colleges and available event dates.</p>
            </div>
        </div>

        <div class="step">
            <div class="step-num">2</div>
            <div>
                <h3>Pick Your Resources</h3>
                <p>Add sound systems, stages, or technical teams to your event basket.</p>
            </div>
        </div>

        <div class="step">
            <div class="step-num">3</div>
            <div>
                <h3>Get Approved</h3>
                <p>The organizer reviews your request. Once accepted, you're ready to rock!</p>
            </div>
        </div>
    </div>
    <?php require_once('../inc/org_footer.php'); ?>
</body>
</html>