<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {
    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$resource_manage = new resource_manage();
$org = new Orgenizer();
$org_id = $org->getId($_SESSION['username'], 0);


if (isset($_REQUEST['add_resourse'])) {
    // 1. Fetch text and number inputs
    $resource_name = $_POST['resource_name'];
    $resource_type = $_POST['resource_type'];
    $capacity = $_POST['capacity'];
    $price = $_POST['price'];
    $status = $_POST['status'];
    $details = $_POST['details'];

    $image_name = $_FILES['upload_image']['name'];
    $temp_name = $_FILES['upload_image']['tmp_name'];
    $folder = __DIR__ . "/../uploads/resourse image/" . $image_name;
    move_uploaded_file($temp_name, $folder);
    echo "<script>alert('" . $resource_manage->AddNewResource($org_id, $resource_name, $resource_type, $capacity, $price, $status, $details, $image_name) . "')</script>";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer - Resource Management</title>
    <style>
        :root {
            --primary: #000000;
            --primary-hover: #2f62cf;
            --success: #10b981;
            --dark: #1e293b;
            --border: #e2e8f0;
        }

        /* 1. Main Action Button */
        .add-btn {
            background: var(--primary);
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 20px;
        }

        /* 2. Modal/Box Styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }

        .modal-content {
            background: white;
            width: 90%;
            max-width: 500px;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            position: relative;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .close-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #64748b;
        }

        /* Form Styling */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border);
            border-radius: 6px;
            box-sizing: border-box;
        }

        /* 3. Resource Display Box (Right-to-Left Scroll) */
        .resource-container {
            background: white;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid var(--border);
            overflow: hidden;
            margin: 10px;
        }

        .table-scroll {
            width: 100%;
            overflow-x: auto;
        }

        .res-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        .res-table th,
        .res-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #f1f5f9;
            white-space: nowrap;
        }

        .res-table th {
            background: #f8fafc;
            color: #64748b;
            font-size: 0.85rem;
            text-transform: uppercase;
        }

        .img-preview {
            width: 50px;
            height: 50px;
            border-radius: 6px;
            object-fit: cover;
            background: #eee;
        }

        .header-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .headre_posiotion {
            margin: 20px 20px 0 10px;
        }

        .status-select {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #cbd5e1;
            background-color: white;
            cursor: pointer;
            font-weight: 600;
            outline: none;
            color: #1e293b;
        }
    </style>
</head>

<body>
    <?php include('../inc/org_header.php'); ?>
    <div class="header-wrapper headre_posiotion">
        <h3>Resource Inventory</h3>

        <button class="add-btn" onclick="toggleModal(true)">+ Add Resource</button>
    </div>
    <div id="resourceModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="toggleModal(false)">&times;</span>
            <h3 style="margin-top:0">Add New Resource</h3>
            <form method="POST" enctype="multipart/form-data"><br><br>
                <div class="form-group">
                    <label>Resource Name</label>
                    <input type="text" name="resource_name" placeholder="e.g. Decoration" required>
                </div>
                <div class="form-group">
                    <label>Resource Type</label>
                    <input type="text" name="resource_type" placeholder="e.g. hall Decoration" required>
                </div>
                <div class="form-group">
                    <label>Capacity</label>
                    <input type="text" name="capacity" placeholder="e.g. 500 Watts / 200 People" required>
                </div>
                <div class="form-group">
                    <label>Price (₹)</label>
                    <input type="text" name="price" placeholder="e.g. 500 /-per day" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="Available">Available</option>
                        <option value="Booked">Booked</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Details</label>
                    <textarea name="details" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Upload Image</label>
                    <input type="file" name="upload_image" accept="image/*">
                </div>
                <button type="submit" name="add_resourse" class="add-btn" style="width:100%; margin:0">Save
                    Resource</button>
            </form>
        </div>
    </div>
    <div class="resource-container">
        <form method="POST">
            <div class="status-box header-wrapper">
                <label style="display:block; margin-bottom: 8px; font-size: 14px; color: #64748b;">
                    Update Resource Status:
                </label>
                <select name="status" class="status-select" onchange="this.form.submit()">
                    <option value="">Filter By Status</option>
                    <option value="All">All</option>
                    <option value="Available">Available</option>
                    <option value="booked">Booked</option>
                </select>
        </form>
        <?php
        if (isset($_REQUEST['resource_status'])) {
            if ($_POST['resource_status'] == "Remove") {
                echo "<script>alert('" . $resource_manage->deleteResourseByOrgenizer($org_id, $_POST['resource_id']) . "')</script>";
            } else {
                echo "<script>alert('" . $resource_manage->updateResourseStatusByOrgenizer($org_id, $_POST['resource_status'], $_POST['resource_id']) . "')</script>";
            }
        }
        $result = $resource_manage->getResourseDtailsByOrgenizerId($org_id);
        if (isset($_REQUEST['status']))
            if ($_POST['status'] != "All")
                $result = $resource_manage->searchResourseDtailsByOrgenizerId($org_id, $_POST['status']);
            else
                $result = $resource_manage->getResourseDtailsByOrgenizerId($org_id);
        if ($result->num_rows > 0) { ?>
            <div class="table-scroll">
                <table class="res-table">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Type</th>
                            <th>Capacity</th>
                            <th>Price</th>
                            <th>Details</th>
                            <th>Quick Status Update</th>
                        </tr>
                    </thead>
                    <?php
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tbody>
                            <tr>
                                <td>
                                    <img class="img-preview" src="../uploads/resourse image/<?= $row['image'] ?>" alt="">
                                </td>
                                <td><?= $row['resource_type'] ?></td>
                                <td><?= $row['capacity'] ?></td>
                                <td><strong><?= $row['price'] ?></strong></td>
                                <td><?= $row['details'] ?></td>
                                <td>
                                    <form method="POST" id="statusForm1">
                                        <input type="hidden" name="resource_id" value="<?= $row['resource_id'] ?>">
                                        <select name="resource_status" class="status-select" onchange="this.form.submit()">
                                            <option value="<?= $row['status'] ?>">
                                                <?= $row['status'] ?>
                                            </option>
                                            <?php if ($row['status'] != "Available") { ?>
                                                <option value="Available">Available</option>
                                                <?php
                                            } else { ?>
                                                <option value="Booked">Booked</option>
                                            <?php } ?>
                                            <option value="Remove">Remove</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    <?php }
        } else
            echo "No Fond Any Resourse<br><br>"; ?>
            </table>
        </div>
    </div>
    </div>

    <?php include('../inc/org_footer.php'); ?>
    <script>
        // Toggle the Modal Box
        function toggleModal(show) {
            const modal = document.getElementById('resourceModal');
            modal.style.display = show ? 'block' : 'none';
        }

        // Close modal if user clicks outside of it
        window.onclick = function (event) {
            const modal = document.getElementById('resourceModal');
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>

</html>