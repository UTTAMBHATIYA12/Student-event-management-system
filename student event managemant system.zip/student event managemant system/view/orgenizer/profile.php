<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$org = new Orgenizer();
$org_id = $org->getId($_SESSION['username'], 0);
$result = $org->getOrgenizerDetails($_SESSION['username']);
if ($row = $result->fetch_assoc()) {
    $name = $row['full_name'];
    $email = $row['email'];
    $phone = $row['phone'];
    $organization = $row['comapny_name'];
    $experience = $row['experience'];
    $about = $row['bio'];
    $address = $row['address'];
    $image = $row['comapny_name'];

}
if (isset($_POST['update_submit'])) {
    $name = $_POST['name'];
    $comapny_name = $_POST['organization'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $experience = $_POST['experience'];
    $about = $_POST['about'];
    $image_name = $_FILES['upload_image']['name'];
    $temp_name = $_FILES['upload_image']['tmp_name'];
    $folder = __DIR__ . "/../uploads/profile_pictures/" . $image_name;
    move_uploaded_file($temp_name, $folder);
    echo "<script>alert('" . $org->updateOrgenizerDetails($name, $comapny_name, $phone, $address, $experience, $about, $image_name, $org_id) . "')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <style>
        /* 1. Main Outer Wrapper (Keeps it centered on desktop without body tag) */
        .profile-section-wrapper {
            display: flex;
            justify-content: center;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        /* 2. Main Profile Container */
        .profile-container {
            width: 100%;
            max-width: 800px;
            /* Increased for better desktop presence */
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            padding: 40px;
            border: 1px solid #e2e8f0;
        }

        /* 3. Header Section */
        .profile-image {
            text-align: center;
            margin-bottom: 30px;
        }

        .image-wrapper img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #f1f5f9;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .profile-container h2 {
            font-size: 1.8rem;
            color: #0f172a;
            margin: 15px 0 5px 0;
        }

        .org-badge {
            background: #eef2ff;
            color: #6366f1;
            padding: 5px 15px;
            border-radius: 100px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        /* 4. The Info Grid - Fixed to fill main box */
        .profile-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            /* Two equal columns */
            gap: 20px;
            width: 100%;
            /* Ensures it fills the main box */
        }

        /* 5. Individual Info Items */
        .info-item {
            background: #f8fafc;
            padding: 20px;
            border-radius: 16px;
            border: 1px solid #f1f5f9;
            display: flex;
            flex-direction: column;
        }

        /* Make Address and About Me span the full width of the main box */
        .info-item:nth-child(4),
        .info-item:nth-child(5) {
            grid-column: span 2;
        }

        .info-item span {
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #94a3b8;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .info-item p {
            font-size: 1rem;
            color: #334155;
            font-weight: 500;
            margin: 0;
            line-height: 1.5;
        }

        /* 6. Edit Button Styling */
        .edit-btn {
            grid-column: span 2;
            /* Full width at the bottom of the grid */
            margin-top: 10px;
            padding: 15px;
            background: #0f172a;
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .edit-btn:hover {
            background: #334155;
        }

        /* 7. Mobile Responsive: Stack boxes on small screens */
        @media (max-width: 600px) {
            .profile-info {
                grid-template-columns: 1fr;
            }

            .info-item:nth-child(4),
            .info-item:nth-child(5),
            .edit-btn {
                grid-column: span 1;
            }
        }

        /* --- MODAL BOX STYLES --- */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            /* Semi-transparent dark slate */
            backdrop-filter: blur(5px);
            display: none;
            /* Hidden by default */
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            width: 95%;
            max-width: 500px;
            padding: 30px;
            border-radius: 24px;
            position: relative;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .close-btn {
            background: #f1f5f9;
            border: none;
            font-size: 20px;
            cursor: pointer;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            color: #64748b;
        }

        .edit-form-group {
            text-align: left;
            margin-bottom: 15px;
        }

        .edit-form-group label {
            font-size: 0.75rem;
            font-weight: 700;
            color: #64748b;
            text-transform: uppercase;
            display: block;
            margin-bottom: 5px;
        }

        .edit-form-group input,
        .edit-form-group textarea,
        .edit-form-group select {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            background: #f8fafc;
            font-family: inherit;
            color: #1e293b;
        }

        form .save-btn {
            background: #6366f1;
            margin-top: 10px;
        }

        form .save-btn:hover {
            background: #4f46e5;
        }
    </style>
</head>

<body>
    <?php include '../inc/org_header.php'; ?>
    <div class="profile-section-wrapper">
        <div class="profile-container">
            <div class="profile-image">
                <div class="image-wrapper">
                    <img src="..\uploads\profile_pictures\<?= $row['compny_logo'] ?>" alt="Organizer">
                </div>

                <h2><?php echo $name; ?></h2>
                <div class="org-badge"><?php echo $organization; ?></div>
            </div>

            <div class="profile-info">
                <div class="info-item"><span>Email Address</span>
                    <p><?php echo $email; ?></p>
                </div>
                <div class="info-item"><span>Phone Number</span>
                    <p><?php echo $phone; ?></p>
                </div>
                <div class="info-item"><span>Experience</span>
                    <p><?php echo $experience; ?></p>
                </div>
                <div class="info-item"><span>Address</span>
                    <p><?php echo $address; ?></p>
                </div>
                <div class="info-item"><span>About Me</span>
                    <p><?php echo $about; ?></p>
                </div>
                <button class="edit-btn" onclick="openEditModal()">Edit Profile</button>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="editModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 style="font-weight: 700;">Edit Profile Details</h3>
                <button class="close-btn" onclick="closeEditModal()">&times;</button>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="edit-form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo $name; ?>" required>
                </div>

                <div class="edit-form-group">
                    <label>Organization(Company Name)</label>
                    <input type="text" name="organization" value="<?php echo $organization; ?>" required>
                </div>

                <div class="edit-form-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" value="<?php echo $phone; ?>" required>
                </div>
                <div class="edit-form-group">
                    <label>E-Mail</label>
                    <input type="email" name="email" value="<?php echo $email; ?>" title="Could Change Email" disabled>
                </div>
                <div class="edit-form-group">
                    <label>Address</label>
                    <input type="tel" name="address" value="<?php echo $address; ?>" required>
                </div>

                <div class="edit-form-group">
                    <label>Experience</label>
                    <select name="experience">
                        <option value="1 Year" <?php if ($experience == "1 Year")
                            echo "selected"; ?>>1 Year</option>
                        <option value="2 Years" <?php if ($experience == "2 Years")
                            echo "selected"; ?>>2 Years</option>
                        <option value="3 Years" <?php if ($experience == "3 Years")
                            echo "selected"; ?>>3 Years</option>
                        <option value="5+ Years" <?php if ($experience == "5+ Years")
                            echo "selected"; ?>>5+ Years
                        </option>
                    </select>
                </div>

                <div class="edit-form-group">
                    <label>About Me</label>
                    <textarea name="about" rows="3"><?php echo $about; ?></textarea>
                </div>
                <div class="edit-form-group">
                    <label>Profile Picture</label>
                    <input type="file" name="upload_image">

                </div>

                <button type="submit" name="update_submit" class="save-btn">Save Changes</button>
            </form>
        </div>
    </div>
    <?php include '../inc/org_footer.php'; ?>
    <script>
        const modal = document.getElementById('editModal');

        function openEditModal() {
            modal.style.display = 'flex';
        }

        function closeEditModal() {
            modal.style.display = 'none';
        }

        // Close if user clicks outside the white box
        window.onclick = function (event) {
            if (event.target == modal) {
                closeEditModal();
            }
        }
    </script>

</body>

</html>