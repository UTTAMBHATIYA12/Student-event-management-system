<?php
require_once('../../model/database.php');
$notification = new notification();
$org = new Orgenizer();
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {
    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
$result = $notification->getNotificationOfOrgenizer($org->getId($_SESSION['username'], 0));
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .header-wrapper {
            display: flex;
            justify-content: space-between;
            /* Pushes content to edges */
            align-items: center;
            /* Aligns vertically */
            margin: 20px 0;
            /* Vertical spacing */
            flex-wrap: wrap;
            gap: 15px;
        }
    </style>
</head>

<body>
    <?php include '../inc/org_header.php'; ?>
    <div class="profile-container">
        <div class="events-section">
            <div class="header-wrapper">
                <h4>Notifications</h4>
                <?php if ($result->num_rows > 0) { ?>
                    <button style="padding:5px 10px; border-radius: 2px;">Delete All</button>
                </div>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <div class="event-item">
                        <div>
                            <h4><?= $row['information'] ?></h4>
                            <p><?= $row['date'] ?></p>
                        </div>
                        <form action="" method="post">
                            <input type="hidden" name="event_id" value="">
                            <input type="submit" value="Delete" name="Event_cancle_join" class="cancle_event">
                        </form>
                    </div>
                <?php }
                } else {
                    echo "No Found Any Notification";
                } ?>
        </div>
    </div>

    <?php include '../inc/org_footer.php'; ?>

</body>

</html>