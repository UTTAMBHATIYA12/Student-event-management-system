<?php
session_start();
// Security check
if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {
    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Required !!'));
    exit();
}
require_once('../../model/database.php');
$resource_manage = new resource_manage();
$org = new Orgenizer();
$org_id = $org->getId($_SESSION['username'], 0);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accepted Resource Requests</title>
    <style>
        :root {
            --bg-color: #f1f5f9;
            --card-bg: #ffffff;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --accent: #2563eb;
            --success: #10b981;
        }

        .page-header {
            max-width: 2100px;
            margin: 10px auto 50px auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-header h2 {
            margin: 20px 0 0 20px;
            color: var(--text-main);
            font-size: 1.5rem;
        }

        .page-header p {
            margin: 5px 0 0 20px;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        /* The Main Box Container */
        .content-box {
            max-width: 95%;
            margin: 20px;
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-color);
        }

        /* Scrollable table container */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            /* Enables the right-to-left move */
            border-radius: 8px;
        }

        .accepted-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
            /* Ensures columns stay properly spaced */
        }

        .accepted-table th {
            background-color: #f8fafc;
            color: var(--text-muted);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
            padding: 14px 20px;
            text-align: left;
            border-bottom: 2px solid var(--border-color);
        }

        .accepted-table td {
            padding: 16px 20px;
            color: var(--text-main);
            font-size: 0.9rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
            /* Auto-adjust columns based on text length */
        }

        .accepted-table tr:hover {
            background-color: #fbfcfe;
        }

        /* Status Badge */
        .status-badge {
            background-color: #dcfce7;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
        }

        .completed {
            color: #0EA5E9;
        }

        .pedding {
            color: #F59E0B;
        }

        .accept {
            color: #10B981;
        }

        .price-text {
            font-weight: 700;
            color: var(--text-main);
        }

        /* Scrollbar Styling */
        .table-responsive::-webkit-scrollbar {
            height: 8px;
        }

        .table-responsive::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        .table-responsive::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        .table-responsive::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        .status-select {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #cbd5e1;
            background-color: white;
            cursor: pointer;
            font-weight: 600;
            outline: none;
            color: #1e293b;
        }

        .status-select:hover {
            border-color: #2563eb;
        }

        .header-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 10px;
            flex-wrap: wrap;
            gap: 15px;
        }
    </style>
</head>

<body>

    <?php include('../inc/org_header.php'); ?>

    <div class="page-header">
        <div class="header_box_text">
            <h2>Accepted Requests</h2>
            <p>List of resources currently approved for colleges</p>
        </div>
    </div>
    <div class="content-box">
        
            <form method="POST">
                <div class="status-box header-wrapper">
                    <label style="display:block; margin-bottom: 8px; font-size: 14px; color: #64748b;">
                        Update Request Status:
                    </label>
                    <select name="status" class="status-select" onchange="this.form.submit()">
                        <option value="">Filter By Staus</option>
                        <option value="All">All</option>
                        <option value="pending">Pending</option>
                        <option value="approved">Accepted</option>
                        <option value="cancled by orgenizer">Rejected You</option>
                        <option value="cancled by collage">cancled by collage</option>
                        <option value="completed">Completed</option>
                    </select>
            </form>
        </div>
        <?php $result = $resource_manage->selectAllocatedResourseCollages($org_id);
        if (isset($_REQUEST['status']))
            if ($_POST['status'] != "All")
                $result = $resource_manage->searchByStatus($org_id, $_POST['status']);
            else
                $result = $resource_manage->selectAllocatedResourseCollages($org_id);
        if ($result->num_rows > 0) { ?>
        <div class="table-responsive">
            <table class="accepted-table">
                <thead>
                    <tr>
                        <th>College Name</th>
                        <th>Resource Name</th>
                        <th>Resource Type</th>
                        <th>Capacity</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tbody>
                        <tr>
                            <td><strong><?= $row['college_name'] ?></strong></td>
                            <td><?= $row['resource_name'] ?></td>
                            <td><?= $row['resource_type'] ?></td>
                            <td><?= $row['capacity'] ?></td>
                            <td class="price-text">₹ <?= $row['price'] ?></td>
                            <td><span class="status-badge <?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                        </tr>
                    </tbody>
                <?php }
        } else
            echo "No Found Any Collage<br>";
        ?>
        </table>
    </div>
    </div>

    <?php include('../inc/org_footer.php'); ?>

</body>

</html>