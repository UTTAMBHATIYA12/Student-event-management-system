<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$booking = new booking();
$orgenizer = new Orgenizer();
$orgenizer_id = $orgenizer->getId($_SESSION['username'], 0);
if (isset($_REQUEST['accept_request'])) {
    echo "<script>alert('" . $booking->manageBookingStatus("orgToCollage", $_POST['college_id'], $_POST['booking_id'], "pending") . "')</script>";
} elseif (isset($_REQUEST['cancle_request'])) {
    echo "<script>alert('" . $booking->manageBookingStatus("orgToCollage", $_POST['college_id'], $_POST['booking_id'], "cancled by orgenizer") . "')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../css/student_style.css">
    <style>
        .booking-request-card {
            margin: 25px;
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid #e2e8f0;
            padding: 30px;
            width: 95%;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.05);
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .booking-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 2px dashed #f1f5f9;
        }

        .request-title h3 {
            font-size: 1.2rem;
            color: #0f172a;
            font-weight: 800;
        }

        .request-id {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 600;
        }

        .status-badge {
            background: #fef3c7;
            color: #d97706;
            font-size: 11px;
            font-weight: 700;
            padding: 5px 12px;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .booking-details-grid {
            padding: 20px;
            border-radius: 20px;
            margin: 0 0 20px 0;
            border: 1px solid black;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .detail-group label {
            display: block;
            font-size: 11px;
            text-transform: uppercase;
            font-weight: 700;
            color: #6366f1;
            /* Indigo Theme */
            margin-bottom: 6px;
        }

        .detail-group p {
            font-size: 14px;
            color: #334155;
            font-weight: 500;
            line-height: 1.4;
        }

        .resource-pill {
            background: #f1f5f9;
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            color: #1e293b;
            display: inline-block;
        }

        .check-item {
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
            color: #475569;
        }

        .price-text {
            font-size: 1.1rem !important;
            font-weight: 800 !important;
            color: #059669 !important;
            /* Success Green */
        }

        /* Action Buttons */
        .action-footer {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            border: none;
            font-family: inherit;
        }

        .btn-reject {
            background: #f1f5f9;
            color: #64748b;
        }

        .btn-reject:hover {
            background: #fee2e2;
            color: #ef4444;
        }

        .btn-accept {
            background: #0f172a;
            color: #fff;
            box-shadow: 0 4px 12px rgba(15, 23, 42, 0.2);
        }

        .btn-accept:hover {
            background: #6366f1;
            transform: translateY(-2px);
        }
    </style>
</head>

<body>
    <?php include('../inc/org_header.php') ?>
    <div class="booking-request-card">
        <div class="booking-header">
            <div class="request-title">
                <h3>New Booking Request</h3>
                <span class="request-id">REF: #EV-2026-042</span>
            </div>
            <span class="status-badge">Action Required</span>
        </div>
        <?php
        $result = $booking->select_new_booking_request_info_for_orgenizer($orgenizer_id);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <form class="booking-details-grid" method="post">
                    <div class="detail-group">
                        <label>College Department</label>
                        <p><?= $row['college_name'] ?></p>
                    </div>

                    <div class="detail-group">
                        <label>Event Category</label>
                        <p><?= $row['event_category'] . "(" . $row['event_name'] . ")" ?> </p>
                    </div>

                    <div class="detail-group">
                        <label>Requested Resource</label>
                        <div class="resource-pill">
                            <i class="fas fa-microchip"></i><?= $row['resource_name'] ?>
                        </div>
                    </div>
                    <div class="detail-group">
                        <label>Timeline</label>
                        <p><strong>Start:</strong> <?= $row['booking_date'] ?></p>
                        <p><strong>End:</strong> <?= $row['booking_date_end'] ?></p>
                    </div>

                    <div class="detail-group">
                        <label>Venue Selection</label>
                        <p><?= $row['address'] ?></p>
                    </div>

                    <div class="detail-group">
                        <label>Other Requerment</label>
                        <div class="check-item">
                            <i class="fas fa-check-circle"></i> <?= $row['other_requerment'] ?>
                        </div>
                    </div>

                    <div class="detail-group">
                        <label>Faculty Coordinator</label>
                        <p><?= $row['principal_name'] . "(" . $row['phone'] . ")" ?></p>
                    </div>

                    <div class="detail-group">
                        <label>Allocated Budget</label>
                        <p class="price-text">₹45,000.00</p>
                    </div>
                    <input type="hidden" name="college_id" value="<?= $row['college_id'] ?>">
                    <input type="hidden" name="booking_id" value="<?= $row['booking_id'] ?>">
                    <button class="btn btn-reject detail-group" type="submit" name="cancle_request">Decline Request</button>
                    <button class="btn btn-accept detail-group" type="submit" name="accept_request">Accept & Book
                        Resource</button>
                </form>
            <?php }
        } else
            echo "Currently Not Available Any Collage Request"; ?>

    </div>
    <?php include('../inc/org_footer.php') ?>
</body>

</html>