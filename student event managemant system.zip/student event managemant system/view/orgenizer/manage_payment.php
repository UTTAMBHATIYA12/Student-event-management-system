<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {
    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$payment = new payment();
$org = new Orgenizer();
$_SESSION['total_amount'] = 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer - My Earnings</title>
    <style>
        /* Container for the whole section */
        .payment-container {
            margin-top: 50px;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            padding: 20px;
            background: #f8fafc;
            border-radius: 12px;
        }

        /* Header styling */
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .balance-card {
            background: #ffffff;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border-left: 4px solid #10b981;
        }

        .balance-card span {
            display: block;
            font-size: 0.85rem;
            color: #64748b;
            text-transform: uppercase;
        }

        .balance-card strong {
            font-size: 1.5rem;
            color: #1e293b;
        }

        /* NEW OPPOSITE SIDE BOX CODE */
        .header-wrapper {
            display: flex;
            justify-content: space-between;
            /* Pushes content to edges */
            align-items: center;
            /* Aligns vertically */
            margin: 20px 0;
            /* Vertical spacing */
            flex-wrap: wrap;
            gap: 15px;
        }

        .sub-text {
            color: #64748b;
            margin: 0;
            font-family: sans-serif;
            font-size: 0.95rem;
        }

        .status-select {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            background-color: white;
            cursor: pointer;
            outline: none;
            min-width: 140px;
        }

        /* Table Scroll Box */
        .table-scroll-box {
            width: 100%;
            overflow-x: auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 700px;
        }

        .payment-table th,
        .payment-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #f1f5f9;
            white-space: nowrap;
        }

        .payment-table thead {
            background-color: #f8fafc;
        }

        .payment-table th {
            color: #475569;
            font-weight: 600;
        }

        .amt-text {
            font-weight: 600;
            color: #0f172a;
        }

        .badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .success {
            background-color: #dcfce7;
            color: #166534;
        }

        .table-scroll-box::-webkit-scrollbar {
            height: 6px;
        }

        .table-scroll-box::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <?php include('../inc/org_header.php'); ?>
    <div class="payment-container">
        <div class="header-flex">
            <div>
                <h2 style="margin:0; color: #1e293b;">Manage Payment</h2>
            </div>
            <div class="balance-card">
                <span>Total Received</span>
                <strong>₹ <?= $_SESSION['total_amount'] ?></strong>
            </div>
        </div>

        <div class="header-wrapper">
            <p class="sub-text">View all payments received from colleges</p>

            <select class="status-select">
                <option value="all">All Status</option>
                <option value="paid">Paid</option>
                <option value="pending">Pending</option>
            </select>
        </div>

        <div class="table-scroll-box">
            <table class="payment-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>College Name</th>
                        <th>Event/Resource</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $payment->paymentHistory($org->getId($_SESSION['username'], 0), 0);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // Optional: Accumulate total for the 'Total Received' card
                            $_SESSION['total_amount'] += $row['amount'];
                            ?>
                            <tr>
                                <td>
                                    <?= date('d-M-Y', strtotime($row['payment_date'])) ?>
                                </td>

                                <td>
                                    <?= $row['college_name'] ?>
                                </td>

                                <td style="font-size: 12px; color: #64748b;">
                                    ID:
                                    <?= $row['transaction_reference'] ?>
                                </td>

                                <td class="amt-text">₹
                                    <?= number_format($row['amount']) ?>
                                </td>

                                <td>
                                    <?php if (strtolower($row['payment_status']) == 'completed' || strtolower($row['payment_status']) == 'paid'): ?>
                                        <span class="badge success">Paid</span>
                                    <?php else: ?>
                                        <span class="badge warning">
                                            <?= $row['payment_status'] ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">No payment history found.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include('../inc/org_footer.php'); ?>
</body>

</html>