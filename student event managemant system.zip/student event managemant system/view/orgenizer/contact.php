<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['orgenizer'] !== 'orgenizer') {

    header("Location: /student%20event%20managemant%20system/index.php?error=" . urlencode('Login Requerd !!'));
    exit();
}
require_once('../../model/database.php');
$org = new Orgenizer();
$Contact_us = new Contact_us();
$result = $org->getOrgenizerDetails($_SESSION['username']);
if ($row = $result->fetch_assoc()) {
    $name = $row['full_name'];
    $email = $row['email'];
}
if (isset($_REQUEST['send_message'])) {
    echo "<script>alert('" . $Contact_us->addContactByOrgenizer($org->getId($_SESSION['username'], 0), $_POST['message']) . "')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        .contact-card {
            max-width: 1000px;
            margin: 30px auto 60px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
            display: flex;
            overflow: hidden;
            padding: 30px;
            gap: 30px;
        }

        /* Left side: Friendly Text */
        .contact-text {
            flex: 1;
        }

        .contact-text h1 {
            font-size: 2.5rem;
            color: #1a202c;
            margin-bottom: 10px;
        }

        .contact-text p {
            color: #718096;
            font-size: 1.1rem;
            line-height: 1.6;
        }

        .contact-details {
            margin-top: 30px;
        }

        .detail-row {
            margin-bottom: 15px;
            color: #2d3748;
            font-weight: 500;
        }

        /* Right side: Clean Form */
        .contact-form {
            flex: 1.2;
            background: #f8fafc;
            padding: 30px;
            border-radius: 16px;
        }

        .input-box {
            margin-bottom: 15px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 1rem;
            background: white;
            transition: 0.3s;
        }

        input:focus,
        textarea:focus {
            border-color: #3182ce;
            box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.2);
            outline: none;
        }

        .send-btn {
            background: #1a202c;
            color: white;
            border: none;
            width: 100%;
            padding: 14px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .send-btn:hover {
            background: #2d3748;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .contact-card {
                flex-direction: column;
                padding: 20px;
            }
        }
    </style>
</head>

<body>
    <?php require_once('../inc/org_header.php'); ?>

    <div class="contact-card">
        <div class="contact-text">
            <h1>Let's Talk.</h1>
            <p>If you're an organizer facing an issue or just want to say your problum, send us a message.</p>

            <div class="contact-details">
                <div class="detail-row">📍 123 Tech Park, Ahmedabad</div>
                <div class="detail-row">✉️ support@evently.com</div>
                <div class="detail-row">📞 +91 98765 43210</div>
            </div>
        </div>

        <div class="contact-form">
            <form method="POST">
                <div class="input-box">
                    <input type="text" name="name" placeholder="Your Name" value="<?php echo $name; ?>" required>
                </div>
                <div class="input-box">
                    <input type="email" name="email" placeholder="Email Address" value="<?php echo $email; ?>" required>
                </div>
                <div class="input-box">
                    <textarea name="message" rows="4" placeholder="Tell us more..." required></textarea>
                </div>
                <button type="submit" name="send_message" class="send-btn">Send Message</button>
            </form>
        </div>
    </div>
    <?php require_once('../inc/org_footer.php'); ?>
</body>

</html>