<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Student Event Management System</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
        }

        footer {
            background: #222;
            color: #ccc;
            padding: 40px 20px;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            max-width: 1100px;
            margin: auto;
        }

        .footer-section {
            flex: 1 1 220px;
            margin: 10px;
        }

        .footer-section h3 {
            color: #fff;
            margin-bottom: 15px;
        }

        .footer-section a {
            color: #ccc;
            text-decoration: none;
            display: block;
            margin-bottom: 8px;
        }

        .footer-section a:hover {
            color: #00adb5;
        }

        .social-links a {
            display: inline-block;
            margin-right: 10px;
            font-weight: 500;
        }
    </style>
</head>

<body>

    <footer>
        <div class="footer-container">

            <!-- About -->
            <div class="footer-section">
                <h3>Student Event System</h3>
                <p>Manage and participate in college events easily with our student-friendly platform.</p>
            </div>

            <!-- Quick Links -->
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="index.php">Home</a>
                <a href="event.php">Events</a>
                <a href="contact.php">Contact Us</a>
                <a href="../common_file/logout.php">Logout</a>
            </div>

            <!-- Social Media -->
            <div class="footer-section">
                <h3>Join With Us</h3>
                <div class="social-links">
                    <a href="#">Instagram</a>
                    <a href="#">Facebook</a>
                    <a href="#">YouTube</a>
                    <a href="#">Google</a>
                </div>
                <p>Email: ucbhatiya6@gmail.com</p>
                <p>Phone: 11236985470</p>
            </div>
    </footer>

</body>

</html>