<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        .sems-footer {
            background-color: #0f172a;
            /* Deep Slate */
            color: #f8fafc;
            padding: 60px 0 20px 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            border-top: 1px solid #1e293b;
        }

        .footer-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1.5fr;
            gap: 50px;
            padding: 0 25px;
        }

        /* Brand Section */
        .sems-logo {
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -1px;
            margin-bottom: 15px;
        }

        .sems-logo span {
            color: #6366f1;
            /* Indigo accents */
        }

        .system-desc {
            color: #94a3b8;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .status-indicator {
            font-size: 12px;
            color: #94a3b8;
            background: rgba(255, 255, 255, 0.05);
            padding: 6px 12px;
            border-radius: 50px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .dot {
            width: 8px;
            height: 8px;
            background: #22c55e;
            /* Green status */
            border-radius: 50%;
            box-shadow: 0 0 10px #22c55e;
        }

        /* Links Section */
        .footer-col h4 {
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 20px;
            color: #ffffff;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .footer-col ul {
            list-style: none;
        }

        .footer-col ul li {
            margin-bottom: 12px;
        }

        .footer-col ul a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .footer-col ul a:hover {
            color: #6366f1;
            padding-left: 4px;
        }

        /* Contact & Social */
        .contact-box {
            background: #1e293b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 15px;
        }

        .contact-box p {
            font-size: 12px;
            color: #94a3b8;
            margin-bottom: 4px;
        }

        .email-link {
            color: #fff;
            font-weight: 600;
            text-decoration: none;
            font-size: 14px;
        }

        .social-grid {
            display: flex;
            gap: 12px;
        }

        .social-grid a {
            width: 38px;
            height: 38px;
            background: #334155;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            color: white;
            transition: 0.3s;
        }

        .social-grid a:hover {
            background: #6366f1;
            transform: translateY(-3px);
        }

        /* Bottom Strip */
        .footer-strip {
            max-width: 1200px;
            margin: 40px auto 0;
            padding: 20px 25px 0;
            border-top: 1px solid #1e293b;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #64748b;
            font-size: 13px;
        }

        @media (max-width: 768px) {
            .footer-wrapper {
                grid-template-columns: 1fr 1fr;
            }

            .footer-strip {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <footer class="sems-footer">
        <div class="footer-wrapper">
            <div class="footer-col brand-info">
                <h2 class="sems-logo">SEMS<span>.pro</span></h2>
                <p class="system-desc">
                    The ultimate coordination bridge between academic institutions and professional event organizers.
                    Streamlining resource allocation and booking management.
                </p>
                <div class="status-indicator">
                    <span class="dot"></span> System Status: <strong>Optimal</strong>
                </div>
            </div>

            <div class="footer-col">
                <h4>Management</h4>
                <ul>
                    <li><a href="#">Resource Allocation</a></li>
                    <li><a href="#">Organizer Directory</a></li>
                    <li><a href="#">Booking Timeline</a></li>
                    <li><a href="#">College Dashboard</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Support</h4>
                <ul>
                    <li><a href="#">Documentation</a></li>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">API Integration</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>

            <div class="footer-col admin-contact">
                <h4>Admin Access</h4>
                <div class="contact-box">
                    <p>Technical Support:</p>
                    <a href="mailto:support@sems.edu" class="email-link">support@sems.edu</a>
                </div>
                <div class="social-grid">
                    <a href="#" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" title="GitHub"><i class="fab fa-github"></i></a>
                    <a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
        </div>

        <div class="footer-strip">
            <p>&copy; 2026 Student Event Management System | Version 2.1 (PHP 8.3)</p>
            <div class="footer-meta">
                <span>Powered by DecorFlow Tech</span>
            </div>
        </div>
    </footer>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</body>

</html>