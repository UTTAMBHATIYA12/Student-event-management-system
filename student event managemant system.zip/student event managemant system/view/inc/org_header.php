<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header</title>
    <link rel="stylesheet" href="../css/student_style.css" />
</head>

<body>
    <div class="header_stu">
        <img src="../css/image/stu_menu.png" id="menubtn" alt="menu">Student Event Management System
    </div>
    <div id="menu">
        <span class="close-btn" id="close_image">✖️</span>
        <h1>Student Event Management System</h1>
        <ul>
            <a href="index.php">
                <li>Home</li>
            </a>
            <a href="view_collage.php">
                <li>View Collage</li>
            </a>
            <a href="manage_resource.php">
                <li>Resource</li>
            </a>
            <a href="manage_payment.php">
                <li>Payment</li>
            </a>
            <a href="notification.php">
                <li>Notification</li>
            </a>
            <a href="about.php">
                <li>About </li>
            </a>
            <a href="contact.php">
                <li>Contact </li>
            </a>
            <a href="profile.php">
                <li>Profile </li>
            </a>
            <a href="\student event managemant system\view\common_file\logout.php">
                <li>Logout </li>
            </a>
        </ul>
    </div>
    <script src="../js/js_file.js"></script>
</body>

</html>