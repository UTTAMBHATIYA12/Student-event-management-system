<link rel="stylesheet" href="../css/admin_css.css">
<?php
require_once('../../model/database.php');
$collage = new Collage();
$collage_id = $collage->getId($_SESSION['username']);
$result = $collage->Selete($collage_id);
?>
<aside class="sidebar">
    <h2>/\Ntehc</h2>
    <nav>
        <a href="index.php">Home</a>
        <a href="manage_event.php">Manage Event</a>
        <a href="manage_galary.php">Manage Galary</a>
        <a href="manage_student.php">Manage Student</a>
        <a href="event_request.php">Event Register Request</a>
        <a href="event_register.php">Event Register Student</a>
        <a href="event_feedback.php">Event FeedBack</a>
        <a href="manage_orgenizer.php">Event Orgenizer</a>
        <a href="my_booking.php">My booking Order</a>
        <a href="payment_history.php">Payment History</a>
        <a href="collage_profile.php">Collage Profile</a>
        <a href="\student event managemant system\view\common_file\logout.php">Logout</a>
    </nav>
</aside>
<!-- Main Content -->
<div class="main">
    <!-- Header -->
    <div class="header">
        <?php
        if ($result->num_rows > 0) {
            if ($row = $result->fetch_assoc()) {
                ?>
                <h1><?php echo $row['college_name']; ?></h1>
                <?php
            }
        }
        ?>
    </div>