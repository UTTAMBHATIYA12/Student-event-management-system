<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>left menu</title>
    <link rel="stylesheet" href="../css/admin_css.css">
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="index.php">Home</a>
        <a href="Collage_request.php">Collage Request</a>
        <a href="ragister_collage_list.php">Collage List</a>
        <a href="view_student.php">view student</a>
        <a href="manage_Orgenizer.php">Manage Orgenizer</a>
        <a href="manage_Payment.php">Manage Payment</a>
        <a href="\student event managemant system\view\common_file\logout.php">Logout</a>
    </div>
    <div class="main">
        <!-- Header -->
        <div class="header">
            <h1>Admin DashBord</h1>
        </div>
</body>

</html>