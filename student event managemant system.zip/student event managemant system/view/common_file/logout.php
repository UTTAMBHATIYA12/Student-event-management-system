<?php
    session_start();
    session_destroy();
    header("Location: http://localhost/student%20event%20managemant%20system/index.php");
    exit();
?>
