const modal = document.getElementById("bookingModal");
const btn = document.getElementById("openBooking");
const close = document.querySelector(".close-btn");
const radioBtns = document.querySelectorAll('input[name="regType"]');
const groupFields = document.getElementById("groupInputs");
const memberCountInput = document.getElementById("memberCount");
const memberList = document.getElementById("memberList");

btn.onclick = () => modal.style.display = "flex";
close.onclick = () => modal.style.display = "none";

// Close modal when clicking outside of it
window.onclick = (event) => {
    if (event.target == modal) modal.style.display = "none";
}

radioBtns.forEach(radio => {
    radio.addEventListener('change', (e) => {
        groupFields.style.display = e.target.value === 'group' ? 'flex' : 'none';
    });
});

memberCountInput.addEventListener('input', (e) => {
    const count = parseInt(e.target.value);
    memberList.innerHTML = "";

    if (count > 1) {
        // Show inputs for additional members
        for (let i = 1; i < count; i++) {
            const div = document.createElement('div');
            div.className = "form-group member-input";
            div.innerHTML = `<label>Member ${i} Student ID</label>
                                     <input type="text" name="member_ids[]" required placeholder="Enter SID">`;
            memberList.appendChild(div);
        }
    }
});