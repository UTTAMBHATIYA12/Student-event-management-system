const menubtn = document.getElementById("menubtn");
const close_image = document.getElementById("close_image");
const menu = document.getElementById("menu");
menubtn.onclick = () => {
    menu.style.left = "0";
    sidebar.style.left = "0";
};
close_image.onclick = () => {
    menu.style.left = "-500px";
    sidebar.style.left = "-500px";
};

// <!-- <script>
//     const show = document.getElementById("notification_show");
//     function cancle_event_box_opne() {
//         show.classList.toggle("show");
//     }
// </script> -->