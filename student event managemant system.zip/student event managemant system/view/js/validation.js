function fetchCollegeName() {
    let code = document.getElementById('collage_code').value;
    let nameField = document.getElementById('college_display_name');
    let idField = document.getElementById('college_id_hidden'); // Target hidden field

    if (code.trim().length > 0) {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", window.location.href, true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                let response = xhr.responseText.trim();

                if (response === "Not Found") {
                    nameField.value = "";
                    idField.value = ""; // Clear hidden ID
                    nameField.placeholder = "Invalid College Code";
                    nameField.style.color = "#ef4444";
                } else {
                    // Split the "Name|ID" string
                    let data = response.split("|");
                    nameField.value = data[0]; // College Name
                    idField.value = data[1];   // College ID (Hidden)
                    nameField.style.color = "#1e293b";
                }
            }
        };
        xhr.send("collage_code=" + encodeURIComponent(code) + "&get_college_name=1");
    } else {
        nameField.value = "";
        idField.value = "";
    }
}

// Password Match Validation
document.querySelector('form').addEventListener('submit', function (e) {
    // Get password values
    const pass = document.querySelector('input[name="password"]').value;
    const confirmPass = document.querySelector('input[name="confirm_password"]').value;

    // Check if they match
    if (pass !== confirmPass) {
        e.preventDefault(); // stop form submit
        alert("Error: Passwords do not match!");

        // Highlight field
        document.querySelector('input[name="confirm_password"]').style.borderColor = "#ef4444";
        document.querySelector('input[name="confirm_password"]').focus();
    }
});

document.querySelector('input[name="password"]').addEventListener('input', function () {
    if (this.value.length >= 8) {
        this.style.borderColor = "#22c55e"; // Green
    } else {
        this.style.borderColor = "#e2e8f0"; // Default
    }
});