document.querySelectorAll('.res-check').forEach(item => {
    item.addEventListener('change', () => {
        let total = 0;

        // Only select checked boxes that have a data-price attribute
        document.querySelectorAll('.res-check:checked').forEach(checked => {
            let price = parseFloat(checked.getAttribute('data-price'));
            if (!isNaN(price)) {
                total += price;
            }
        });

        // Platform fee logic
        let serviceFee = total > 0 ? 50 : 0;
        let grandTotal = total + serviceFee;

        // Update the UI
        document.getElementById('base-cost').innerText = "₹ " + total.toLocaleString('en-IN');
        document.getElementById('service-fee').innerText = "₹ " + serviceFee.toLocaleString('en-IN');
        document.getElementById('total-display').innerText = "₹ " + grandTotal.toLocaleString('en-IN');

        // Update the hidden input for PHP
        document.getElementById('total_input').value = grandTotal;
    });
});