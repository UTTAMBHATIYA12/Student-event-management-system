
let t;
const input = document.getElementById('search');
input.oninput = function () {
    clearTimeout(t);
    t = setTimeout(() => {
        if (this.value.trim() !== "")
            this.form.submit();
    }, 1000);
};