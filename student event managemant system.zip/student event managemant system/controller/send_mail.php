<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Manual include (IMPORTANT)
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $otp = $_POST['otp'];
    $email = $_POST['email'];

    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ucbhatiya6@gmail.com'; // Your Gmail
        $mail->Password = 'rnjygzghoawakhkd'; // Replace this
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Sender & Receiver
        $mail->setFrom('ucbhatiya6@gmail.com', 'Uttam');
        $mail->addAddress($email); // Receiver

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'New Form Message';
        $mail->Body = "
            
            Subject: Password Reset OTP

            Hello,

            Your password reset OTP is:
            <h3>$otp</h3>
            Please use this OTP to reset your password.
            Do not share this OTP with anyone.
            Thank you,
            Student Event Management System
        ";

        $mail->send();

        echo "<h3 style='color:green;'>✅ Email Sent Successfully!</h3>";

    } catch (Exception $e) {
        echo "<h3 style='color:red;'>❌ Error: {$mail->ErrorInfo}</h3>";
    }
}
?>