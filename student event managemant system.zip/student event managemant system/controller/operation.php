<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Manual include (IMPORTANT)
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
require_once(__DIR__ . '/../model/database.php');
class login
{
    function __construct($username, $password)
    {

        session_start();
        $student = new Student();
        $GetStudent = $student->Select_login_details($username, $password);

        $collage = new Collage();
        $GetCollage = $collage->Select_login_details($username, $password);
        $request_not_accept = $collage->Check_Request_Aprove_Or_Not($username, $password);

        $admin = new admin();
        $GetAdmin = $admin->Select_login_details($username, $password);

        $orgenizer = new Orgenizer();
        $GetOrgenizer = $orgenizer->Select_login_details($username, $password);

        if ($GetStudent > 0) {
            $_SESSION['username'] = $username;
            $_SESSION['student'] = "student";
            header("location: view/student/index.php");
            exit();
        } elseif ($GetCollage > 0) {
            $_SESSION['username'] = $username;
            $_SESSION['collage'] = "collage";
            header("location: view/collage/index.php");
            exit();
        } elseif ($GetOrgenizer > 0) {
            $_SESSION['username'] = $username;
            $_SESSION['orgenizer'] = "orgenizer";
            header("location: view/orgenizer/index.php");
            exit();
        } elseif ($GetAdmin > 0) {
            $_SESSION['username'] = $username;
            $_SESSION['admin'] = "admin";
            header("location: view/admin/index.php");
            exit();
        } elseif ($request_not_accept != 0) {
            header("Location: /student%20event%20managemant%20system/index.php?error=" . urldecode('Your request not accepted now because Admin not approve it yet, your wait for approval dot please login after admin approval your request, we will knowing your you and give access'));
            exit();
        } else {
            header("Location: /student%20event%20managemant%20system/index.php?error=" . urldecode('Invalid Username And Password'));
            exit();
        }
    }
}
class Registration extends Database
{

    function student_validation_check($name, $gender, $course, $year, $semester, $roll_no, $college_id, $image, $email, $contact, $password)
    {
        $check_query = $this->conn->query("SELECT * FROM `student_registration` WHERE `email` = '$email' OR `phone` = '$contact'");
        $Student = new Student();



        if ($check_query->num_rows > 0) {
            $existing_user = $check_query->fetch_assoc();

            if ($existing_user['email'] == $email) {
                return "Error : Email already registered !";
            } else {
                return "Error : Contact number already registered";
            }
        } else {
            $image_name = "";
            if (isset($_FILES[$image]) && $_FILES[$image]['error'] == 0) {
                $image_name = $_FILES[$image]['name'];
                $temp_name = $_FILES[$image]['tmp_name'];
                $folder = "c:/wamp64/www/student event managemant system/view/uploads/galary_pictures/" . $image_name;
                move_uploaded_file($temp_name, $folder);
                $register_result = $Student->Student_registration($name, $gender, $course, $year, $semester, $roll_no, $college_id, $image_name, $email, $contact, password_hash($password, PASSWORD_DEFAULT));
                return $register_result;
            }
        }
    }
    function Collage_Validation_check($college_name, $university_name, $college_code, $address, $city, $state, $pincode, $phone_number, $email, $password, $principal_name, $total_students)
    {
        $check_code = $this->conn->query("SELECT college_code FROM college_register WHERE college_code = '$college_code'");
        if (mysqli_num_rows($check_code) > 0) {
            return "Collage Code already registered !";
        }
        $check_email = $this->conn->query("SELECT email FROM college_register WHERE email = '$email'");
        if (mysqli_num_rows($check_email) > 0) {
            return "E-mail already registered !";
        }
        $check_phone = $this->conn->query("SELECT phone FROM college_register WHERE phone = '$phone_number'");
        if (mysqli_num_rows($check_phone) > 0) {
            return "Contact Number already registered !";
        } else {
            $code = 'SEMS' . strtoupper(substr(md5(uniqid()), 0, 8));
            $collage = new Collage();
            return $collage->New_Collage_Register($college_name, $university_name, $college_code, $address, $city, $state, $pincode, $phone_number, $email, $password, $principal_name, $total_students, $code);

        }
    }
}
class verifyEmail extends Database
{
    function send_email($email, $otp_or_code, $sine)
    {
        $mail = new PHPMailer(true);

        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ucbhatiya6@gmail.com'; // Your Gmail
            $mail->Password = 'rnjygzghoawakhkd'; // Replace this
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Sender & Receiver
            $mail->setFrom('ucbhatiya6@gmail.com', 'SEMS');
            $mail->addAddress($email); // Receiver

            // Email Content
            $mail->isHTML(true);
            if ($sine == "Request_accept") {
                $mail->Subject = 'Your SEMS Registration is Approved, Action Required';
                $mail->Body = "
                <div style='max-width: 600px; margin: 20px auto; font-family: Arial, sans-serif; border: 1px solid #e1e1e1; border-radius: 8px; overflow: hidden; background-color: #ffffff;'>
                    <div style='padding: 30px; color: #334155; line-height: 1.6;'>
                        <p style='font-size: 16px; margin-top: 0;'>Dear,</p>
                        <p style='font-size: 16px;'>We are pleased to inform you that your request has been <strong>approved</strong> by
                            the Admin. Your system is now active.</p>
                        <div
                            style='background-color: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 6px; padding: 20px; text-align: center; margin: 25px 0;'>
                            <span style='font-size: 32px; font-weight: bold; color: #1e40af; letter-spacing: 3px;'>$otp_or_code</span>
                        </div>
                        <p style='font-size: 15px; color: #64748b; margin-bottom: 25px;'>
                            Share this code only with students authorized to join your specific events and Register With Us.
                        </p>
                        <p style='font-size: 16px; margin: 0;'>Best regards,</p>
                        <p style='font-size: 16px; font-weight: bold; margin-top: 5px;'>The SEMS Team</p>
                    </div>
                </div>";
            } else {
                $mail->Subject = 'Password Reset OTP';
                $mail->Body = "
                <div style='font-family: Helvetica, Arial, sans-serif; min-width: 1000px; overflow: auto; line-height: 2'>
                    <div style='margin: 50px auto; width: 70%; padding: 20px 0'>
                        <p style='font-size: 1.1em'>Hi, there</p>
                        <p>
                            Verification is required to reset your password. Please enter the following code:</p>
                        <h2 style='background: #00466a; margin: 0 auto; width: max-content; padding: 0 10px; color: #fff; border-radius: 4px;'>$otp_or_code</h2>
                        <p style='font-size: 0.9em;'>Regards,<br />Student Event Management System</p>
                        <hr style='border: none; border-top: 1px solid #eee' />
                        <div style='float: right; padding: 8px 0; color: #aaa; font-size: 0.8em; line-height: 1; font-weight: 300'>
                            <p>Student Event Management System Inc</p>
                        </div>
                    </div>
                </div>";
            }
            $mail->send();

            return 1;

        } catch (Exception $e) {
            return "Error: {$mail->ErrorInfo}";
        }
    }
    function generateOTP()
    {
        return rand(100000, 999999);
    }
}
?>